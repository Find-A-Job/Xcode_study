//
//  DIY_tabbar.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

//4f95fb深蓝色
//77b2fa浅蓝色
//747474 深灰色
//9d9d9d浅灰色

#import "DIY_tabbar.h"

#import "firstView.h"
#import "secondView.h"
#import "thirdButtonView.h"
#import "fourthView.h"
#import "fifthView.h"
#import "KBTabbar.h"
#import "userzmxDelegate.h"

@interface DIY_tabbar() <userzmxDegelate, firstViewDelegate>

//其他数据
@property(nonatomic) CGRect rectOfTabbar;

//中间按钮
@property(strong, nonatomic) UIButton *centBtn;
//按钮回调
-(void)centerBtnClick:(id)sender;

@end

@implementation DIY_tabbar

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //视图1
    firstView *fv1=[[firstView alloc] init];
    fv1.uzd=self;
    fv1.fDele=self;
    UINavigationController *navFv1=[[UINavigationController alloc] initWithRootViewController:fv1];
    navFv1.tabBarItem.title=@"首页";
    [navFv1.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navFv1.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navFv1.tabBarItem.image=[UIImage imageNamed:@"fz1@3x.png"];
    [navFv1.tabBarItem setSelectedImage:[[UIImage imageNamed:@"fz2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navFv1.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navFv1.navigationBar.topItem setTitle:@"首页"];
    [navFv1.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];
    [navFv1.navigationBar setShadowImage:[UIImage new]];
    
    //视图2
    secondView *sv2=[[secondView alloc] init];
    sv2.uzd=self;
    UINavigationController *navSv2=[[UINavigationController alloc] initWithRootViewController:sv2];
    navSv2.tabBarItem.title=@"悬赏";
    [navSv2.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navSv2.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navSv2.tabBarItem.image=[UIImage imageNamed:@"xs1@3x.png"];
    [navSv2.tabBarItem setSelectedImage:[[UIImage imageNamed:@"xs2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navSv2.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navSv2.navigationBar.topItem setTitle:@"悬赏"];
    [navSv2.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];
    [navSv2.navigationBar setShadowImage:[UIImage new]];
    
    //视图4
    fourthView *fv4=[[fourthView alloc] init];
    fv4.uzd=self;
    UINavigationController *navFv4=[[UINavigationController alloc] initWithRootViewController:fv4];
    navFv4.tabBarItem.title=@"资讯";
    [navFv4.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navFv4.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navFv4.tabBarItem.image=[UIImage imageNamed:@"zixun1@3x.png"];
    [navFv4.tabBarItem setSelectedImage:[[UIImage imageNamed:@"zixun2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navFv4.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navFv4.navigationBar.topItem setTitle:@"资讯"];
    [navFv4.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];
    [navFv4.navigationBar setShadowImage:[UIImage new]];
    
    //视图5
    fifthView *fv5=[[fifthView alloc] init];
    fv5.uzd=self;
    UINavigationController *navFv5=[[UINavigationController alloc] initWithRootViewController:fv5];
    navFv5.tabBarItem.title=@"我的";
    [navFv5.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navFv5.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navFv5.tabBarItem.image=[UIImage imageNamed:@"wode1@3x.png"];
    [navFv5.tabBarItem setSelectedImage:[[UIImage imageNamed:@"wode2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navFv5.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navFv5.navigationBar.topItem setTitle:@"我的"];
    [navFv5.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];//背景图设置超过64，然后再设置ShadowImage可以去除底部横线
    [navFv5.navigationBar setShadowImage:[UIImage new]];
    
    //成为tabbar控制器的子控制器
    [self setViewControllers:@[navFv1, navSv2, navFv4, navFv5]];
    
    
    //中央按钮3,KVC
    KBTabbar *tabbar = [[KBTabbar alloc]init];
    [self setValue:tabbar forKeyPath:@"tabBar"];
    [tabbar.centerBtn addTarget:self action:@selector(centerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    self.centBtn=tabbar.centerBtn;
    
    //其他数据
    self.rectOfTabbar=navFv1.tabBarController.tabBar.frame;
}

-(void)centerBtnClick:(id)sender{
    //旋转
    CGAffineTransform p=[self.centBtn transform];
    [UIView animateWithDuration:0.3f animations:^{
        [self.centBtn setTransform:CGAffineTransformMakeRotation(M_PI_2)];
    } completion:^(BOOL finished) {
        if (finished) {
            [UIView animateWithDuration:0.3f animations:^{
                //[self.centBtn setTransform:CGAffineTransformMakeRotation(M_PI_2)];
                [self.centBtn setTransform:p];
            }];
        }
    }];
    
    //位移
//    CGPoint cp=[self.centBtn center];
//    CGPoint cp2=CGPointMake(cp.x+5, cp.y+5);
//    [UIView animateWithDuration:0.3f animations:^{
//        [self.centBtn setCenter:cp2];
//    } completion:^(BOOL finished) {
//        if (finished) {
//            [UIView animateWithDuration:0.3f animations:^{
//                [self.centBtn setCenter:cp];
//            }];
//        }
//    }];
    
    //缩放
//    CGRect cf=[self.centBtn bounds];
//    CGRect cf2=CGRectMake(cf.origin.x, cf.origin.y, cf.size.width/2, cf.size.height/2);
//    [UIView animateWithDuration:0.3f animations:^{
//        [self.centBtn setBounds:cf2];
//    } completion:^(BOOL finished) {
//        if (finished) {
//            [UIView animateWithDuration:0.3f animations:^{
//                [self.centBtn setBounds:cf];
//            }];
//        }
//    }];
    
    //透明度
//    CGFloat ca=[self.centBtn alpha];
//    CGFloat ca2=0;
//    [UIView animateWithDuration:0.3f animations:^{
//        [self.centBtn setAlpha:ca2];
//    } completion:^(BOOL finished) {
//        if (finished) {
//            [UIView animateWithDuration:0.3f animations:^{
//                [self.centBtn setAlpha:ca];
//            }];
//        }
//    }];
    
    //神奇的UIApplication
//    NSString *baiduURL=@"https://www.baidu.com/";
//    NSString *telURL=@"tel://10086";
//    NSString *msgURL=@"sms://10086";
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:msgURL] options:@{} completionHandler:^(BOOL success) {
//        if (success) {
//            NSLog(@"success");
//        }
//    }];
}
-(CGRect)getTabbarRect{
    return self.rectOfTabbar;
}

//懒加载
-(fabuView *)fabu{
    if (!_fabu) {
        _fabu=[[fabuView alloc] init];
    }
    
    return _fabu;
}
-(fabuView *)zhaoling{
    if (!_zhaoling) {
        _zhaoling=[[fabuView alloc] init];
    }
    
    return _zhaoling;
}
//发布失物 视图
-(id)getFabuView{
    return [self fabu];
}
//发布招领 视图
-(id)getZhaoLingView{
    return [self zhaoling];
}
@end
