//
//  usezmx.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#ifndef usezmx_h
#define usezmx_h
//#import <Foundation/Foundation.h>

@protocol userzmxDegelate

@optional
-(CGRect)getTabbarRect;

@end

#endif /* usezmx_h */
