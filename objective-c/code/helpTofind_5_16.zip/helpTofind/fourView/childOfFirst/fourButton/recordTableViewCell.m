//
//  recordTableViewCell.m
//  helpTofind
//
//  Created by rdt on 2019/5/15.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "recordTableViewCell.h"

@implementation recordTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    
    //移除默认控件
    [self.textLabel removeFromSuperview];
    [self.imageView removeFromSuperview];
    
    //
    CGRect cellRect=frame;
    cellRect.size.height=400;
    self.frame=frame;
    
    UIImage *BKimgTransform=[UIImage imageNamed:@"usualBK.png"];
    BKimgTransform=[BKimgTransform resizableImageWithCapInsets:UIEdgeInsetsMake(BKimgTransform.size.height*0.2f, BKimgTransform.size.width*0.2f, BKimgTransform.size.height*0.2f, BKimgTransform.size.width*0.2f)];
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:cellRect];
    bkView.image=BKimgTransform;
    
    //背景图片
    self.backgroundView=bkView;
    
    //背景色透明
    [self setBackgroundColor:[UIColor clearColor]];
    
    //取消选中状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    
    
    
    
    //添加控件
    UIColor *shenhui        = [UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui        = [UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan        = [UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan        = [UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    UIColor *hei            = [UIColor blackColor];
    
    CGRect boundsBase       = [self bounds];
    CGFloat leftOffset      = boundsBase.size.width/10;
    CGFloat topOffset       = boundsBase.size.height/30;
    CGFloat labelWidth      = boundsBase.size.width/3*2;
    CGFloat labelHeight     = boundsBase.size.height/20;
    CGFloat leftImgWidth    = labelHeight/2;
    CGFloat photoImgWidth   = labelWidth;
    CGFloat photoImgHeight  = labelWidth/3*2;
    CGFloat bottomImgWidth  = boundsBase.size.width/8;
    
    UIFont *titleFont       = [UIFont systemFontOfSize:leftOffset/2+1];
    UIFont *nameFont        = [UIFont systemFontOfSize:leftOffset/2-1];
    UIFont *timeFont        = [UIFont systemFontOfSize:10];
    
    
    
    
    UILabel *titleLabel             = [[UILabel alloc] initWithFrame:CGRectMake(leftOffset, topOffset, labelWidth, labelHeight)];
    UILabel *userLabel              = [[UILabel alloc] initWithFrame:CGRectMake(leftOffset, titleLabel.frame.origin.y+titleLabel.bounds.size.height, labelWidth, labelHeight/3*2)];
    UILabel *timeLabel              = [[UILabel alloc] initWithFrame:CGRectMake(leftOffset, userLabel.frame.origin.y+userLabel.bounds.size.height, labelWidth, labelHeight/4*2)];
    UIImageView *lostTimeImgView    = [[UIImageView alloc] initWithFrame:CGRectMake(leftOffset, timeLabel.frame.origin.y+timeLabel.bounds.size.height+5, leftImgWidth, leftImgWidth)];
    UILabel *lostTimeLabel          = [[UILabel alloc] initWithFrame:CGRectMake(lostTimeImgView.frame.origin.x+lostTimeImgView.frame.size.width+5, lostTimeImgView.frame.origin.y, labelWidth, labelHeight/2)];
    
    UIImageView *placeImgView       = [[UIImageView alloc] initWithFrame:CGRectMake(lostTimeImgView.frame.origin.x, lostTimeImgView.frame.origin.y+lostTimeImgView.bounds.size.height+3, leftImgWidth, leftImgWidth)];
    UILabel *placeLabel             = [[UILabel alloc] initWithFrame:CGRectMake(placeImgView.frame.origin.x+placeImgView.bounds.size.width+5, placeImgView.frame.origin.y, lostTimeLabel.bounds.size.width, lostTimeLabel.bounds.size.height)];
    
    UIImageView *typeImgView        = [[UIImageView alloc] initWithFrame:CGRectMake(placeImgView.frame.origin.x, placeImgView.frame.origin.y+placeImgView.bounds.size.height+3, leftImgWidth, leftImgWidth)];
    UILabel *typeLabel              = [[UILabel alloc] initWithFrame:CGRectMake(typeImgView.frame.origin.x+typeImgView.bounds.size.width+5, typeImgView.frame.origin.y, lostTimeLabel.bounds.size.width, lostTimeLabel.bounds.size.height)];
    
    UIImageView *photoImgView       = [[UIImageView alloc] initWithFrame:CGRectMake(leftOffset, typeImgView.frame.origin.y+typeImgView.bounds.size.height+7, photoImgWidth, photoImgHeight)];
    UIImageView *lineImgView        = [[UIImageView alloc] initWithFrame:CGRectMake(boundsBase.size.width/20, photoImgView.frame.origin.y+photoImgView.bounds.size.height+10, self.bounds.size.width/20*18, 1)];
    
    UIButton *phoneButton           = [[UIButton alloc] initWithFrame:CGRectMake((boundsBase.size.width/3-bottomImgWidth)/2, lineImgView.frame.origin.y+10, bottomImgWidth, bottomImgWidth/6*5)];
    UILabel *phoneLabel             = [[UILabel alloc] initWithFrame:CGRectMake(phoneButton.frame.origin.x, phoneButton.frame.origin.y+phoneButton.bounds.size.height, bottomImgWidth, bottomImgWidth/2)];
    
    UIButton *msgButton             = [[UIButton alloc] initWithFrame:CGRectMake((boundsBase.size.width/3-bottomImgWidth)/2+boundsBase.size.width/3, lineImgView.frame.origin.y+10, bottomImgWidth, bottomImgWidth/6*5)];
    UILabel *msgLabel               = [[UILabel alloc] initWithFrame:CGRectMake(msgButton.frame.origin.x, msgButton.frame.origin.y+msgButton.bounds.size.height, bottomImgWidth, bottomImgWidth/2)];
    
    UIButton *commentButton         = [[UIButton alloc] initWithFrame:CGRectMake((boundsBase.size.width/3-bottomImgWidth)/2+boundsBase.size.width/3*2, lineImgView.frame.origin.y+10, bottomImgWidth, bottomImgWidth/6*5)];
    UILabel *commentLabel           = [[UILabel alloc] initWithFrame:CGRectMake(commentButton.frame.origin.x, commentButton.frame.origin.y+commentButton.bounds.size.height, bottomImgWidth, bottomImgWidth/2)];
    
    
    
    titleLabel.textColor    = shenlan;
    userLabel.textColor     = hei;
    timeLabel.textColor     = shenhui;
    lostTimeLabel.textColor = shenlan;
    placeLabel.textColor    = shenlan;
    typeLabel.textColor     = shenlan;
    phoneLabel.textColor    = shenlan;
    msgLabel.textColor      = shenlan;
    commentLabel.textColor  = shenlan;
    
    
    
    
    titleLabel.font         = titleFont;
    userLabel.font          = nameFont;
    timeLabel.font          = timeFont;
    lostTimeLabel.font      = timeFont;
    placeLabel.font         = timeFont;
    typeLabel.font          = timeFont;
    phoneLabel.font         = nameFont;
    msgLabel.font           = nameFont;
    commentLabel.font       = nameFont;
    
    
    
    
    [self addSubview:titleLabel];
    [self addSubview:userLabel];
    [self addSubview:timeLabel];
    [self addSubview:lostTimeImgView];
    [self addSubview:lostTimeLabel];
    [self addSubview:placeImgView];
    [self addSubview:placeLabel];
    [self addSubview:typeImgView];
    [self addSubview:typeLabel];
    [self addSubview:photoImgView];
    [self addSubview:lineImgView];
    [self addSubview:phoneButton];
    [self addSubview:phoneLabel];
    [self addSubview:msgButton];
    [self addSubview:msgLabel];
    [self addSubview:commentButton];
    [self addSubview:commentLabel];
    
    
    
    
    UIImage *lostTimeImg    = [UIImage imageNamed:@"biaoshi1@3x.png"];
    lostTimeImgView.image   = lostTimeImg;
    UIImage *placeImg       = [UIImage imageNamed:@"biaoshi2@3x.png"];
    placeImgView.image      = placeImg;
    UIImage *typeImg        = [UIImage imageNamed:@"biaoshi3@3x.png"];
    typeImgView.image       = typeImg;
    UIImage *photoImg       = [UIImage imageNamed:@"ka.png"];
    photoImgView.image      = photoImg;
    UIImage *lineImg        = [UIImage imageNamed:@"xian.png"];
    lineImgView.image       = lineImg;
    UIImage *phoneImg       = [UIImage imageNamed:@"tel@3x.png"];
    [phoneButton setBackgroundImage:phoneImg forState:UIControlStateNormal];
    UIImage *msgImg       = [UIImage imageNamed:@"msg@3x.png"];
    [msgButton setBackgroundImage:msgImg forState:UIControlStateNormal];
    UIImage *commentImg       = [UIImage imageNamed:@"comment@3x.png"];
    [commentButton setBackgroundImage:commentImg forState:UIControlStateNormal];
    
    
    
    
    titleLabel.tag          = 10;
    userLabel.tag           = 11;
    timeLabel.tag           = 12;
    lostTimeImgView.tag     = 13;
    lostTimeLabel.tag       = 14;
    placeImgView.tag        = 15;
    placeLabel.tag          = 16;
    typeImgView.tag         = 17;
    typeLabel.tag           = 18;
    photoImgView.tag        = 19;
    lineImgView.tag         = 20;
    phoneButton.tag         = 21;
    phoneLabel.tag          = 22;
    msgButton.tag           = 23;
    msgLabel.tag            = 24;
    commentButton.tag       = 25;
    commentLabel.tag        = 26;
    
    
    
    [phoneLabel setTextAlignment:NSTextAlignmentCenter];
    [msgLabel setTextAlignment:NSTextAlignmentCenter];
    [commentLabel setTextAlignment:NSTextAlignmentCenter];
    
    
    
    
    titleLabel.text=@"丢失校园卡一张";
    userLabel.text=@"张先生";
    timeLabel.text=@"2019-01-02 19:12 发布";
    lostTimeLabel.text=@"2019-1-1";
    placeLabel.text=@"湖南省永州市零陵区德财路";
    typeLabel.text=@"卡包";
    phoneLabel.text=@"电话";
    msgLabel.text=@"短信";
    commentLabel.text=@"评论";
    
    
    
    
//    [titleLabel setBackgroundColor:[UIColor orangeColor]];
//    [userLabel setBackgroundColor:[UIColor grayColor]];
//    [timeLabel setBackgroundColor:[UIColor orangeColor]];
//    [lostTimeLabel setBackgroundColor:[UIColor grayColor]];
//    [placeLabel setBackgroundColor:[UIColor orangeColor]];
//    [typeLabel setBackgroundColor:[UIColor grayColor]];
//    [phoneLabel setBackgroundColor:[UIColor orangeColor]];
//    [msgLabel setBackgroundColor:[UIColor orangeColor]];
//    [commentLabel setBackgroundColor:[UIColor orangeColor]];
    
    
    
    //button callback
#warning shouye_shiwu_phoneButton_click add
#warning shouye_shiwu_msgButton_click add
#warning shouye_shiwu_commentButton_click add
    
    
    NSLog(@"%s: %f, %f, %f, %f", __FILE__, leftOffset, topOffset, labelWidth, labelHeight);
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
