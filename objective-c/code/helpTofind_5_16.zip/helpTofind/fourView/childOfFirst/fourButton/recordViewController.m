//
//  recordViewController.m
//  helpTofind
//
//  Created by rdt on 2019/5/14.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "recordViewController.h"
#import "recordTableView.h"

@interface recordViewController () <UITableViewDelegate, UITableViewDataSource>

//leftcell
@property(strong, nonatomic)NSString *leftCellIdent;

//rightcell
@property(strong, nonatomic)NSString *rightCellIdent;

//typeData
@property(strong, nonatomic)NSDictionary *typeData;

@end

@implementation recordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //基础数据
    //{
        //cellIdent
        self.leftCellIdent=@"leftCell";
        self.rightCellIdent=@"rightCell";
    
        //type data
        self.typeData=[[NSDictionary alloc] initWithObjectsAndKeys:@"全部", @"1", @"卡包", @"2", @"电子", @"3", @"饰品", @"4", @"文件", @"5", @"宠物", @"6", @"其他", @"7", nil];
    
        //uicolor
        UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
        UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
        UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
        UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
        UIColor *shurukuang=[UIColor colorWithRed:0xec/255.0f green:0xf3/255.0f blue:0xfe/255.0f alpha:1.0f];
        UIColor *noColor=[UIColor clearColor];
        
        //base  750x1334
        CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
        CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
        CGFloat stateBarHeight=[[UIApplication sharedApplication] statusBarFrame].size.height;
        CGFloat navBarHeight=[self.navigationController.navigationBar bounds].size.height;
        CGFloat tabbarHeight=self.tabBarController.tabBar.bounds.size.height;
    
        //bkimg
        UIImage *BKimgTransform=[UIImage imageNamed:@"usualBK.png"];
        //BKimgTransform=[BKimgTransform stretchableImageWithLeftCapWidth:BKimgTransform.size.width*0.2f topCapHeight:BKimgTransform.size.height*0.2f];
        BKimgTransform=[BKimgTransform resizableImageWithCapInsets:UIEdgeInsetsMake(BKimgTransform.size.height*0.2f, BKimgTransform.size.width*0.2f, BKimgTransform.size.height*0.2f, BKimgTransform.size.width*0.2f)];
        UIImage *qqlBKImgTransform=[UIImage imageNamed:@"qianqianlanBK.png"];
        qqlBKImgTransform=[qqlBKImgTransform stretchableImageWithLeftCapWidth:qqlBKImgTransform.size.width*0.1f topCapHeight:qqlBKImgTransform.size.height*0.1f];
    
        
    //}

    
    
    
    
    
    
    //背景view，imageview
    UIImageView *bk=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    bk.image=qqlBKImgTransform;
    [self.view addSubview:bk];
    
    
    
    //左类目view， view
    //--左类目view的背景view， imageview
    //--左类目view的按钮， tableview
    UIView *leftView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, winWidth/6.0f, winHeight-tabbarHeight-stateBarHeight-navBarHeight)];
    [self.view addSubview:leftView];
    
    UIImageView *bkImgLeftView=[[UIImageView alloc] initWithFrame:leftView.bounds];
    bkImgLeftView.image=BKimgTransform;
    [leftView addSubview:bkImgLeftView];
    
    UITableView *typeTableView=[[UITableView alloc] initWithFrame:leftView.bounds style:UITableViewStylePlain];
    typeTableView.delegate=self;
    typeTableView.dataSource=self;
    [typeTableView setBackgroundColor:noColor];
    [typeTableView setScrollEnabled:NO];
    [typeTableView setSeparatorColor:shenlan];
    UIEdgeInsets sepEdge=[typeTableView separatorInset];
    sepEdge.right=sepEdge.left;
    [typeTableView setSeparatorInset:sepEdge];//分割线长度设置
    [typeTableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    
    [leftView addSubview:typeTableView];
    
    
    
    
    //右tableview
    //cell
//    UIView *rightView=[[UIView alloc] initWithFrame:CGRectMake(leftView.bounds.size.width, leftView.frame.origin.y, self.view.bounds.size.width-leftView.bounds.size.width, leftView.bounds.size.height)];
//    [self.view addSubview:rightView];
//
//    UIImageView *bkImgRightView=[[UIImageView alloc] initWithFrame:rightView.bounds];
//    bkImgRightView.image=BKimgTransform;
//    [rightView addSubview:bkImgRightView];
    recordTableView *rtv=[[recordTableView alloc] initWithFrame:CGRectMake(leftView.bounds.size.width, leftView.frame.origin.y, self.view.bounds.size.width-leftView.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
    [self.view addSubview:rtv];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return self.tabBarController.tabBar.bounds.size.height;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:self.leftCellIdent];
    
    if (!cell) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.leftCellIdent];
    }
    
    NSString *key=[[NSString alloc] initWithFormat:@"%lu", indexPath.row+1];
    cell.textLabel.text=[self.typeData objectForKey:key];
    [cell.textLabel setTextColor:[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f]];
    [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
    [cell setBackgroundColor:[UIColor clearColor]];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"click: %ld, %@", indexPath.row, [self.typeData objectForKey:[NSString stringWithFormat:@"%ld", indexPath.row+1]]);
    //点击事件
#warning shouye_shiwu_left_tableview_click
}

@end
