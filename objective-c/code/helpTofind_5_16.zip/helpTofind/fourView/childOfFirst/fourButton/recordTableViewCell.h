//
//  recordTableViewCell.h
//  helpTofind
//
//  Created by rdt on 2019/5/15.
//  Copyright © 2019 电脑. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface recordTableViewCell : UITableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame;

@end

NS_ASSUME_NONNULL_END
