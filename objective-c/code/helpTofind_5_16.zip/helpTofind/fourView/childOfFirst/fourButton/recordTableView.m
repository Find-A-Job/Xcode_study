//
//  recordTableView.m
//  helpTofind
//
//  Created by rdt on 2019/5/15.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "recordTableView.h"
#import "recordTableViewCell.h"

@interface recordTableView() <UITableViewDelegate, UITableViewDataSource>

//cellIdent
@property(strong, nonatomic) NSString *cellIdent;

@end

@implementation recordTableView


-(instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    self=[super initWithFrame:frame style:style];
    
    
    //
    self.cellIdent=@"cellIdentRecord";
    self.delegate=self;
    self.dataSource=self;
    
    
    //去掉分割线
    self.separatorColor=[UIColor clearColor];
    
    //背景透明
    self.backgroundColor=[UIColor clearColor];
    
    //额外滚动区域
    [self setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];
    
    //取消右侧滚动条
    [self setShowsVerticalScrollIndicator:NO];
    
    
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

//delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 400;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    recordTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[recordTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent frame:tableView.bounds];
    }
    
    
    
    NSLog(@"table.frame:%f, %f, %f, %f", tableView.frame.origin.x, tableView.frame.origin.y, tableView.frame.size.width, tableView.frame.size.height);
    
    return cell;
}

@end
