//
//  newNewsCell.m
//  helpTofind
//
//  Created by rdt on 2019/5/7.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "newNewsCell.h"

@implementation newNewsCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    
    //name
    UILabel *name=[[UILabel alloc] initWithFrame:CGRectMake(4, 5, 60, 20)];
    [name setTextColor:shenlan];
    [name setFont:[UIFont systemFontOfSize:16]];
    [name setTextAlignment:NSTextAlignmentRight];
    [self addSubview:name];
    self.labName=name;
    
    //title
    UILabel *title=[[UILabel alloc] initWithFrame:CGRectMake(name.frame.origin.x+name.frame.size.width+5, name.frame.origin.y, 100, name.frame.size.height)];
    [title setTextColor:shenlan];
    [title setFont:[UIFont systemFontOfSize:16]];
    [self addSubview:title];
    self.labTitle=title;
    
    //time
    UILabel *timeDate=[[UILabel alloc] initWithFrame:CGRectMake(title.frame.origin.x+title.frame.size.width+5, name.frame.origin.y, 330-title.frame.origin.x-title.frame.size.width-25, name.frame.size.height)];
    [timeDate setTextColor:qianhui];
    [timeDate setFont:[UIFont systemFontOfSize:16]];
    [self addSubview:timeDate];
    self.labTime=timeDate;
    
    
    //取消选中状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return self;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
