//
//  dropListCell.m
//  helpTofind
//
//  Created by rdt on 2019/5/9.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "dropListCell.h"

@implementation dropListCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    if (self) {
        //self.textLabel.text=@"其他";
        self.textLabel.textColor=qianlan;
    }
    
    
    return self;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier rect:(CGRect)r{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    if (self) {
        self.frame=r;
        //self.textLabel.text=@"其他1";
        self.textLabel.textColor=qianlan;
    }
    
    
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
