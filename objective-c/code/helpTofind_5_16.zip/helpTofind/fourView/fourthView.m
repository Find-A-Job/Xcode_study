//
//  fourthView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "fourthView.h"
#import "zxCell.h"
#import "articleDetails.h"

@interface fourthView() <UITableViewDelegate, UITableViewDataSource>

//cell重用标识
@property(nonatomic) NSString *cellInedt;

//展示的数据
@property(strong, nonatomic) NSDictionary *dataOfShow;

//
-(void)goToArticleDetails:(id)sender;

@end

@implementation fourthView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //部分数据初始化
    self.cellInedt=@"cellForZX";
    
    //静态测试数据，可注释掉
    NSDictionary *dt1=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu1", @"image", @"title1", @"title", @"a", @"author", @"2019-1-1", @"date", nil];
    NSDictionary *dt2=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu2", @"image", @"title2", @"title", @"b", @"author", @"2019-2-1", @"date", nil];
    NSDictionary *dt3=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu3", @"image", @"title3", @"title", @"c", @"author", @"2019-3-1", @"date", nil];
    NSDictionary *dt4=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu4", @"image", @"title4", @"title", @"d", @"author", @"2019-4-1", @"date", nil];
    NSDictionary *dt5=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu5", @"image", @"title5", @"title", @"e", @"author", @"2019-5-1", @"date", nil];
    
    NSArray *allDataArr=@[dt1, dt2, dt3, dt4, dt5];
    NSDictionary *alldataDic=[[NSDictionary alloc] initWithObjectsAndKeys:allDataArr, @"data", nil];
    self.dataOfShow=alldataDic;
    
    //背景
    CGFloat bkViewY=self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height;
    CGFloat bkViewWidth=self.navigationController.navigationBar.frame.size.width;
    CGFloat bkViewHeight=[self.uzd getTabbarRect].origin.y-bkViewY;
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bkViewWidth, bkViewHeight)];
    [self.view addSubview:bkView];
    [bkView setImage:[UIImage imageNamed:@"di.png"]];
    [bkView setUserInteractionEnabled:YES];
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //尺寸
    CGSize screenSize=CGSizeMake([[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    CGFloat leftSpacing=10;
    CGFloat upSpacing=20;
    CGPoint tableViewPoint=CGPointMake(leftSpacing, upSpacing);
    CGSize tableViewSize=CGSizeMake(screenSize.width-2*leftSpacing, screenSize.height);
    
    //主
    UITableView *mainTableView=[[UITableView alloc] initWithFrame:CGRectMake(tableViewPoint.x, tableViewPoint.y, tableViewSize.width, tableViewSize.height) style:UITableViewStylePlain];
    [bkView addSubview:mainTableView];
    [mainTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];//去分割线
    [mainTableView setShowsVerticalScrollIndicator:NO];//隐藏右侧滚动条
    [mainTableView setDelegate:self];
    [mainTableView setDataSource:self];
    [mainTableView setBackgroundColor:[UIColor clearColor]];
    [mainTableView setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];//增加额外滚动范围
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number=0;
    if (section==0) {
        NSArray *arr=[self.dataOfShow objectForKey:@"data"];
        number=(NSInteger)[arr count];
    }
    
    
    return number;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 150;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    zxCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellInedt];
    
    if(!cell){
        cell=[[zxCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellInedt];
    }
    NSArray *arr=[self.dataOfShow objectForKey:@"data"];
    [cell.leftImg setImage:[UIImage imageNamed:[arr[indexPath.row] objectForKey:@"image"]]];
    //[cell.leftImg setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:@""]]]];
    cell.titleLabel.text=[arr[indexPath.row] objectForKey:@"title"];
    cell.authorLabel.text=[arr[indexPath.row] objectForKey:@"author"];
    cell.dateLabel.text=[arr[indexPath.row] objectForKey:@"date"];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    articleDetails *ad=[[articleDetails alloc] init];
    [self.navigationController pushViewController:ad animated:YES];
}

-(void)goToArticleDetails:(id)sender{
    articleDetails *ad=[[articleDetails alloc] init];
    [self.navigationController pushViewController:ad animated:YES];
}
@end
