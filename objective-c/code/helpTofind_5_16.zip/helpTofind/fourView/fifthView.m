//
//  fifthView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "fifthView.h"
#import "wdshiwu.h"
#import "wdzhaoling.h"
#import "wdxiaoxi.h"
#import "wdziliao.h"
#import "userzmxDelegate.h"

@interface fifthView() <userzmxDegelate>

//按钮
@property(strong, nonatomic) UIButton *b1;
@property(strong, nonatomic) UIButton *b2;
@property(strong, nonatomic) UIButton *b3;
@property(strong, nonatomic) UIButton *b4;

//按钮响应事件
-(void)b1Click:(id)sender;
-(void)b2Click:(id)sender;
-(void)b3Click:(id)sender;
-(void)b4Click:(id)sender;

@end

@implementation fifthView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //背景
    CGFloat bkViewY=self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height;
    CGFloat bkViewWidth=self.navigationController.navigationBar.frame.size.width;
    CGFloat bkViewHeight=[self.uzd getTabbarRect].origin.y-bkViewY;
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bkViewWidth, bkViewHeight)];
    [self.view addSubview:bkView];
    [bkView setImage:[UIImage imageNamed:@"di.png"]];
    
    //
    CGFloat buttonWidth=360;
    CGFloat buttonHeight=120;
    CGFloat startY=0;
    CGFloat buttonX=8;
    CGFloat spacingOfButton=5;
    CGFloat b1y=startY;
    CGFloat b2y=startY+buttonHeight+spacingOfButton;
    CGFloat b3y=startY+2*(buttonHeight+spacingOfButton);
    CGFloat b4y=startY+3*(buttonHeight+spacingOfButton);
    
    //我的失物
    UIButton *wdsw=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b1y, buttonWidth, buttonHeight)];
    self.b1=wdsw;
    [wdsw setBackgroundImage:[UIImage imageNamed:@"wdswuBK.png"] forState:UIControlStateNormal];
    [wdsw setBackgroundImage:[UIImage imageNamed:@"wdswuBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdsw];
    [wdsw setTitle:@"我的失物" forState:UIControlStateNormal];
    [wdsw setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdsw addTarget:self action:@selector(b1Click:) forControlEvents:UIControlEventTouchUpInside];
    
    //我的招领
    UIButton *wdzliao=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b2y, buttonWidth, buttonHeight)];
    self.b2=wdzliao;
    [wdzliao setBackgroundImage:[UIImage imageNamed:@"wdzlingBK.png"] forState:UIControlStateNormal];
    [wdzliao setBackgroundImage:[UIImage imageNamed:@"wdzlingBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdzliao];
    [wdzliao setTitle:@"我的招领" forState:UIControlStateNormal];
    [wdzliao setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdzliao addTarget:self action:@selector(b2Click:) forControlEvents:UIControlEventTouchUpInside];
    
    //我的消息
    UIButton *wdxx=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b3y, buttonWidth, buttonHeight)];
    self.b3=wdxx;
    [wdxx setBackgroundImage:[UIImage imageNamed:@"wdxxiBK.png"] forState:UIControlStateNormal];
    [wdxx setBackgroundImage:[UIImage imageNamed:@"wdxxiBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdxx];
    [wdxx setTitle:@"我的消息" forState:UIControlStateNormal];
    [wdxx setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdxx addTarget:self action:@selector(b3Click:) forControlEvents:UIControlEventTouchUpInside];
    
    //我的资料
    UIButton *wdzl=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b4y, buttonWidth, buttonHeight)];
    self.b4=wdzl;
    [wdzl setBackgroundImage:[UIImage imageNamed:@"wdzliaoBK.png"] forState:UIControlStateNormal];
    [wdzl setBackgroundImage:[UIImage imageNamed:@"wdzliaoBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdzl];
    [wdzl setTitle:@"我的资料" forState:UIControlStateNormal];
    [wdzl setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdzl addTarget:self action:@selector(b4Click:) forControlEvents:UIControlEventTouchUpInside];
}
-(void)b1Click:(id)sender{
    wdshiwu *wd=[[wdshiwu alloc] init];
    
    [self.navigationController pushViewController:wd animated:YES];
}
-(void)b2Click:(id)sender{
    wdzhaoling *wd=[[wdzhaoling alloc] init];
    [self.navigationController pushViewController:wd animated:YES];
}
-(void)b3Click:(id)sender{
    wdxiaoxi *wd=[[wdxiaoxi alloc] init];
    [self.navigationController pushViewController:wd animated:YES];
}
-(void)b4Click:(id)sender{
    wdziliao *wd=[[wdziliao alloc] init];
    wd.uzd=self;
    [self.navigationController pushViewController:wd animated:YES];
}
-(CGRect)getTabbarRect{
    return [self.uzd getTabbarRect];
}
@end
