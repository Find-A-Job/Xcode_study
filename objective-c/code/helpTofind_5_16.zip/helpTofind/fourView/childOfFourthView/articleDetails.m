//
//  articleDetails.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/18.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "articleDetails.h"

@interface articleDetails()

@end

@implementation articleDetails

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //设置标题
    self.navigationItem.title=@"文章详情";
    
    //设置背景
    UIImageView *bkImgView=[[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:bkImgView];
    [bkImgView setImage:[UIImage imageNamed:@"di.png"]];
    
    //文章视图背景
    UIImageView *textBK=[[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 355, 480)];
    [textBK setImage:[UIImage imageNamed:@"at_di.png"]];
    [self.view addSubview:textBK];
    [textBK setUserInteractionEnabled:YES];
    
    //文章
    UITextView *ut=[[UITextView alloc] initWithFrame:CGRectMake(20, 50, 315, 380)];
    [textBK addSubview:ut];
    //[ut setBackgroundColor:[UIColor blueColor]];
    [ut setText:@"2019-04-19 11:56:47.498382+0800 helpTofind[7864:975474] [MC] System group container for systemgroup.com.apple.configurationprofiles path is /private/var/containers/Shared/SystemGroup/systemgroup.com.apple.configurationprofiles\
     2019-04-19 11:56:47.501979+0800 helpTofind[7864:975474] [MC] Reading from public effective user settings."];
    
    //字体大小, 24
    [ut setFont:[UIFont systemFontOfSize:20]];
    
    //不可编辑
    [ut setEditable:NO];
}
@end
