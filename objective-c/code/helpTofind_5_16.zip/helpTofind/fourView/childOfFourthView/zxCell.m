//
//  zxCell.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/18.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "zxCell.h"

@interface zxCell()


@end

@implementation zxCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    //视图上的imgview和label留着不删
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //添加控件, 一个uiimage和三个uilabel
    CGFloat spacingBetweenLeftAndRight=15;
    CGFloat spacingBetweenUpAndDown=20;
    CGFloat cellHeight=150;
    
    CGPoint imgXY=CGPointMake(spacingBetweenLeftAndRight, spacingBetweenUpAndDown);
    CGSize  imgSize=CGSizeMake(100, cellHeight-2*spacingBetweenUpAndDown);
    
    CGPoint titleXY=CGPointMake(imgXY.x+imgSize.width+spacingBetweenLeftAndRight, spacingBetweenUpAndDown+10);
    CGSize  titleSize=CGSizeMake(self.frame.size.width-titleXY.x-spacingBetweenLeftAndRight, 35);
    
    CGSize  authorSize=CGSizeMake(titleSize.width/2-spacingBetweenLeftAndRight, titleSize.height-10);
    CGPoint authorXY=CGPointMake(titleXY.x, cellHeight-spacingBetweenUpAndDown-authorSize.height);
    
    CGSize  dateSize=CGSizeMake(authorSize.width, authorSize.height);
    CGPoint dateXY=CGPointMake(authorXY.x+authorSize.width+spacingBetweenLeftAndRight*2, authorXY.y);
    
    //创建控件
    self.leftImg=[[UIImageView alloc] initWithFrame:CGRectMake(imgXY.x, imgXY.y, imgSize.width, imgSize.height)];
    self.titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(titleXY.x, titleXY.y, titleSize.width, titleSize.height)];
    self.authorLabel=[[UILabel alloc] initWithFrame:CGRectMake(authorXY.x, authorXY.y, authorSize.width, authorSize.height)];
    self.dateLabel=[[UILabel alloc] initWithFrame:CGRectMake(dateXY.x, dateXY.y, dateSize.width, dateSize.height)];
    
    //占位，可注释掉
//    [self.leftImg setImage:[UIImage imageNamed:@"tu1.png"]];
//    self.titleLabel.backgroundColor=[UIColor blackColor];
//    self.authorLabel.backgroundColor=[UIColor blackColor];
//    self.dateLabel.backgroundColor=[UIColor blackColor];
    
    //字体颜色
    [self.titleLabel setTextColor:qianhui];
    [self.authorLabel setTextColor:qianhui];
    [self.dateLabel setTextColor:qianhui];
    
    //加入视图中
    [self addSubview:self.leftImg];
    [self addSubview:self.titleLabel];
    [self addSubview:self.authorLabel];
    [self addSubview:self.dateLabel];
    
    //背景色毛玻璃效果
    [self setBackgroundColor:[UIColor clearColor]];
    //设置背景视图
    [self setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"zx_di.png"]]];
    
    //显示箭头
    [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    //点击不会变为高亮状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return self;
}

@end
