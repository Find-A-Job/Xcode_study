//
//  firstView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "firstView.h"
#import "childOfFirst/newNewsCell.h"
#import "childOfFirst/fabuView.h"
#import "childOfFirst/fourButton/recordViewController.h"
#import "childOfFirst/singleRecordVC.h"

@interface firstView() <UITableViewDelegate, UITableViewDataSource>

//ident
@property(strong, nonatomic) NSString *cellIdent;

//data
@property(strong, nonatomic) NSDictionary *showData;

//viewController lost
@property(strong, nonatomic) recordViewController *lostRecordVC;

//viewController find
@property(strong, nonatomic) recordViewController *findRecordVC;

//viweController singleRecord
@property(strong, nonatomic) singleRecordVC *singleRecVC;

-(void)showRect:(CGRect)r;

//button
-(void)clickSWJLU:(id)sender;
-(void)clickFBSWU:(id)sender;
-(void)clickZLJLU:(id)sender;
-(void)clickFBZLING:(id)sender;

@end

@implementation firstView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //
    self.cellIdent=@"cell3";
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //静态数据
    NSDictionary *data1=[[NSDictionary alloc] initWithObjectsAndKeys:@"小雨", @"name", @"丢失校园卡", @"title", @"2018-12-26", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data2=[[NSDictionary alloc] initWithObjectsAndKeys:@"啊方", @"name", @"手机", @"title", @"2018-10-23", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data3=[[NSDictionary alloc] initWithObjectsAndKeys:@"飞飞", @"name", @"钥匙串丢了", @"title", @"2018-10-2", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data4=[[NSDictionary alloc] initWithObjectsAndKeys:@"欧阳", @"name", @"身份证", @"title", @"2018-8-9", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data5=[[NSDictionary alloc] initWithObjectsAndKeys:@"东东", @"name", @"公交卡丢了", @"title", @"2018-6-20", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data6=[[NSDictionary alloc] initWithObjectsAndKeys:@"大牛", @"name", @"一本手册", @"title", @"2018-5-12", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data7=[[NSDictionary alloc] initWithObjectsAndKeys:@"跳跳鱼", @"name", @"一支钢笔", @"title", @"2018-4-24", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data8=[[NSDictionary alloc] initWithObjectsAndKeys:@"飞翔海鸥", @"name", @"一件粉色外套", @"title", @"2018-3-29", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data9=[[NSDictionary alloc] initWithObjectsAndKeys:@"piupiupiu", @"name", @"儿童玩具", @"title", @"2018-1-27", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSDictionary *data10=[[NSDictionary alloc] initWithObjectsAndKeys:@"神乎其技", @"name", @"手电筒", @"title", @"2018-1-2", @"time", @"2018-03-04", @"lostTime", @"湖南省永州市零陵区德财路", @"place", @"卡包", @"type", nil];
    NSArray *allData=@[data1, data2, data3, data4, data5, data6, data7, data8, data9, data10];
    NSDictionary *dicData=[[NSDictionary alloc] initWithObjectsAndKeys:allData, @"data", nil];
    self.showData=dicData;

    //背景滚动视图
    UIScrollView *baseScrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    [self.view addSubview:baseScrollView];
    [baseScrollView setContentSize:CGSizeMake(0, winHeight+150)];//设置滚动范围
    [baseScrollView setShowsVerticalScrollIndicator:NO];//不显示垂直滚动条
    //[baseScrollView setBounces:NO];//取消弹簧效果
    
    
    
    //背景视图
    UIView *baseView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, winWidth, baseScrollView.contentSize.height+20)];
    [baseScrollView addSubview:baseView];
    UIImage *bkImg=[UIImage imageNamed:@"shouYebg.png"];
    bkImg=[bkImg stretchableImageWithLeftCapWidth:bkImg.size.width*0.3f topCapHeight:bkImg.size.height*0.3f];
    UIImageView *bkImgView=[[UIImageView alloc] initWithFrame:baseView.bounds];
    bkImgView.image=bkImg;
    [baseView addSubview:bkImgView];
    
    
    
    
    
    //轮播图视图 378x197
    UIView *showImageView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, winWidth, 200)];
    [baseView addSubview:showImageView];
    [showImageView setBackgroundColor:[UIColor clearColor]];
    
    CGFloat midImgViewWidth=350;
    CGFloat leftOffset1=(winWidth-midImgViewWidth)/2;
    CGRect midImgVIewRect=CGRectMake((winWidth-midImgViewWidth)/2, 1, midImgViewWidth, 198);
    UIImageView *midImgView=[[UIImageView alloc] initWithFrame:midImgVIewRect];
    UIImage *img1=[UIImage imageNamed:@"shiwuzhaoling.png"];
    midImgView.image=img1;
    [showImageView addSubview:midImgView];
    
    CGRect leftImgViewRect=CGRectMake(0, 0, midImgView.bounds.size.width/5*4, midImgView.bounds.size.height/5*4);
    UIImageView *leftImgView=[[UIImageView alloc] initWithFrame:leftImgViewRect];
    leftImgView.center=midImgView.center;
    CGRect newFrame1=leftImgView.frame;
    newFrame1.origin.x=0-leftImgView.bounds.size.width+(leftOffset1<=0?0:leftOffset1)+4;
    leftImgView.frame=newFrame1;
    [leftImgView setImage:[UIImage imageNamed:@"shiwuzhaoling.png"]];
    [showImageView addSubview:leftImgView];
    
    UIImageView *rightImgView=[[UIImageView alloc] initWithFrame:leftImgViewRect];
    rightImgView.center=midImgView.center;
    newFrame1=rightImgView.frame;
    newFrame1.origin.x=winWidth-(leftOffset1<=0?0:leftOffset1)-4;
    rightImgView.frame=newFrame1;
    [rightImgView setImage:[UIImage imageNamed:@"shiwuzhaoling.png"]];
    [showImageView addSubview:rightImgView];
    
    
    
    //快捷按钮视图
    UIView *buttonView=[[UIView alloc] initWithFrame:CGRectMake(0, showImageView.frame.origin.y+showImageView.bounds.size.height, winWidth, 120)];
    [baseView addSubview:buttonView];
    bkImg=[UIImage imageNamed:@"buttonViewBk.png"];
    bkImg=[bkImg stretchableImageWithLeftCapWidth:bkImg.size.width*0.3f topCapHeight:bkImg.size.height*0.3f];
    bkImgView=[[UIImageView alloc] initWithFrame:buttonView.bounds];
    bkImgView.image=bkImg;
    [buttonView addSubview:bkImgView];
    
    CGSize imgSize=CGSizeMake(80, 80);
    CGSize labelSize=CGSizeMake(imgSize.width, 20);
    CGFloat leftOffset=(winWidth-4*imgSize.width-3*10)/2;
    
    UIButton *imgViewSwjlu=[[UIButton alloc] initWithFrame:CGRectMake(leftOffset, 10, imgSize.width, imgSize.height)];
    UILabel *labSwjlu=[[UILabel alloc] initWithFrame:CGRectMake(imgViewSwjlu.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    UIButton *imgViewFbswu=[[UIButton alloc] initWithFrame:CGRectMake(imgViewSwjlu.frame.origin.x+imgSize.width+10, 10, imgSize.width, imgSize.height)];
    UILabel *labFbswu=[[UILabel alloc] initWithFrame:CGRectMake(imgViewFbswu.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    UIButton *imgViewZljlu=[[UIButton alloc] initWithFrame:CGRectMake(imgViewFbswu.frame.origin.x+imgSize.width+10, 10, imgSize.width, imgSize.height)];
    UILabel *labZljlu=[[UILabel alloc] initWithFrame:CGRectMake(imgViewZljlu.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    UIButton *imgViewFbzling=[[UIButton alloc] initWithFrame:CGRectMake(imgViewZljlu.frame.origin.x+imgSize.width+10, 10, imgSize.width, imgSize.height)];
    UILabel *labFbzling=[[UILabel alloc] initWithFrame:CGRectMake(imgViewFbzling.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    
    UIImage *img2=[UIImage imageNamed:@"shiwujilu.png"];
    [imgViewSwjlu setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewSwjlu.image=img2;
    img2=[UIImage imageNamed:@"fabushiwu.png"];
    [imgViewFbswu setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewFbswu.image=img2;
    img2=[UIImage imageNamed:@"zhaolingjilu.png"];
    [imgViewZljlu setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewZljlu.image=img2;
    img2=[UIImage imageNamed:@"fabuzhaoling.png"];
    [imgViewFbzling setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewFbzling.image=img2;
    
    [imgViewSwjlu addTarget:self action:@selector(clickSWJLU:) forControlEvents:UIControlEventTouchUpInside];
    [imgViewFbswu addTarget:self action:@selector(clickFBSWU:) forControlEvents:UIControlEventTouchUpInside];
    [imgViewZljlu addTarget:self action:@selector(clickZLJLU:) forControlEvents:UIControlEventTouchUpInside];
    [imgViewFbzling addTarget:self action:@selector(clickFBZLING:) forControlEvents:UIControlEventTouchUpInside];
    
    [labSwjlu setText:@"失物记录"];
    [labFbswu setText:@"发布失物"];
    [labZljlu setText:@"招领记录"];
    [labFbzling setText:@"发布招领"];
    
    [labSwjlu setTextColor:qianlan];
    [labFbswu setTextColor:qianlan];
    [labZljlu setTextColor:qianlan];
    [labFbzling setTextColor:qianlan];
    
    [labSwjlu setFont:[UIFont systemFontOfSize:14]];
    [labFbswu setFont:[UIFont systemFontOfSize:14]];
    [labZljlu setFont:[UIFont systemFontOfSize:14]];
    [labFbzling setFont:[UIFont systemFontOfSize:14]];
    
    [labSwjlu setTextAlignment:NSTextAlignmentCenter];
    [labFbswu setTextAlignment:NSTextAlignmentCenter];
    [labZljlu setTextAlignment:NSTextAlignmentCenter];
    [labFbzling setTextAlignment:NSTextAlignmentCenter];
    
    [buttonView addSubview:imgViewSwjlu];
    [buttonView addSubview:labSwjlu];
    [buttonView addSubview:imgViewFbswu];
    [buttonView addSubview:labFbswu];
    [buttonView addSubview:imgViewZljlu];
    [buttonView addSubview:labZljlu];
    [buttonView addSubview:imgViewFbzling];
    [buttonView addSubview:labFbzling];
    
    
    //最新信息视图
    UIView *newMsgView=[[UIView alloc] initWithFrame:CGRectMake(0, buttonView.frame.origin.y+buttonView.frame.size.height, winWidth, 370)];
    [baseView addSubview:newMsgView];
    bkImg=[UIImage imageNamed:@"msgViewBk.png"];
    bkImg=[bkImg stretchableImageWithLeftCapWidth:bkImg.size.width*0.3f topCapHeight:bkImg.size.height*0.3f];
    bkImgView=[[UIImageView alloc] initWithFrame:newMsgView.bounds];
    bkImgView.image=bkImg;
    [newMsgView addSubview:bkImgView];
    
    CGFloat tableViewWidth=330;
    CGFloat leftOffset3=(winWidth-tableViewWidth)/2;
    UIImageView *shugang=[[UIImageView alloc] initWithFrame:CGRectMake(leftOffset3, 20, 4, 20)];
    UILabel *labzxxx=[[UILabel alloc] initWithFrame:CGRectMake(shugang.frame.origin.x+shugang.frame.size.width+2, shugang.frame.origin.y, 100, shugang.frame.size.height)];
    
    UIImage *img3=[UIImage imageNamed:@"xiaoXiBiaoZhi.png"];
    shugang.image=img3;
    [labzxxx setTextColor:qianlan];
    [labzxxx setText:@"最新信息"];
    [labzxxx setFont:[UIFont systemFontOfSize:20]];
    
    [newMsgView addSubview:shugang];
    [newMsgView addSubview:labzxxx];
    
    UITableView *nnShow=[[UITableView alloc] initWithFrame:CGRectMake(leftOffset3, shugang.frame.origin.y+shugang.frame.size.height+5, tableViewWidth, newMsgView.bounds.size.height-shugang.frame.origin.y-shugang.frame.size.height-15) style:UITableViewStylePlain];
    [newMsgView addSubview:nnShow];
    [nnShow setSeparatorStyle:UITableViewCellSeparatorStyleNone];//去分割线
    [nnShow setShowsVerticalScrollIndicator:NO];//隐藏右侧滚动条
    [nnShow setDelegate:self];
    [nnShow setDataSource:self];
    [nnShow setBackgroundColor:[UIColor clearColor]];
    //[nnShow setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];//增加额外滚动范围
}

-(void)showRect:(CGRect)r{
    //NSLog(@"x=%f, y=%f, height=%f, width=%f", r.origin.x, r.origin.y, r.size.height, r.size.width);
}

//button
-(void)clickSWJLU:(id)sender{
    NSLog(@"失物记录");
    UIViewController *swjlhere=[self getLostRecordVC];
    swjlhere.navigationItem.title=@"失物记录";
    [self.navigationController pushViewController:swjlhere animated:YES];
}
-(void)clickFBSWU:(id)sender{
    NSLog(@"发布失物");
    UIViewController *fbswhere=[self.fDele getFabuView];
    fbswhere.navigationItem.title=@"发布失物";
    [self.navigationController pushViewController:fbswhere animated:YES];
}
-(void)clickZLJLU:(id)sender{
    NSLog(@"招领记录");
    UIViewController *zljlhere=[self getFindRecordVC];
    zljlhere.navigationItem.title=@"招领记录";
    [self.navigationController pushViewController:zljlhere animated:YES];
}
-(void)clickFBZLING:(id)sender{
    NSLog(@"发布招领");
    UIViewController *fbzlhere=[self.fDele getZhaoLingView];
    fbzlhere.navigationItem.title=@"发布招领";
    //[self.navigationController pushViewController:[self.fDele getZhaoLingView] animated:YES];
    [self.navigationController pushViewController:fbzlhere animated:YES];
}

//delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    newNewsCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[newNewsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    
    //
    NSArray *allData=[self.showData objectForKey:@"data"];
    
    //name
    cell.labName.text=[allData[indexPath.row] objectForKey:@"name"];
    
    //title
    cell.labTitle.text=[allData[indexPath.row] objectForKey:@"title"];
    
    //time
    cell.labTime.text=[allData[indexPath.row] objectForKey:@"time"];
    
    return  cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger num=indexPath.row;
    
    //cell选中时跳转操作
    singleRecordVC *srvc=[self getSingleRecordVC];
    NSArray *arr=[self.showData objectForKey:@"data"];
    srvc.singleRecordData=arr[num];
    [self.navigationController pushViewController:srvc animated:YES];
}



//VC
-(id)getLostRecordVC{
    if (!self.lostRecordVC) {
        self.lostRecordVC=[[recordViewController alloc] init];
    }
    
    return self.lostRecordVC;
}
-(id)getFindRecordVC{
    if (!self.findRecordVC) {
        self.findRecordVC=[[recordViewController alloc] init];
    }
    
    return self.findRecordVC;
}
-(id)getSingleRecordVC{
    if(!self.singleRecVC){
        self.singleRecVC=[[singleRecordVC alloc] init];
    }
    
    return self.singleRecVC;
}



@end
