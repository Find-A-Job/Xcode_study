//
//  xuanshangTableView.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/26.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "cellOfxs/clickCommentDelegate.h"

@interface xuanshangTableView : UITableViewController


//弹起键盘和编辑框
@property(weak, nonatomic) id<clickCommentDelegate> commentDelegate;

@end
