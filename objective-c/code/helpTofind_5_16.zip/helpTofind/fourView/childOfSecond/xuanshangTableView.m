//
//  xuanshangTableView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/26.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "xuanshangTableView.h"
#import "cellOfxs.h"

@interface xuanshangTableView() <UITableViewDelegate, UITableViewDataSource, clickCommentDelegate>

//cell标识
@property(strong, nonatomic) NSString *cellIdent;

//data
@property(strong, nonatomic) NSDictionary *showData;

@end

@implementation xuanshangTableView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //
    self.cellIdent=@"cellOfxuanshang";
    
    //静态数据，可注释掉
    NSDictionary *t1=[NSDictionary dictionaryWithObjectsAndKeys:@"丢球丢球", @"title", @"王得分", @"userName", @"2019-1-1", @"publishDate",@"2018-1-1", @"loseDate",@"福建省厦门市思明区", @"place",@"其他", @"tag",@"70", @"money",@"13611111111", @"tel", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t2=[NSDictionary dictionaryWithObjectsAndKeys:@"手弓锯", @"title", @"刘师傅", @"userName", @"2019-2-1", @"publishDate",@"2018-2-1", @"loseDate",@"福建省厦门市思明区", @"place",@"工具", @"tag",@"0", @"money",@"13622222222", @"tel", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t3=[NSDictionary dictionaryWithObjectsAndKeys:@"语文课本", @"title", @"朴老师", @"userName", @"2019-3-1", @"publishDate",@"2018-3-1", @"loseDate",@"福建省厦门市思明区", @"place",@"书籍", @"tag",@"10", @"money",@"13633333333", @"tel", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t4=[NSDictionary dictionaryWithObjectsAndKeys:@"散文诗丢了", @"title", @"沈丛文", @"userName", @"2019-4-1", @"publishDate",@"2018-4-1", @"loseDate",@"福建省厦门市思明区", @"place",@"书籍", @"tag",@"100", @"money",@"13644444444", @"tel", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t5=[NSDictionary dictionaryWithObjectsAndKeys:@"颠勺丢了", @"title", @"锅得钢", @"userName", @"2019-5-1", @"publishDate",@"2018-5-1", @"loseDate",@"福建省厦门市思明区", @"place",@"工具", @"tag",@"40", @"money",@"13655555555", @"tel", @"ka.png", @"img", @"0", @"state",nil];
    NSArray *arr=@[t1, t2, t3, t4, t5];
    self.showData=[[NSDictionary alloc] initWithObjectsAndKeys:arr, @"data", nil];
    
    //设置坐标
    [self.tableView setFrame:CGRectMake(0, 50, [[UIApplication sharedApplication] statusBarFrame].size.width, 600)];
    
    //背景透明
    [self.tableView setBackgroundColor:[UIColor clearColor]];
    
    //增加额外滚动区域
    [self.tableView setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];
    
    //去分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    //隐藏右侧滚动条
    [self.tableView setShowsVerticalScrollIndicator:NO];
    
}

//代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number=0;
    
    NSArray *arr=[self.showData objectForKey:@"data"];
    number=arr.count;
    
    return number;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat gao=600;
    
    return  gao;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    cellOfxs *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[cellOfxs alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    cell.commentDelegate=self;
    
    NSDictionary *nsd=((NSArray *)[self.showData objectForKey:@"data"])[indexPath.row];
    //标题
    cell.l1.text=[nsd objectForKey:@"title"];
    
    //用户
    cell.l2.text=[nsd objectForKey:@"userName"];
    
    //发布时间
    cell.l3.text=[NSString stringWithFormat:@"%@  发布", [nsd objectForKey:@"publishDate"]];
    
    //丢失/寻找时间
    cell.l4.text=[nsd objectForKey:@"loseDate"];
    
    //地址
    cell.l5.text=[nsd objectForKey:@"place"];
    
    //类型
    cell.l6.text=[nsd objectForKey:@"tag"];
    
    //赏金
    NSString *moneyValue=[nsd objectForKey:@"money"];
    if ([moneyValue isEqualToString:@"0"]) {
        [cell.l7 setHidden:YES];
        [cell.u2 setHidden:YES];
    }else{
        [cell.l7 setHidden:NO];
        [cell.u2 setHidden:NO];
        cell.l7.text=[NSString stringWithFormat:@"%@赏金", moneyValue];
    }
    
    //上传的图片
    [cell.u1 setImage:[UIImage imageNamed:[nsd objectForKey:@"img"]]];
    
    //额外的信息
    cell.tel.tag=(indexPath.row+10)*10;
    cell.msg.tag=(indexPath.row+11)*10;
    cell.comment.tag=(indexPath.row+12)*10;
    
    return cell;
}
-(void)showKeyboard{
    [self.commentDelegate showKeyboard];
}
-(NSString *)getPhoneNumber:(NSInteger)indexPath{
    NSDictionary *nsd=((NSArray *)[self.showData objectForKey:@"data"])[indexPath];
    NSString *telNumber=[nsd objectForKey:@"tel"];
    
    return telNumber;
}

@end
