//
//  cellOfxs.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/26.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "cellOfxs.h"

@interface cellOfxs()

//功能按钮回调
-(void)telClick:(id)sender;
-(void)msgClick:(id)sender;
-(void)commentClick:(id)sender;

@end

@implementation cellOfxs

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    //界面表示
    /*
     
     |++++++++++++++++++++++++++++++++++++++++
     |title/label                            |
     |userName/label           money/label   |
     |dateOfPublish/label                    |
     |                                       |
     |dateOfLose/img   dateOfLose/label      |
     |placeOfLose/img  placeOfLose/label     |
     |tag/img          tag/label             |
     |                                       |
     |imgOfLose/img                          |
     |                                       |
     |_______________________________________|
     |                                       |
     |tel/btn  msg/btn   comment/btn         |
     |_______________________________________|
     
     */
    if(self){
        NSLog(@"\ncell,,,Width:%f ,Height:%f", [self frame].size.width, [self frame].size.height);
        //尺寸坐标
        CGFloat spacingBetweenLeftAndRight=35;
        CGFloat spacingBetweenTopAndBottom=20;
        CGSize  imgSize=CGSizeMake(23, 26);
        CGSize  imgSizeHuge=CGSizeMake(300, 200);
        CGSize  imgSizeBtn=CGSizeMake(30, 25);
        CGSize  imgSizeXian=CGSizeMake([[UIApplication sharedApplication] statusBarFrame].size.width-40, 1);
        
        CGRect titleRect        = CGRectMake(spacingBetweenLeftAndRight, spacingBetweenTopAndBottom, 200, 50);
        CGRect userNameRect     = CGRectMake(titleRect.origin.x, titleRect.origin.y+titleRect.size.height+5, titleRect.size.width, titleRect.size.height-10);
        CGRect dateOfPublish    = CGRectMake(titleRect.origin.x, userNameRect.origin.y+userNameRect.size.height+3, titleRect.size.width, userNameRect.size.height-10);
        
        CGRect dateOfLoseImg    = CGRectMake(titleRect.origin.x, dateOfPublish.origin.y+dateOfPublish.size.height+6, imgSize.width, imgSize.height);
        CGRect dateOfLose       = CGRectMake(dateOfLoseImg.origin.x+dateOfLoseImg.size.width+3, dateOfLoseImg.origin.y+1, titleRect.size.width, imgSize.height-2);
        
        CGRect placeOfLoseImg   = CGRectMake(dateOfLoseImg.origin.x, dateOfLoseImg.origin.y+dateOfLose.size.height+4, imgSize.width, imgSize.height);
        CGRect placeOfLose      = CGRectMake(dateOfLose.origin.x, placeOfLoseImg.origin.y+1, titleRect.size.width, imgSize.height-2);
        
        CGRect tagImg           = CGRectMake(dateOfLoseImg.origin.x, placeOfLoseImg.origin.y+placeOfLose.size.height+4, imgSize.width, imgSize.height);
        CGRect tag              = CGRectMake(dateOfLose.origin.x, tagImg.origin.y+1, titleRect.size.width, imgSize.height-2);
        
        CGRect imgOfLose        = CGRectMake(spacingBetweenLeftAndRight, tag.origin.y+tag.size.height+8, imgSizeHuge.width, imgSizeHuge.height);
        
        CGRect moneyImg         = CGRectMake(210, titleRect.origin.y+titleRect.size.height, imgSize.width+5, imgSize.height+5);
        CGRect money            = CGRectMake(moneyImg.origin.x+moneyImg.size.width+3, moneyImg.origin.y+2, 100, imgSize.height-2);
        
        CGRect telBtnRect       = CGRectMake(spacingBetweenLeftAndRight, imgOfLose.origin.y+imgOfLose.size.height+50, imgSizeBtn.width*1.5, imgSizeBtn.height*1.5);
        CGRect telLabRect       = CGRectMake(telBtnRect.origin.x, telBtnRect.origin.y+telBtnRect.size.height+5, telBtnRect.size.width, 20);
        
        CGRect msgBtnRect       = CGRectMake(telBtnRect.origin.x+telBtnRect.size.width+50, telBtnRect.origin.y, imgSizeBtn.width*1.5, imgSizeBtn.height*1.5);
        CGRect msgLabRect       = CGRectMake(msgBtnRect.origin.x, telLabRect.origin.y, telLabRect.size.width, telLabRect.size.height);
        
        CGRect commentBtnRect   = CGRectMake(msgBtnRect.origin.x+msgBtnRect.size.width+50, telBtnRect.origin.y, imgSizeBtn.width*1.5, imgSizeBtn.height*1.5);
        CGRect commentLabRect   = CGRectMake(commentBtnRect.origin.x, telLabRect.origin.y, telLabRect.size.width, telLabRect.size.height);
        
        CGRect ImgXianRect      = CGRectMake(20, telBtnRect.origin.y-20, imgSizeXian.width, imgSizeXian.height);
        
        //颜色
        UIColor *hei=[UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:1.0f];
        UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
        UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
        UIColor *huang=[UIColor colorWithRed:0xef/255.0f green:0xd2/255.0f blue:0x6c/255.0f alpha:1.0f];
        
        //label, 标题, 浅蓝, 默认大小17， 改为22.5
        UILabel *label1=[[UILabel alloc] initWithFrame:titleRect];
        [self addSubview:label1];
        [label1 setTextColor:qianlan];
        self.l1=label1;
        [label1 setFont:[UIFont systemFontOfSize:22.5f]];
        //[label1 setBackgroundColor:hei];
        
        //label, 用户昵称, 黑, 18
        UILabel *label2=[[UILabel alloc] initWithFrame:userNameRect];
        [self addSubview:label2];
        [label2 setTextColor:hei];
        self.l2=label2;
        [label2 setFont:[UIFont systemFontOfSize:18]];
        //[label2 setBackgroundColor:hei];
        
        //label, 发布日期, 浅灰, 15
        UILabel *label3=[[UILabel alloc] initWithFrame:dateOfPublish];
        [self addSubview:label3];
        [label3 setTextColor:qianhui];
        self.l3=label3;
        [label3 setFont:[UIFont systemFontOfSize:15]];
        //[label3 setBackgroundColor:hei];
        
        //img, ‘丢失/发现’时间
        UIImageView *timeView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"biaoshi1@3x.png"]];
        [timeView setCenter:CGPointMake(dateOfLoseImg.origin.x+dateOfLoseImg.size.width/2, dateOfLoseImg.origin.y+dateOfLoseImg.size.height/2)];
        [self addSubview:timeView];
        
        //label, ‘丢失/发现’时间, 浅蓝, 18
        UILabel *label4=[[UILabel alloc] initWithFrame:dateOfLose];
        [self addSubview:label4];
        [label4 setFont:[UIFont systemFontOfSize:18]];
        [label4 setTextColor:qianlan];
        self.l4=label4;
        //[label4 setBackgroundColor:hei];
        
        //img, 地点
        UIImageView *placeView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"biaoshi2.png"]];
        [placeView setCenter:CGPointMake(placeOfLoseImg.origin.x+placeOfLoseImg.size.width/2.0f, placeOfLoseImg.origin.y+placeOfLoseImg.size.height/2.0f)];
        [self addSubview:placeView];
        
        //label, 地点, 浅蓝, 18
        UILabel *label5=[[UILabel alloc] initWithFrame:placeOfLose];
        [self addSubview:label5];
        [label5 setTextColor:qianlan];
        [label5 setFont:[UIFont systemFontOfSize:18]];
        self.l5=label5;
        //[label5 setBackgroundColor:hei];
        
        //img, 标签
        UIImageView *tagView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"biaoshi3.png"]];
        [tagView setCenter:CGPointMake(tagImg.origin.x+tagImg.size.width/2, tagImg.origin.y+tagImg.size.height/2)];
        [self addSubview:tagView];
        
        //label, 标签, 浅蓝
        UILabel *label6=[[UILabel alloc] initWithFrame:tag];
        [self addSubview:label6];
        [label6 setTextColor:qianlan];
        [label6 setFont:[UIFont systemFontOfSize:18]];
        self.l6=label6;
        //[label6 setBackgroundColor:hei];
        
        //img, 赏金
        UIImageView *moneyView=[[UIImageView alloc] initWithFrame:moneyImg];
        [moneyView setImage:[UIImage imageNamed:@"shangjin.png"]];
        [self addSubview:moneyView];
        self.u2=moneyView;
        
        //label, 赏金， 黄, 22
        UILabel *label7=[[UILabel alloc] initWithFrame:money];
        [self addSubview:label7];
        [label7 setFont:[UIFont systemFontOfSize:22]];
        [label7 setTextColor:huang];
        self.l7=label7;
        //[label7 setBackgroundColor:hei];
        
        //img, 物品照片
        UIImageView *thingView=[[UIImageView alloc] initWithFrame:imgOfLose];
        //[thingView setImage:[UIImage imageNamed:@"shangjin.png"]];
        [self addSubview:thingView];
        self.u1=thingView;
        
        //btn, 电话按钮
        UIButton *telBtn=[[UIButton alloc] initWithFrame:telBtnRect];
        [telBtn setBackgroundImage:[UIImage imageNamed:@"tel.png"] forState:UIControlStateNormal];
        [self addSubview:telBtn];
        [telBtn addTarget:self action:@selector(telClick:) forControlEvents:UIControlEventTouchUpInside];
        self.tel=telBtn;
        
        //lab, 电话文本, 22
        UILabel *telLab=[[UILabel alloc] initWithFrame:telLabRect];
        [telLab setText:@"电话"];
        [telLab setFont:[UIFont systemFontOfSize:18]];
        [telLab setTextColor:qianlan];
        [telLab setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:telLab];
        
        //btn, 短信按钮
        UIButton *msgBtn=[[UIButton alloc] initWithFrame:msgBtnRect];
        [msgBtn setBackgroundImage:[UIImage imageNamed:@"msg.png"] forState:UIControlStateNormal];
        [self addSubview:msgBtn];
        [msgBtn addTarget:self action:@selector(msgClick:) forControlEvents:UIControlEventTouchUpInside];
        self.msg=msgBtn;
        
        //lab, 短信文本, 22
        UILabel *msgLab=[[UILabel alloc] initWithFrame:msgLabRect];
        [msgLab setText:@"短信"];
        [msgLab setFont:[UIFont systemFontOfSize:18]];
        [msgLab setTextColor:qianlan];
        [msgLab setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:msgLab];
        
        //btn, 评论按钮
        UIButton *commentBtn=[[UIButton alloc] initWithFrame:commentBtnRect];
        [commentBtn setBackgroundImage:[UIImage imageNamed:@"comment.png"] forState:UIControlStateNormal];
        [self addSubview:commentBtn];
        [commentBtn addTarget:self action:@selector(commentClick:) forControlEvents:UIControlEventTouchUpInside];
        self.comment=commentBtn;
        
        //lab, 评论文本, 22
        UILabel *commentLab=[[UILabel alloc] initWithFrame:commentLabRect];
        [commentLab setText:@"评论"];
        [commentLab setFont:[UIFont systemFontOfSize:18]];
        [commentLab setTextColor:qianlan];
        [commentLab setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:commentLab];
        
        //分隔线
        UIImageView *xianImgView=[[UIImageView alloc] initWithFrame:ImgXianRect];
        [xianImgView setImage:[UIImage imageNamed:@"xian.png"]];
        [self addSubview:xianImgView];
    }
    
    
    //背景色毛玻璃效果
    [self setBackgroundColor:[UIColor clearColor]];
    //设置背景视图
    [self setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"at_di.png"]]];
    //点击不会变为高亮状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    
    return self;
}
-(void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    UIBezierPath *line=[[UIBezierPath alloc] init];
    [line moveToPoint:CGPointMake(0, 50)];
    [line addLineToPoint:CGPointMake(100, 50)];
    [[UIColor blueColor] setStroke];
    NSLog(@"cellOfxs.m\ndrawRect, %f, %f, %f, %f", rect.origin.x, rect.origin.y, rect.size.width, rect.size.height);
}
//功能按钮
-(void)telClick:(id)sender{
    UIButton *btn=(UIButton *)sender;
    NSString *telNumber=[NSString stringWithFormat:@"tel://%@", [self.commentDelegate getPhoneNumber:[btn tag]/10-10]];
    
    //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://13696903774"] options:@{} completionHandler:nil];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}
-(void)msgClick:(id)sender{
    UIButton *btn=(UIButton *)sender;
    NSString *telNumber=[NSString stringWithFormat:@"tel://%@", [self.commentDelegate getPhoneNumber:[btn tag]/10-11]];
    
    //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://13696903774"] options:@{} completionHandler:nil];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}
-(void)commentClick:(id)sender{
    [self.commentDelegate showKeyboard];
}
@end
