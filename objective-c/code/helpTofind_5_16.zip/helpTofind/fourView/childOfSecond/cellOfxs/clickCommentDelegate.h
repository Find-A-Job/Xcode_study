//
//  clickCommentDelegate.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/28.
//  Copyright © 2019年 电脑. All rights reserved.
//

#ifndef clickCommentDelegate_h
#define clickCommentDelegate_h

@protocol clickCommentDelegate

@optional
-(void)showKeyboard;
-(NSString *)getPhoneNumber:(NSInteger)indexPath;

@end
#endif /* clickCommentDelegate_h */
