//
//  wdshiwu.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "wdshiwu.h"
#import "cellOfwd.h"

@interface wdshiwu()

//cell
@property(nonatomic) NSString *cellIdent;

//ts
@property(strong, nonatomic) NSDictionary *showData;

@end

@implementation wdshiwu

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //
    self.cellIdent=@"wdshiwuCell";
    
    //静态数据，可注释掉
    NSDictionary *t1=[NSDictionary dictionaryWithObjectsAndKeys:@"丢球丢球", @"title", @"王得分", @"userName", @"2019-1-1", @"publishDate",@"2018-1-1", @"loseDate",@"福建省厦门市思明区", @"place",@"其他", @"tag",@"70", @"money",@"这里是9个字的简介", @"overView", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t2=[NSDictionary dictionaryWithObjectsAndKeys:@"手弓锯", @"title", @"刘师傅", @"userName", @"2019-2-1", @"publishDate",@"2018-2-1", @"loseDate",@"福建省厦门市思明区", @"place",@"工具", @"tag",@"0", @"money",@"这里是9个字的简介", @"overView", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t3=[NSDictionary dictionaryWithObjectsAndKeys:@"语文课本", @"title", @"朴老师", @"userName", @"2019-3-1", @"publishDate",@"2018-3-1", @"loseDate",@"福建省厦门市思明区", @"place",@"书籍", @"tag",@"10", @"money",@"这里是9个字的简介", @"overView", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t4=[NSDictionary dictionaryWithObjectsAndKeys:@"散文诗丢了", @"title", @"沈丛文", @"userName", @"2019-4-1", @"publishDate",@"2018-4-1", @"loseDate",@"福建省厦门市思明区", @"place",@"书籍", @"tag",@"100", @"money",@"这里是9个字的简介", @"overView", @"ka.png", @"img", @"0", @"state",nil];
    NSDictionary *t5=[NSDictionary dictionaryWithObjectsAndKeys:@"颠勺丢了", @"title", @"锅得钢", @"userName", @"2019-5-1", @"publishDate",@"2018-5-1", @"loseDate",@"福建省厦门市思明区", @"place",@"工具", @"tag",@"40", @"money",@"这里是9个字的简介", @"overView", @"ka.png", @"img", @"0", @"state",nil];
    NSArray *arr=@[t1, t2, t3, t4, t5];
    self.showData=[[NSDictionary alloc] initWithObjectsAndKeys:arr, @"data", nil];
    //[NSDictionary dictionaryWithObjectsAndKeys:arr, "data", nil];
    
    //设置标题
    self.navigationItem.title=@"我的失物";
    
    //去分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    //隐藏右侧滚动条
    [self.tableView setShowsVerticalScrollIndicator:NO];
    
    //增加额外滚动区域
    [self.tableView setContentInset:UIEdgeInsetsMake(0, 0, 100, 0)];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number=3;
    NSArray *arr=[self.showData objectForKey:@"data"];
    number=arr.count;
    
    return number;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat height=700;
    
    return height;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    cellOfwd *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if(!cell){
        cell=[[cellOfwd alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    NSDictionary *nsd=((NSArray *)[self.showData objectForKey:@"data"])[indexPath.row];
    //标题
    cell.l1.text=[nsd objectForKey:@"title"];
    
    //用户
    cell.l2.text=[nsd objectForKey:@"userName"];
    
    //发布时间
    cell.l3.text=[NSString stringWithFormat:@"%@  发布", [nsd objectForKey:@"publishDate"]];
    
    //丢失/寻找时间
    cell.l4.text=[nsd objectForKey:@"loseDate"];
    
    //地址
    cell.l5.text=[nsd objectForKey:@"place"];
    
    //类型
    cell.l6.text=[nsd objectForKey:@"tag"];
    
    //赏金
    NSString *moneyValue=[nsd objectForKey:@"money"];
    if ([moneyValue isEqualToString:@"0"]) {
        [cell.l7 setHidden:YES];
        [cell.u2 setHidden:YES];
    }else{
        [cell.l7 setHidden:NO];
        [cell.u2 setHidden:NO];
        cell.l7.text=[NSString stringWithFormat:@"%@赏金", moneyValue];
    }
        
    //上传的图片
    [cell.u1 setImage:[UIImage imageNamed:[nsd objectForKey:@"img"]]];
    
    //简介
    [cell.tv1 setText:[nsd objectForKey:@"overView"]];
    
    //状态， 0未设置， 1关闭， 2完成
    NSString *state=[nsd objectForKey:@"state"];
    if ([state isEqualToString:@"0"]) {
        [cell.closeView setHidden:YES];
        [cell.finishView setHidden:YES];
        [cell.close setHidden:NO];
        [cell.finish setHidden:NO];
    }else if ([state isEqualToString:@"1"]) {
        [cell.closeView setHidden:NO];
        [cell.finishView setHidden:YES];
        [cell.close setHidden:YES];
        [cell.finish setHidden:YES];
    }else if ([state isEqualToString:@"2"]) {
        [cell.closeView setHidden:YES];
        [cell.finishView setHidden:NO];
        [cell.close setHidden:YES];
        [cell.finish setHidden:YES];
    }
    
    return cell;
}
//-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
//    
//    return YES;
//}
//-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
//    
//    return UITableViewCellEditingStyleDelete;
//}
//-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
//    
//    
//}
@end
