//
//  wdziliao.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "wdziliao.h"

@interface wdziliao() <UITextFieldDelegate>

@property(strong, nonatomic) UITextField *utxm;

//修改按钮
@property(strong, nonatomic) UIButton *btnChange;

//textFiled
@property(strong, nonatomic) UITextField *tf1;
@property(strong, nonatomic) UITextField *tf2;
@property(strong, nonatomic) UITextField *tf3;

//按钮回调函数
-(void)btnChangeClick:(id)sender;

@end

@implementation wdziliao

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //[self.view setBackgroundColor:[UIColor whiteColor]];
    //设置标题
    self.navigationItem.title=@"我的资料";
    
    //视图背景
    CGFloat bkViewY=self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height;
    CGFloat bkViewWidth=self.navigationController.navigationBar.frame.size.width;
    CGFloat bkViewHeight=[self.uzd getTabbarRect].origin.y-bkViewY;
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bkViewWidth, bkViewHeight)];
    [self.view addSubview:bkView];
    [bkView setImage:[UIImage imageNamed:@"di.png"]];
    
    //信息框背景
    UIImageView *bk=[[UIImageView alloc] initWithFrame:CGRectMake(10, 5, bkViewWidth-20, 300)];
    [bk setImage:[UIImage imageNamed:@"kuang1"]];
    [self.view addSubview:bk];
    [bk setUserInteractionEnabled:YES];//开启响应
    
    //各个控件尺寸
    CGFloat spacingBetweenUpAndDown=5;
    CGFloat spacingBetweenLeftAndRight=5;
    CGFloat labX=20;
    CGFloat lab1Y=20;
    CGSize  labSize=CGSizeMake(80, 40);
    CGFloat lab2Y=lab1Y+labSize.height+spacingBetweenUpAndDown;
    CGFloat lab3Y=lab2Y+labSize.height+spacingBetweenUpAndDown;
    
    CGFloat tfX=labX+labSize.width+spacingBetweenLeftAndRight;
    CGFloat tf1Y=lab1Y;
    CGSize  tfSize=CGSizeMake(220, labSize.height);
    CGFloat tf2Y=lab2Y;
    CGFloat tf3Y=lab3Y;
    
//    CGFloat btnX=tfX+tfSize.width+spacingBetweenLeftAndRight;
//    CGFloat btn1Y=lab1Y;
//    CGSize  btnSize=CGSizeMake(30, labSize.height);
//    CGFloat btn2Y=lab2Y;
//    CGFloat btn3Y=lab3Y;
    CGFloat btnX=50;
    CGFloat btn1Y=lab3Y+labSize.height+20;
    CGSize  btnSize=CGSizeMake(50, labSize.height);
    CGFloat btn2Y=lab2Y;
    CGFloat btn3Y=lab3Y;

    //标签
    UILabel *xm=[[UILabel alloc] initWithFrame:CGRectMake(labX, lab1Y, labSize.width, labSize.height)];
    [xm setTextAlignment:NSTextAlignmentRight];
    [xm setTextColor:qianlan];
    [xm setText:@"昵称"];
    [bk addSubview:xm];
    
    UILabel *lxfs=[[UILabel alloc] initWithFrame:CGRectMake(labX, lab2Y, labSize.width, labSize.height)];
    [lxfs setTextAlignment:NSTextAlignmentRight];
    [lxfs setTextColor:qianlan];
    [lxfs setText:@"联系方式"];
    [bk addSubview:lxfs];
    
    UILabel *yjdz=[[UILabel alloc] initWithFrame:CGRectMake(labX, lab3Y, labSize.width, labSize.height)];
    [yjdz setTextAlignment:NSTextAlignmentRight];
    [yjdz setTextColor:qianlan];
    [yjdz setText:@"邮寄地址"];
    [bk addSubview:yjdz];
    
    //编辑框
    UITextField *utxm=[[UITextField alloc] initWithFrame:CGRectMake(tfX, tf1Y, tfSize.width, tfSize.height)];
    [utxm setBackground:[UIImage imageNamed:@"kuang2"]];
    [utxm setPlaceholder:@"请输入姓名"];
    utxm.delegate=self;
    [bk addSubview:utxm];
    self.tf1=utxm;
    
    UITextField *utlxfs=[[UITextField alloc] initWithFrame:CGRectMake(tfX, tf2Y, tfSize.width, tfSize.height)];
    [utlxfs setBackground:[UIImage imageNamed:@"kuang2"]];
    [utlxfs setPlaceholder:@"请输入联系方式"];
    utlxfs.delegate=self;
    [bk addSubview:utlxfs];
    [utlxfs setTag:2];
    //[utlxfs setKeyboardType:UIKeyboardTypeNumberPad];
    self.tf2=utlxfs;
    
    UITextField *utyjdz=[[UITextField alloc] initWithFrame:CGRectMake(tfX, tf3Y, tfSize.width, tfSize.height)];
    [utyjdz setBackground:[UIImage imageNamed:@"kuang2"]];
    [utyjdz setPlaceholder:@"请输入邮寄地址"];
    utyjdz.delegate=self;
    [bk addSubview:utyjdz];
    self.tf3=utyjdz;
    
    //按钮
    UIButton *btnxm=[[UIButton alloc] initWithFrame:CGRectMake(btnX, btn1Y, btnSize.width, btnSize.height)];
    [btnxm setTitle:@"修改" forState:UIControlStateNormal];
    [btnxm setTitleColor:qianlan forState:UIControlStateNormal];
    [btnxm addTarget:self action:@selector(btnChangeClick:) forControlEvents:UIControlEventTouchUpInside];
    [bk addSubview:btnxm];
}
//编辑框代理
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return  YES;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    BOOL result=YES;
    if(textField.tag == 2){
        NSCharacterSet *temSet=[NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i=0; i<string.length; ++i) {
            NSString *s=[string substringWithRange:NSMakeRange(i, 1)];
            NSRange r=[s rangeOfCharacterFromSet:temSet];
            if(r.length == 0){
                result=NO;
                break;
            }
        }
    }
    
    return result;
}
//
-(void)btnChangeClick:(id)sender{
    NSString *xm=self.tf1.text;
    NSString *lxfs=self.tf2.text;
    NSString *yjdz=self.tf3.text;
    NSLog(@"\nget text from textfiled, \n%@, \n%@, \n%@", xm, lxfs, yjdz);
}
@end
