//
//  cellOfwd.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/19.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface cellOfwd : UITableViewCell

@property(strong, nonatomic) UILabel *l1;//标题
@property(strong, nonatomic) UILabel *l2;//用户昵称
@property(strong, nonatomic) UILabel *l3;//发布日期
@property(strong, nonatomic) UILabel *l4;//‘丢失/发现’时间
@property(strong, nonatomic) UILabel *l5;//地点
@property(strong, nonatomic) UILabel *l6;//标签
@property(strong, nonatomic) UILabel *l7;//赏金

@property(strong, nonatomic) UIImageView *u1;//物品照片
@property(strong, nonatomic) UIImageView *u2;//赏金图标
@property(strong, nonatomic) UITextView  *tv1;//简介

//新增
@property(strong, nonatomic) UIButton *close;//关闭按钮
@property(strong, nonatomic) UIButton *finish;//完成按钮
@property(strong, nonatomic) UIImageView *closeView;//关闭视图
@property(strong, nonatomic) UIImageView *finishView;//完成视图

@end
