//
//  secondView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "secondView.h"
#import "xuanshangTableView.h"
#import "childOfSecond/cellOfxs/clickCommentDelegate.h"

@interface secondView() <UITextFieldDelegate, clickCommentDelegate>

@property(strong, nonatomic) UITextField *editBox;

//
-(void)keyboardUp:(NSNotification *)sender;
-(void)keyboardDown:(NSNotification *)sender;

//
-(void)enterBk:(id)sender;
-(void)enterFk:(id)sender;

@end

@implementation secondView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //color
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //背景
    UIImageView *shangdiView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shangdi1.png"]];
    [self.view addSubview:shangdiView];
    [self.view setBackgroundColor:[UIColor whiteColor]];//需要改成灰色
    
    //按时间排序，按赏金排序
    
    //表格
    xuanshangTableView *xs=[[xuanshangTableView alloc] initWithStyle:UITableViewStylePlain];
    [self addChildViewController:xs];
    [self.view addSubview:xs.view];
    xs.commentDelegate=self;
    
    //输入框
    UITextField *putText=[[UITextField alloc] initWithFrame:CGRectMake(0, 200, 375, 50)];
    [putText setBackgroundColor:[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f]];
    [putText setFont:[UIFont systemFontOfSize:20]];
    [putText setTextColor:[UIColor blackColor]];
    putText.delegate=self;
    [putText setHidden:YES];
    [self.view addSubview:putText];
    [self.view bringSubviewToFront:putText];
    self.editBox=putText;
    
    //输入框右侧按钮
    UIButton *fasong=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 38, 28)];//x,y属性没效果
    [fasong setTitle:@"发送" forState:UIControlStateNormal];
    [fasong setTitleColor:qianlan forState:UIControlStateNormal];
    [putText setRightView:fasong];
    [putText setRightViewMode:UITextFieldViewModeWhileEditing];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    //页面消失，注销相关活动
    NSLog(@"页面隐藏");
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
}
-(void)viewDidAppear:(BOOL)animated{
    //监听键盘,设置编辑框高度（在键盘上方），以及注销监听，防止多次监听
    //...
    NSLog(@"页面出现");
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDown:) name:UIKeyboardWillHideNotification object:nil];
    
    //进入后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterBk:) name:UIApplicationWillResignActiveNotification object:nil];
    
    //变为活动状态
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterFk:) name:UIApplicationDidBecomeActiveNotification object:nil];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [self.editBox setHidden:YES];
    
    return YES;
}
-(void)showKeyboard{
    [self.editBox setHidden:NO];
    [self.editBox setText:@""];
    [self.editBox becomeFirstResponder];
}
-(void)keyboardUp:(NSNotification *)sender{
    NSValue *keyboard=[(NSDictionary *)[sender userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey];
    
    if ([sender.name isEqualToString:UIKeyboardWillShowNotification]) {
        CGRect keyboardRect=[keyboard CGRectValue];
        [self.editBox setCenter:CGPointMake(keyboardRect.size.width/2.0f, keyboardRect.origin.y-self.editBox.bounds.size.height/2.0f-64)];//60
        [self.editBox setHidden:NO];
    }
}
//键盘收起， textfiled隐藏, 清空
-(void)keyboardDown:(NSNotification *)sender{
    if ([sender.name isEqualToString:UIKeyboardWillHideNotification]) {
        [self.editBox setHidden:YES];
        [self.editBox setText:@""];
    }
}
-(void)enterBk:(id)sender{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}
-(void)enterFk:(id)sender{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDown:) name:UIKeyboardWillHideNotification object:nil];
}
@end
