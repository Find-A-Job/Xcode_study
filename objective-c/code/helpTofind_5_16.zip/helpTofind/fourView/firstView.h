//
//  firstView.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "userzmxDelegate.h"

@protocol firstViewDelegate <NSObject>

@optional
-(id)getFabuView;
-(id)getZhaoLingView;

@end

@interface firstView : UIViewController

//代理
@property(weak, nonatomic) id<userzmxDegelate> uzd;

//
@property(weak, nonatomic) id<firstViewDelegate> fDele;

//

@end
