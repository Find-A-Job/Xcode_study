//
//  MyTabBar.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "MyTabBar.h"

@interface MyTabBar()

@property(nonatomic, weak) UIButton *addButton;

@property(nonatomic, weak) UILabel *addLabel;

@end

@implementation MyTabBar

-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        UIButton *addButton=[[UIButton alloc] init];
        [addButton setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [addButton setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateHighlighted];
        [addButton addTarget:self action:@selector(addBtnDidClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:addButton];
        
        self.addButton=addButton;
    }
    
    return self;
}
//响应中间“+”按钮点击事件
-(void)addBtnDidClick{
    if ([self.myTabBarDelegate respondsToSelector:@selector(addButtonClick:)]) {
        [self.myTabBarDelegate addButtonClick:self];
    }
}
-(void)layoutSubviews{
    [super layoutSubviews];
    
    //
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIImageView class]] && view.bounds.size.height <= 1) {
            UIImageView *line=(UIImageView *)view;
            line.hidden=YES;
        }
    }
    
    //
    CGRect p=self.frame;
    
    //"+"按钮设置
    [self.addButton setCenter:CGPointMake(self.center.x, self.frame.size.height * 0.5 - 1.5 * self.addButton.layoutMargins.bottom)];
    p.size=CGSizeMake(self.addButton.currentBackgroundImage.size.width, self.addButton.currentBackgroundImage.size.height);
    [self.addButton setFrame:p];
    
    //"+"按钮下的label
    
    //
    int btnIndex=0;
    Class class=NSClassFromString(@"UITabBarButton");
    for (UIView *btn in self.subviews) {
        if ([btn isKindOfClass:class]) {
            CGRect c=self.frame;
            c.size.width=c.size.width/3;
            c.origin.x=c.size.width*btnIndex;
            [btn setFrame:c];
            
            ++btnIndex;
            if (btnIndex==2) {
                ++btnIndex;
            }
        }
    }
    
    [self bringSubviewToFront:self.addButton];
}

-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    if(self.isHidden == NO){
        CGPoint neA=[self convertPoint:point toView:self.addButton];
        //CGPoint neL=[self convertPoint:point toView:self.addLabel];
        
        if ([self.addButton pointInside:neA withEvent:event]) {
            return self.addButton;
        } else {
            return [super hitTest:point withEvent:event];
        }
    }else{
        return [super hitTest:point withEvent:event];
    }
}
@end
