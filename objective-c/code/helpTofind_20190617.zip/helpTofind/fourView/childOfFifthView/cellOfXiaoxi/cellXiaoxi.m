//
//  cellXiaoxi.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/23.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "cellXiaoxi.h"

@interface cellXiaoxi()

@end

@implementation cellXiaoxi

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //标题， 信息， 时间戳， 简易版暂不考虑‘回复’功能
        
        //color
        UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
        
        //尺寸
        CGRect titleRect=CGRectMake(20, 20, 200, 50);
        CGRect msgRect=CGRectMake(titleRect.origin.x, titleRect.origin.y+titleRect.size.height+10, titleRect.size.width, titleRect.size.height);
        CGRect timeStampRect=CGRectMake(msgRect.origin.x, msgRect.origin.y+msgRect.size.height+10, 100, msgRect.size.height-10);
        
        //标题, 黑， 22
        UILabel *title=[[UILabel alloc] initWithFrame:titleRect];
        [title setTextColor:[UIColor blackColor]];
        [title setBackgroundColor:[UIColor clearColor]];
        [title setFont:[UIFont systemFontOfSize:22]];
        self.title=title;
        [self addSubview:title];
        
        //信息， 黑， 18
        UILabel *msg=[[UILabel alloc] initWithFrame:msgRect];
        [msg setTextColor:[UIColor blackColor]];
        [msg setBackgroundColor:[UIColor clearColor]];
        [msg setFont:[UIFont systemFontOfSize:18]];
        self.msg=msg;
        [self addSubview:msg];
        
        //时间戳，浅灰， 12
        UILabel *timeStamp=[[UILabel alloc] initWithFrame:timeStampRect];
        [timeStamp setTextColor:qianhui];
        [timeStamp setBackgroundColor:[UIColor clearColor]];
        [timeStamp setFont:[UIFont systemFontOfSize:12]];
        self.timeStamp=timeStamp;
        [self addSubview:timeStamp];
        
        //设置背景
        UIImage *uimg=[UIImage imageNamed:@"xiaoxikuang.png"];
        UIImageView *bkView=[[UIImageView alloc] initWithImage:[uimg stretchableImageWithLeftCapWidth:uimg.size.width*0.3 topCapHeight:uimg.size.height*0.3]];
        [self setBackgroundView:bkView];
        
        //选中无变化
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    
    return self;
}

@end
