//
//  cellXiaoxi.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/23.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface cellXiaoxi : UITableViewCell

@property(strong, nonatomic) UILabel *title;
@property(strong, nonatomic) UILabel *msg;
@property(strong, nonatomic) UILabel *timeStamp;


@end
