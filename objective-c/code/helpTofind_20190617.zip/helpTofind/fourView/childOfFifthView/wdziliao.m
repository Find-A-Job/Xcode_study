//
//  wdziliao.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "wdziliao.h"
#import "../../dataPersistence/NSUserDefaults+nsUD_cate.h"
#import "../../main/global.h"

@interface wdziliao() <UITextFieldDelegate, NSURLSessionDelegate>

@property(strong, nonatomic) UITextField *utxm;

//修改按钮
@property(strong, nonatomic) UIButton *btnChange;

//textFiled
@property(strong, nonatomic) UITextField *tf1;
@property(strong, nonatomic) UITextField *tf2;
@property(strong, nonatomic) UITextField *tf3;

//按钮回调函数
-(void)btnChangeClick:(id)sender;
-(void)btnLogoutClick:(id)sender;

@end

@implementation wdziliao

-(void)viewDidLoad{
    [super viewDidLoad];
    
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    UIColor *editboxColor=[UIColor colorWithRed:0xec/255.0f green:0xf3/255.0f blue:0xfe/255.0f alpha:1.0f];
    UIColor *btnColor=[UIColor colorWithRed:0x8e/255.0f green:0xbe/255.0f blue:0xfe/255.0f alpha:1.0f];
    
    CGFloat winWidth=[UIScreen mainScreen].bounds.size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    
    //设置标题
    self.navigationItem.title=@"我的资料";
    
    //视图背景
    //CGFloat bkViewY=self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height;
    //CGFloat bkViewWidth=self.navigationController.navigationBar.frame.size.width;
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    [self.view addSubview:bkView];
    UIImage *blueBKImg=[UIImage imageNamed:@"di.png"];
    blueBKImg=[blueBKImg resizableImageWithCapInsets:UIEdgeInsetsMake(blueBKImg.size.height*0.5f, blueBKImg.size.width*0.1f, blueBKImg.size.height*0.1f, blueBKImg.size.width*0.1f)];
    bkView.image=blueBKImg;
    
    
    
    //信息框背景
    UIImage *cellBkImg=[UIImage imageNamed:@"usualBK.png"];
    cellBkImg=[cellBkImg resizableImageWithCapInsets:UIEdgeInsetsMake(cellBkImg.size.height*0.2f, cellBkImg.size.width*0.2f, cellBkImg.size.height*0.2f, cellBkImg.size.width*0.2f)];
    UIImageView *cellBkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, winHeight/66, winWidth, winHeight/10*6)];
    cellBkView.image=cellBkImg;
    [self.view addSubview:cellBkView];
    //[bk setUserInteractionEnabled:YES];//开启响应
    
    
    
    //各个控件尺寸
    
    CGSize labelSize=CGSizeMake(cellBkView.bounds.size.width/9*2, cellBkView.bounds.size.height/10);
    CGSize editboxSize=CGSizeMake(cellBkView.bounds.size.width/5*3, labelSize.height);
    CGSize btnSize=CGSizeMake(cellBkView.bounds.size.width/4, labelSize.height);
    CGFloat spaceOfTopAndBottom=cellBkView.bounds.size.height/14;
    CGFloat spaceOfLeftAndRight=cellBkView.bounds.size.width/75;
    
    
    UILabel *accountLabel=[[UILabel alloc] initWithFrame:CGRectMake(cellBkView.bounds.size.width/10-spaceOfLeftAndRight, cellBkView.frame.origin.y+spaceOfTopAndBottom, labelSize.width, labelSize.height)];
    
    UITextField *accountEditbox=[[UITextField alloc] initWithFrame:CGRectMake(accountLabel.frame.origin.x+accountLabel.bounds.size.width+spaceOfLeftAndRight, accountLabel.frame.origin.y, editboxSize.width, editboxSize.height)];
    
    UILabel *userNameLabel=[[UILabel alloc] initWithFrame:CGRectMake(accountLabel.frame.origin.x, accountLabel.frame.origin.y+accountLabel.bounds.size.height+spaceOfTopAndBottom, labelSize.width, labelSize.height)];
    
    UITextField *userNameEditbox=[[UITextField alloc] initWithFrame:CGRectMake(accountEditbox.frame.origin.x, userNameLabel.frame.origin.y, editboxSize.width, editboxSize.height)];
    
    UILabel *phoneLabel=[[UILabel alloc] initWithFrame:CGRectMake(accountLabel.frame.origin.x, userNameLabel.frame.origin.y+userNameLabel.bounds.size.height+spaceOfTopAndBottom, labelSize.width, labelSize.height)];
    
    UITextField *phoneEditbox=[[UITextField alloc] initWithFrame:CGRectMake(accountEditbox.frame.origin.x, phoneLabel.frame.origin.y, editboxSize.width, editboxSize.height)];
    
    UILabel *placeLabel=[[UILabel alloc] initWithFrame:CGRectMake(accountLabel.frame.origin.x, phoneLabel.frame.origin.y+phoneLabel.bounds.size.height+spaceOfTopAndBottom, labelSize.width, labelSize.height)];
    
    UITextField *placeEditbox=[[UITextField alloc] initWithFrame:CGRectMake(accountEditbox.frame.origin.x, placeLabel.frame.origin.y, editboxSize.width, editboxSize.height)];
    
    
    
    [self.view addSubview:accountLabel];
    [self.view addSubview:accountEditbox];
    [self.view addSubview:userNameLabel];
    [self.view addSubview:userNameEditbox];
    [self.view addSubview:phoneLabel];
    [self.view addSubview:phoneEditbox];
    [self.view addSubview:placeLabel];
    [self.view addSubview:placeEditbox];
    
    
    accountLabel.textColor      = qianlan;
    accountEditbox.textColor    = shenhui;
    userNameLabel.textColor     = qianlan;
    userNameEditbox.textColor   = shenhui;
    phoneLabel.textColor        = qianlan;
    phoneEditbox.textColor      = shenhui;
    placeLabel.textColor        = qianlan;
    placeEditbox.textColor      = shenhui;
    
    
    accountEditbox.backgroundColor  = editboxColor;
    userNameEditbox.backgroundColor = editboxColor;
    phoneEditbox.backgroundColor    = editboxColor;
    placeEditbox.backgroundColor    = editboxColor;
    
    
    accountLabel.text               = @"账号";
    accountEditbox.placeholder      = @"";
    userNameLabel.text              = @"昵称";
    userNameEditbox.placeholder     = @"";
    phoneLabel.text                 = @"联系电话";
    phoneEditbox.placeholder        = @"";
    placeLabel.text                 = @"邮寄地址";
    placeEditbox.placeholder        = @"";
    
    
    [accountEditbox.layer setCornerRadius:8];
    [accountEditbox.layer setMasksToBounds:YES];
    [userNameEditbox.layer setCornerRadius:8];
    [userNameEditbox.layer setMasksToBounds:YES];
    [phoneEditbox.layer setCornerRadius:8];
    [phoneEditbox.layer setMasksToBounds:YES];
    [placeEditbox.layer setCornerRadius:8];
    [placeEditbox.layer setMasksToBounds:YES];
    
    
    accountLabel.textAlignment      = NSTextAlignmentRight;
    userNameLabel.textAlignment     = NSTextAlignmentRight;
    phoneLabel.textAlignment        = NSTextAlignmentRight;
    placeLabel.textAlignment        = NSTextAlignmentRight;
    
    
    accountEditbox.delegate         = self;
    userNameEditbox.delegate        = self;
    phoneEditbox.delegate           = self;
    placeEditbox.delegate           = self;
    
    
    accountEditbox.tag      = 300;
    userNameEditbox.tag     = 301;
    phoneEditbox.tag        = 302;
    placeEditbox.tag        = 303;
    
    
    //禁用账号编辑框
    accountEditbox.enabled=NO;
    
    
//    //按钮
    
    UIButton *changeBtn=[[UIButton alloc] initWithFrame:CGRectMake((cellBkView.bounds.size.width-2*btnSize.width)/3, placeLabel.frame.origin.y+placeLabel.bounds.size.height+spaceOfTopAndBottom/2*3, btnSize.width, btnSize.height)];
    UIButton *logoutBtn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, btnSize.width, btnSize.height)];
    
    logoutBtn.center=changeBtn.center;
    CGRect position=logoutBtn.frame;
    position.origin.x=(position.origin.x*2+position.size.width);
    logoutBtn.frame=position;
    
    [changeBtn setTitle:@"修改" forState:UIControlStateNormal];
    [logoutBtn setTitle:@"注销" forState:UIControlStateNormal];
    
    [changeBtn setBackgroundColor:btnColor];
    [logoutBtn setBackgroundColor:btnColor];
    
    [changeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [logoutBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [changeBtn.layer setCornerRadius:8];
    [changeBtn.layer setMasksToBounds:YES];
    [logoutBtn.layer setCornerRadius:8];
    [logoutBtn.layer setMasksToBounds:YES];
    
    
    [self.view addSubview:changeBtn];
    [self.view addSubview:logoutBtn];
    
    
    [changeBtn addTarget:self action:@selector(btnChangeClick:) forControlEvents:UIControlEventTouchUpInside];
    [logoutBtn addTarget:self action:@selector(btnLogoutClick:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)viewWillAppear:(BOOL)animated{
    
    NSDictionary *userInfo      = [NSUserDefaults getData:@"userInfo"];
    NSString *accountString     = [userInfo objectForKey:@"username"];
    NSString *userNameString    = [userInfo objectForKey:@"consigner"];
    NSString *phoneString       = [userInfo objectForKey:@"mobile"];
    NSString *addressString     = [userInfo objectForKey:@"address"];
    
    [(UITextField *)[self.view viewWithTag:300] setText:accountString];
    [(UITextField *)[self.view viewWithTag:301] setText:userNameString];
    [(UITextField *)[self.view viewWithTag:302] setText:phoneString];
    [(UITextField *)[self.view viewWithTag:303] setText:addressString];
    
}
//编辑框代理
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return  YES;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    BOOL result=YES;
    NSLog(@"editField:%@", string);
    if(textField.tag == 302){
        //超过11位，则限制
        unsigned long oldStringLength=(unsigned long)textField.text.length;
        unsigned long newStringLength=(unsigned long)string.length;

        NSLog(@"oldStringLength:%lu, newStringLength:%lu", oldStringLength, newStringLength);//使用apple自带的复制粘贴，会比你复制的字符长度多1，比如复制“12”，则会变成“ 12”
        if (newStringLength <= 0) {
            //允许删除操作
            return YES;
        }
        if ((oldStringLength + newStringLength) > 11) {
            NSLog(@"超过最大长度");
            return NO;
        }
        

        
        //旧方案
//        NSCharacterSet *temSet=[NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
//        for (int i=0; i<string.length; ++i) {
//            NSString *s=[string substringWithRange:NSMakeRange(i, 1)];
//            NSRange r=[s rangeOfCharacterFromSet:temSet];
//            if(r.length == 0){
//                result=NO;
//                break;
//            }
//        }
        
        //方案一,一个一个比较
//        NSString *targetString=@"0123456789";
//        for (int i=0; i<string.length; ++i) {
//            NSString *oneWord=[string substringWithRange:NSMakeRange(i, 1)];
//            if (![targetString  containsString:oneWord]) {
//                result=NO;
//            }
//        }
        
        //方案二,characterset
        NSCharacterSet *digitSet=[NSCharacterSet decimalDigitCharacterSet];
        NSArray *stringArr=[string componentsSeparatedByCharactersInSet:digitSet];
        NSString *finishString=[stringArr componentsJoinedByString:@""];
        NSLog(@"finishString: %@", finishString);
        if (finishString.length != 0 || ![finishString isEqualToString:@""]) {
            NSLog(@"输入的内容是非数字字符");
            result=NO;
        }
    }
    
    return result;
}
//

#pragma mark - btn click

#warning change data & logout
-(void)btnChangeClick:(id)sender{
    UITextField *accountEditbox         = [self.view viewWithTag:300];
    UITextField *consignerEditbox       = [self.view viewWithTag:301];
    UITextField *mobileEditbox          = [self.view viewWithTag:302];
    UITextField *addressEditbox         = [self.view viewWithTag:303];
    NSString *uidString                 = [(NSDictionary *)[NSUserDefaults getData:@"userInfo"] objectForKey:@"uid"];
    
    //判断电话号码长度是否合理
    if (mobileEditbox.text.length > 0 && mobileEditbox.text.length != 11) {
        [self popAlert:@"请输入11位手机号码"];
        return;
    }
    
    //判断资料是否有 不同，若相同则不发送修改数据。若不同则发送修改数据。防止发送过多数据
#warning click again judge

    NSString *domainString      = DOMAIN_SET;
    NSString *url               = [[NSString alloc] initWithFormat:@"http://%@/index.php?s=/member/modifyInfo", domainString];
    NSURL *realUrl              = [[NSURL alloc] initWithString:url];
    
    //创建请求体字符串
    NSString *post=[[NSString alloc] initWithFormat:@"consigner=%@&mobile=%@&address=%@&uid=%@", consignerEditbox.text, mobileEditbox.text, addressEditbox.text, uidString];
    NSLog(@"%@", post);
    
    //字符串转UTF-8编码方式
    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
    
    //创建请求体
    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
    
    //设置请求方式
    [request setHTTPMethod:@"post"];
    
    //填充请求体
    [request setHTTPBody:postData];
    
    //配置会话
    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    //创建会话
    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"请求完成...");
        if (!error) {
            NSLog(@"成功");
            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
            if ([code isEqualToString:@"1"]) {
                NSDictionary *userInfo=[[NSDictionary alloc] initWithObjectsAndKeys:uidString, @"uid", consignerEditbox.text, @"consigner", mobileEditbox.text, @"mobile", addressEditbox.text, @"address", accountEditbox.text, @"username", nil];
                //写入偏好设置
                [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:userInfo, @"value", @"userInfo", @"key", nil]];
                NSLog(@"修改成功");
                [self popAlert:@"修改成功"];
            } else {
                NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                //加个失败弹窗
                [self popAlert:@"账号或密码错误"];
            }
        } else {
            NSLog(@"失败， %@", error);
            //加个失败弹窗
            [self popAlert:@"服务器连接失败"];
        }
    }];
    //执行会话任务
    [task resume];
}

-(void)btnLogoutClick:(id)sender{
    
    //设置状态为未登录
    [self.uzd logoutFromWDZL];
    
    //h返回上级菜单
    [self.navigationController popViewControllerAnimated:YES];
    ;
}



#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}

@end
