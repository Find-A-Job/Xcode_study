//
//  wdshiwu.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol wdshiwuViewDelegate <NSObject>

@optional
-(NSDictionary *)getDatawdshiwu;
-(void)ssetChangeString:(NSString *)cs;
-(void)changeGlobalShowData:(NSDictionary *)sData;

@end
@interface wdshiwu : UITableViewController

@property(strong, atomic)NSDictionary *showData;
@property(strong, atomic)NSDictionary *imgCachePool;

@property(weak, nonatomic) id<wdshiwuViewDelegate> wdshiwuDelegate;

@end
