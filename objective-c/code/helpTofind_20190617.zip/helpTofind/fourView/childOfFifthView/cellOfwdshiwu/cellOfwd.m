//
//  cellOfwd.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/19.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "cellOfwd.h"
#import "../../../dataPersistence/NSUserDefaults+nsUD_cate.h"
#import "../../../main/global.h"

@interface cellOfwd() <NSURLSessionDelegate>

-(void)closeBtnAction:(id)sender;
-(void)finishBtnAction:(id)sender;
@end

@implementation cellOfwd

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    //界面表示
    /*
     
     |++++++++++++++++++++++++++++++++++++++++
     |title/label                            |
     |userName/label           money/label   |
     |dateOfPublish/label                    |
     |                                       |
     |dateOfLose/img   dateOfLose/label      |
     |placeOfLose/img  placeOfLose/label     |
     |tag/img          tag/label             |
     |                                       |
     |imgOfLose/img                          |
     |                                       |
     |overView/img     overView/textView     |
     |                                       |
     |                                       |
     |++++++++++++++++++++++++++++++++++++++++
     
     //新增两个按钮和一个图片
     */
    if(self){
        //尺寸坐标
        CGFloat spacingBetweenLeftAndRight=35;
        CGFloat spacingBetweenTopAndBottom=20;
        CGSize  imgSize=CGSizeMake(23, 26);
        CGSize  imgSizeHuge=CGSizeMake(300, 200);
        
        CGRect titleRect        = CGRectMake(spacingBetweenLeftAndRight, spacingBetweenTopAndBottom, 200, 50);
        CGRect userNameRect     = CGRectMake(titleRect.origin.x, titleRect.origin.y+titleRect.size.height+5, titleRect.size.width, titleRect.size.height-10);
        CGRect dateOfPublish    = CGRectMake(titleRect.origin.x, userNameRect.origin.y+userNameRect.size.height+3, titleRect.size.width, userNameRect.size.height-10);
        
        CGRect dateOfLoseImg    = CGRectMake(titleRect.origin.x, dateOfPublish.origin.y+dateOfPublish.size.height+6, imgSize.width, imgSize.height);
        CGRect dateOfLose       = CGRectMake(dateOfLoseImg.origin.x+dateOfLoseImg.size.width+3, dateOfLoseImg.origin.y+1, titleRect.size.width, imgSize.height-2);
        
        CGRect placeOfLoseImg   = CGRectMake(dateOfLoseImg.origin.x, dateOfLoseImg.origin.y+dateOfLose.size.height+4, imgSize.width, imgSize.height);
        CGRect placeOfLose      = CGRectMake(dateOfLose.origin.x, placeOfLoseImg.origin.y+1, titleRect.size.width, imgSize.height-2);
        
        CGRect tagImg           = CGRectMake(dateOfLoseImg.origin.x, placeOfLoseImg.origin.y+placeOfLose.size.height+4, imgSize.width, imgSize.height);
        CGRect tag              = CGRectMake(dateOfLose.origin.x, tagImg.origin.y+1, titleRect.size.width, imgSize.height-2);
        
        CGRect imgOfLose        = CGRectMake(spacingBetweenLeftAndRight, tag.origin.y+tag.size.height+8, imgSizeHuge.width, imgSizeHuge.height);
        
        CGRect moneyImg         = CGRectMake(210, titleRect.origin.y+titleRect.size.height, imgSize.width+5, imgSize.height+5);
        CGRect money            = CGRectMake(moneyImg.origin.x+moneyImg.size.width+3, moneyImg.origin.y+2, 100, imgSize.height-2);
        
        CGRect overViewImg      = CGRectMake(titleRect.origin.x, imgOfLose.origin.y+imgOfLose.size.height+8, imgSize.width+5, imgSize.height+5);
        CGRect overView         = CGRectMake(overViewImg.origin.x+overViewImg.size.width+3, overViewImg.origin.y, 150, 150);
        
        CGRect closeBtnRect     = CGRectMake(280, 20, 30, 20);
        CGRect finishBtnRect    = CGRectMake(closeBtnRect.origin.x+closeBtnRect.size.width+5, 20, 30, 20);
        CGRect stateImgRect     = CGRectMake(150, 150, 152, 152);
        
        //颜色
        UIColor *hei=[UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:1.0f];
        UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
        UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
        UIColor *huang=[UIColor colorWithRed:0xef/255.0f green:0xd2/255.0f blue:0x6c/255.0f alpha:1.0f];
        
        //label, 标题, 浅蓝, 默认大小17， 改为22.5
        UILabel *label1=[[UILabel alloc] initWithFrame:titleRect];
        [self addSubview:label1];
        [label1 setTextColor:qianlan];
        self.l1=label1;
        [label1 setFont:[UIFont systemFontOfSize:22.5f]];
        //[label1 setBackgroundColor:hei];
        
        //label, 用户昵称, 黑, 18
        UILabel *label2=[[UILabel alloc] initWithFrame:userNameRect];
        [self addSubview:label2];
        [label2 setTextColor:hei];
        self.l2=label2;
        [label2 setFont:[UIFont systemFontOfSize:18]];
        //[label2 setBackgroundColor:hei];
        
        //label, 发布日期, 浅灰, 15
        UILabel *label3=[[UILabel alloc] initWithFrame:dateOfPublish];
        [self addSubview:label3];
        [label3 setTextColor:qianhui];
        self.l3=label3;
        [label3 setFont:[UIFont systemFontOfSize:15]];
        //[label3 setBackgroundColor:hei];
        
        //img, ‘丢失/发现’时间
        //UIImageView *timeView=[[UIImageView alloc] initWithFrame:dateOfLoseImg];
        //[timeView setImage:[UIImage imageNamed:@"biaoshi1.png"]];
        UIImageView *timeView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"biaoshi1@3x.png"]];
        [timeView setCenter:CGPointMake(dateOfLoseImg.origin.x+dateOfLoseImg.size.width/2, dateOfLoseImg.origin.y+dateOfLoseImg.size.height/2)];
        [self addSubview:timeView];
        
        //label, ‘丢失/发现’时间, 浅蓝, 18
        UILabel *label4=[[UILabel alloc] initWithFrame:dateOfLose];
        [self addSubview:label4];
        [label4 setFont:[UIFont systemFontOfSize:12]];
        [label4 setTextColor:qianlan];
        self.l4=label4;
        //[label4 setBackgroundColor:hei];
        
        //img, 地点
        //UIImageView *placeView=[[UIImageView alloc] initWithFrame:placeOfLoseImg];
        //[placeView setImage:[UIImage imageNamed:@"biaoshi2.png"]];
        UIImageView *placeView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"biaoshi2.png"]];
        [placeView setCenter:CGPointMake(placeOfLoseImg.origin.x+placeOfLoseImg.size.width/2.0f, placeOfLoseImg.origin.y+placeOfLoseImg.size.height/2.0f)];
        [self addSubview:placeView];
        
        //label, 地点, 浅蓝, 18
        UILabel *label5=[[UILabel alloc] initWithFrame:placeOfLose];
        [self addSubview:label5];
        [label5 setTextColor:qianlan];
        [label5 setFont:[UIFont systemFontOfSize:12]];
        self.l5=label5;
        //[label5 setBackgroundColor:hei];
        
        //img, 标签
        //UIImageView *tagView=[[UIImageView alloc] initWithFrame:tagImg];
        //[tagView setImage:[UIImage imageNamed:@"biaoshi3.png"]];
        UIImageView *tagView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"biaoshi3.png"]];
        [tagView setCenter:CGPointMake(tagImg.origin.x+tagImg.size.width/2, tagImg.origin.y+tagImg.size.height/2)];
        [self addSubview:tagView];
        
        //label, 标签, 浅蓝
        UILabel *label6=[[UILabel alloc] initWithFrame:tag];
        [self addSubview:label6];
        [label6 setTextColor:qianlan];
        [label6 setFont:[UIFont systemFontOfSize:12]];
        self.l6=label6;
        //[label6 setBackgroundColor:hei];
        
        //img, 赏金
        UIImageView *moneyView=[[UIImageView alloc] initWithFrame:moneyImg];
        [moneyView setImage:[UIImage imageNamed:@"shangjin.png"]];
        [self addSubview:moneyView];
        self.u2=moneyView;
        
        //label, 赏金， 黄, 22
        UILabel *label7=[[UILabel alloc] initWithFrame:money];
        [self addSubview:label7];
        [label7 setFont:[UIFont systemFontOfSize:15]];
        [label7 setTextColor:huang];
        self.l7=label7;
        //[label7 setBackgroundColor:hei];
        
        //img, 物品照片
        UIImageView *thingView=[[UIImageView alloc] initWithFrame:imgOfLose];
        //[thingView setImage:[UIImage imageNamed:@"shangjin.png"]];
        [self addSubview:thingView];
        self.u1=thingView;
        
        //img, 简介
        //UIImageView *overViView=[[UIImageView alloc] initWithFrame:overViewImg];
        //[overViView setImage:[[UIImage imageNamed:@"overView.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        UIImageView *overViView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"jianjie@3x.png"]];
        [overViView setCenter:CGPointMake(overViewImg.origin.x+overViewImg.size.width/2, overViewImg.origin.y+overViewImg.size.height/2)];
        [self addSubview:overViView];
        
        //textfield, 简介, 黑, 18
        UITextView *ut=[[UITextView alloc] initWithFrame:overView];
        [ut setEditable:NO];
        [ut setTextColor:qianlan];
        [ut setFont:[UIFont systemFontOfSize:18]];
        [self addSubview:ut];
        self.tv1=ut;
        
        //‘关闭’按钮
        UIButton *closeBtn=[[UIButton alloc] initWithFrame:closeBtnRect];
        [self addSubview:closeBtn];
        [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
        [closeBtn setTitleColor:qianlan forState:UIControlStateNormal];
        [closeBtn.titleLabel setFont:[UIFont systemFontOfSize:10]];
        [closeBtn.titleLabel setTextAlignment:NSTextAlignmentCenter];
        //[closeBtn setBackgroundColor:hei];
        self.close=closeBtn;
        [closeBtn addTarget:self action:@selector(closeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        
        //‘完成’按钮
        UIButton *finishBtn=[[UIButton alloc] initWithFrame:finishBtnRect];
        [self addSubview:finishBtn];
        [finishBtn setTitle:@"完成" forState:UIControlStateNormal];
        [finishBtn setTitleColor:qianlan forState:UIControlStateNormal];
        [finishBtn.titleLabel setFont:[UIFont systemFontOfSize:10]];
        [finishBtn.titleLabel setTextAlignment:NSTextAlignmentCenter];
        //[finishBtn setBackgroundColor:hei];
        self.finish=finishBtn;
        [finishBtn addTarget:self action:@selector(finishBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        
        //’关闭‘状态视图
        UIImageView *closeImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"closed@3x"]];
        [closeImgView setCenter:CGPointMake(stateImgRect.origin.x+stateImgRect.size.width/2, stateImgRect.origin.y+stateImgRect.size.height/2)];
        [self addSubview:closeImgView];
        [closeImgView setHidden:YES];
        self.closeView=closeImgView;
        
        //‘完成’状态视图
        UIImageView *finishImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"finished@3x"]];
        [finishImgView setCenter:closeImgView.center];
        [self addSubview:finishImgView];
        [finishImgView setHidden:YES];
        self.finishView=finishImgView;
    }
    
    
    //背景色毛玻璃效果
    [self setBackgroundColor:[UIColor clearColor]];
    //设置背景视图
    [self setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"at_di.png"]]];
    //点击不会变为高亮状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    
    return self;
}
-(void)closeBtnAction:(id)sender{
    //执行网络请求
    //...
    [self changeStatus:@"已关闭" idInfo:nil];
    
    //设置控件状态
    [self.closeView setHidden:NO];
    [self.finishView setHidden:YES];
    [self.close setHidden:YES];
    [self.finish setHidden:YES];
}
-(void)finishBtnAction:(id)sender{
    //执行网络请求
    //...
    [self changeStatus:@"已完成" idInfo:nil];
    
    //设置控件状态
    [self.closeView setHidden:YES];
    [self.finishView setHidden:NO];
    [self.close setHidden:YES];
    [self.finish setHidden:YES];
}

-(void)changeStatus:(NSString *)status idInfo:(NSString *)idString{
    
    NSString *domainString=DOMAIN_SET;
    NSString *urlString=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/swzl/changeStatus", domainString];
    NSURL *realUrl=[[NSURL alloc] initWithString:urlString];
    NSString *uidString=[[NSUserDefaults getData:@"userInfo"] objectForKey:@"uid"];
    
    //创建请求体字符串
    NSString *post=[[NSString alloc] initWithFormat:@"status=%@&id=%ld", status, (self.l1.tag-10)];//再警告扁你！！！
    
    //字符串转UTF-8编码方式
    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
    
    //创建请求体
    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
    
    //设置请求方式
    [request setHTTPMethod:@"post"];
    
    //填充请求体
    [request setHTTPBody:postData];
    
    //配置会话
    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    //创建会话
    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"请求完成...");
        if (!error) {
            NSLog(@"成功");
            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
            if ([code isEqualToString:@"1"]) {
                
                NSString *idInfo=[[NSString alloc] initWithFormat:@"%ld", (self.l1.tag-10)];
                [self.mDelegate changeStatus:status idInfo:idInfo];
                
                //通知更新全局数据
                [[NSNotificationCenter defaultCenter] postNotificationName:@"update" object:nil];
                NSLog(@"changestatus\n%@", idInfo);
            } else {
                NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                //加个失败弹窗
            }
        } else {
            NSLog(@"失败， %@", error);
            //加个失败弹窗
        }
    }];
    //执行会话任务
    [task resume];
}
@end
