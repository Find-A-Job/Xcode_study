//
//  wdzhaoling.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol wdzhaolingViewDelegate <NSObject>

@optional
-(NSDictionary *)getDatawdzhaoling;

@end

@interface wdzhaoling : UITableViewController


//ts
@property(strong, nonatomic) NSDictionary *showData;
@property(strong, nonatomic) NSDictionary *imgPool;

@property(weak, nonatomic) id<wdzhaolingViewDelegate> wdzhaolingDelegate;

@end
