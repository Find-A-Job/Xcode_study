//
//  wdxiaoxi.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "wdxiaoxi.h"
#import "cellXiaoxi.h"

@interface wdxiaoxi() <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource>

//cell
@property(strong, nonatomic) NSString *cellIdent;

//datesource
@property(strong, nonatomic) NSDictionary *dateShow;

//textfiled
@property(strong, nonatomic) UITextField *tfEditBox;

//键盘事件
-(void)keyboardUp:(NSNotification *)sender;
-(void)keyboardDown:(NSNotification *)sender;

//done button
-(void)clickDoneBtn;

@end

@implementation wdxiaoxi

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //静态数据
    NSDictionary *d1=[[NSDictionary alloc] initWithObjectsAndKeys:@"钥匙串", @"title", @"老王：有看到一个差不多的", @"msg", @"2018-5-5", @"timeStamp", nil];
    NSDictionary *d2=[[NSDictionary alloc] initWithObjectsAndKeys:@"小首饰", @"title", @"阿秦：我也丢了这个", @"msg", @"2018-6-5", @"timeStamp", nil];
    NSDictionary *d3=[[NSDictionary alloc] initWithObjectsAndKeys:@"手表", @"title", @"泡泡：跟我的好像啊", @"msg", @"2018-7-5", @"timeStamp", nil];
    NSDictionary *d4=[[NSDictionary alloc] initWithObjectsAndKeys:@"身份证", @"title", @"小孙：居然掉在我家附近？！！", @"msg", @"2018-8-5", @"timeStamp", nil];
    NSArray *arr=@[d1, d2, d3, d4];
    self.dateShow=[[NSDictionary alloc] initWithObjectsAndKeys:arr, @"data", nil];
    
    //设置标题
    self.navigationItem.title=@"我的消息";
    
    //导航栏右按钮
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(clickDoneBtn)];
    
    //背景色
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    //重用标识
    self.cellIdent=@"cellOfXiaoxi";
    
    //编辑框
    UITextField *putText=[[UITextField alloc] initWithFrame:CGRectMake(0, 100, 375, 50)];
    [putText setBackgroundColor:[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f]];
    [putText setFont:[UIFont systemFontOfSize:20]];
    [putText setTextColor:[UIColor blackColor]];
    putText.delegate=self;
    [self.view addSubview:putText];
    [putText setHidden:YES];
    self.tfEditBox=putText; 
    
    //tableview
    UITableView *utShow=[[UITableView alloc] initWithFrame:[self.view bounds] style:UITableViewStylePlain];
    utShow.delegate=self;
    utShow.dataSource=self;
    [utShow setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:utShow];
    [self.view sendSubviewToBack:utShow];
    
    //增加额外滚动区域
    [utShow setContentInset:UIEdgeInsetsMake(0, 0, 100, 0)];
    
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
}
//cell
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    cellXiaoxi *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[cellXiaoxi alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    NSArray *arr=[self.dateShow objectForKey:@"data"];
    [cell.title setText:[arr[indexPath.row] objectForKey:@"title"]];
    [cell.msg setText:[arr[indexPath.row] objectForKey:@"msg"]];
    [cell.timeStamp setText:[arr[indexPath.row] objectForKey:@"timeStamp"]];
    
    return cell;
}
//number of cell
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number=0;
    
    NSArray *arr=[self.dateShow objectForKey:@"data"];
    number=[arr count];
    
    return number;
}
//height of cell
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat height=200;
    
    return height;
}
//press '\n'
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.tfEditBox setHidden:YES];
    [textField resignFirstResponder];
    
    return YES;
}
//click 'done' button 
-(void)clickDoneBtn{
    [self.tfEditBox setHidden:NO];
    [self.tfEditBox becomeFirstResponder];
}
//键盘弹起时，获取键盘高度，调整textfiled高度， 显示
-(void)keyboardUp:(NSNotification *)sender{
    NSValue *keyboard=[(NSDictionary *)[sender userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey];
    
    if ([sender.name isEqualToString:UIKeyboardWillShowNotification]) {
        CGRect keyboardRect=[keyboard CGRectValue];
        [self.tfEditBox setCenter:CGPointMake(keyboardRect.size.width/2.0f, keyboardRect.origin.y-self.tfEditBox.bounds.size.height/2.0f-64)];//60
        [self.tfEditBox setHidden:NO];
    }
}
//键盘收起， textfiled隐藏, 清空
-(void)keyboardDown:(NSNotification *)sender{
    if ([sender.name isEqualToString:UIKeyboardWillHideNotification]) {
        [self.tfEditBox setHidden:YES];
        [self.tfEditBox setText:@""];
    }
}
-(void)viewWillDisappear:(BOOL)animated{
    //页面消失，注销相关活动
    NSLog(@"页面隐藏");
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}
-(void)viewDidAppear:(BOOL)animated{
    //监听键盘,设置编辑框高度（在键盘上方），以及注销监听，防止多次监听
    //...
    NSLog(@"页面出现");
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
    //注册键盘事件进行监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDown:) name:UIKeyboardWillHideNotification object:nil];
}
@end
