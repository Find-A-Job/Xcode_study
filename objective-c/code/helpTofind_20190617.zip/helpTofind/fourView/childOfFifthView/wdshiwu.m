//
//  wdshiwu.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "wdshiwu.h"
#import "cellOfwd.h"
#import "../../AFNetworking/AFNetworking.h"
#import "../../dataPersistence/NSUserDefaults+nsUD_cate.h"
#import "../../main/global.h"

@interface wdshiwu() <NSURLSessionDelegate, cellOfwdDelegate>

//cell
@property(nonatomic) NSString *cellIdent;


@end

@implementation wdshiwu

-(void)viewDidLoad{
    [super viewDidLoad];
    
    
    //
    self.cellIdent=@"wdshiwuCell";
    

    
    //设置标题
    self.navigationItem.title=@"我的失物";
    
    //去分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    //隐藏右侧滚动条
    [self.tableView setShowsVerticalScrollIndicator:NO];
    
    //增加额外滚动区域
    [self.tableView setContentInset:UIEdgeInsetsMake(0, 0, 100, 0)];
}

#pragma mark - tableview代理


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    NSInteger number=3;
    NSArray *arr=[self.showData objectForKey:@"myData"];
    number=arr.count;
    
    return number;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat height=700;
    
    return height;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    cellOfwd *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if(!cell){
        cell=[[cellOfwd alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
        cell.mDelegate=self;
    }
    NSArray *arr=[self.showData objectForKey:@"myData"];
    NSDictionary *nsd=arr[indexPath.row];
    //NSDictionary *nsd=((NSArray *)[self.showData objectForKey:@"myData"])[indexPath.row];
    
    //获取字段值
    NSString *l1String=[nsd objectForKey:@"title"];
    NSString *l2String=[nsd objectForKey:@"user_name"];
    NSString *l3String=[nsd objectForKey:@"create_time"];
    NSString *l4String=[nsd objectForKey:@"lose_time"];
    NSString *l5String=[nsd objectForKey:@"address"];
    NSString *l6String=[nsd objectForKey:@"goods_type"];
    NSString *l7String=[nsd objectForKey:@"for_money"];
    NSString *tv1String=[nsd objectForKey:@"resume"];
    NSString *statusString=[nsd objectForKey:@"status"];
    
    l1String=((NSNull *)l1String == [NSNull null] ? @"" : l1String);
    l2String=((NSNull *)l2String == [NSNull null] ? @"" : l2String);
    l3String=((NSNull *)l3String == [NSNull null] ? @"" : [NSString stringWithFormat:@"%@  发布", l3String]);
    l4String=((NSNull *)l4String == [NSNull null] ? @"" : l4String);
    l5String=((NSNull *)l5String == [NSNull null] ? @"" : l5String);
    l6String=((NSNull *)l6String == [NSNull null] ? @"" : l6String);
    l7String=((NSNull *)l7String == [NSNull null] ? @"0" : l7String);
    tv1String=((NSNull *)tv1String == [NSNull null] ? @"" : tv1String);
    statusString=((NSNull *)statusString == [NSNull null] ? @"进行中" : statusString);
    
    //标题
    cell.l1.text=l1String;
    
    //为了区分每个cell的条目id，将数据中ID值放在title的tag里,加10防止0出现,还原记得减10
    cell.l1.tag=[(NSString *)[nsd objectForKey:@"id"] intValue]+10;
    
    //用户,字段修改
    cell.l2.text=l2String;
    
    //为了区分每条数据所在的tablecell，将tablecellIndex值放在username的tag里
    cell.l2.tag=indexPath.row;
    
    //发布时间
    cell.l3.text=l3String;
    
    //丢失/寻找时间
    cell.l4.text=l4String;
    
    //地址
    cell.l5.text=l5String;
    
    //类型
    cell.l6.text=l6String;
    
    //赏金
    if (l7String.doubleValue <= 0) {
        [cell.l7 setHidden:YES];
        [cell.u2 setHidden:YES];
    }else{
        [cell.l7 setHidden:NO];
        [cell.u2 setHidden:NO];
        cell.l7.text=[NSString stringWithFormat:@"%d赏金", l7String.intValue];
    }
    
    //图片
    UIImage *picImg;
    if (self.imgCachePool == nil) {
        picImg=[UIImage imageNamed:@"ka.png"];
    }else{
        picImg=[self.imgCachePool objectForKey:[NSString stringWithFormat:@"%@", [nsd objectForKey:@"id"]]];
    }
    cell.u1.image=picImg;
    
    
    //简介
    cell.tv1.text=tv1String;
    
    //状态
    if ([statusString isEqualToString:@"已关闭"]) {
        [cell.closeView setHidden:NO];
        [cell.finishView setHidden:YES];
        [cell.close setHidden:YES];
        [cell.finish setHidden:YES];
    }else if ([statusString isEqualToString:@"已完成"]) {
        [cell.closeView setHidden:YES];
        [cell.finishView setHidden:NO];
        [cell.close setHidden:YES];
        [cell.finish setHidden:YES];
    }else{
        //字符等于@"进行中"或其他未识别的字符，都视为@"进行中"
        [cell.closeView setHidden:YES];
        [cell.finishView setHidden:YES];
        [cell.close setHidden:NO];
        [cell.finish setHidden:NO];
    }
    
    return cell;
}


#pragma mark - 视图出现和消失
-(void)viewWillAppear:(BOOL)animated{
    
    //刷新tableview
    [self.tableView reloadData];
}
-(void)viewDidAppear:(BOOL)animated{
    NSArray *arr=[self.showData objectForKey:@"myData"];
    if (arr.count<=0) {
        [self popAlert:@"没有相关记录"];
    }
}


#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}


#pragma mark - 懒加载


#pragma mark - 图片缓存




#pragma mark - cellofwd delegate 更新状态

-(void)setDataFromCellOfwdDelegate:(NSDictionary *)neewData{
    
    self.showData=neewData;
}

-(void)gobackAndReset:(NSString *)ccs{
    ;
}

-(void)changeStatus:(NSString *)status idInfo:(NSString *)idInfo{
    //这个视图下的数据需要更新
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    NSMutableArray *newArr=[[NSMutableArray alloc] init];
    
    for (NSDictionary *dic in oldArr) {
        NSString *idString=[NSString stringWithFormat:@"%@",  [dic objectForKey:@"id"]];
        if ([idString isEqualToString:idInfo]) {
            NSMutableDictionary *muDic=[[NSMutableDictionary alloc] init];
            [muDic addEntriesFromDictionary:dic];
            
            [muDic setObject:status forKey:@"status"];
            NSDictionary *newDic=[[NSDictionary alloc] initWithDictionary:muDic];
            
            [newArr addObject:newDic];
            continue;
        }
        [newArr addObject:dic];
    }
    
    self.showData=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
}
@end
