//
//  fourthView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "fourthView.h"
#import "zxCell.h"
#import "articleDetails.h"


@interface fourthView() <UITableViewDelegate, UITableViewDataSource, NSURLSessionDelegate>

//cell重用标识
@property(nonatomic) NSString *cellInedt;

//展示的数据
@property(strong, nonatomic) NSDictionary *dataOfShow;

//
-(void)goToArticleDetails:(id)sender;

@end

@implementation fourthView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //获取数据
    [self getDataFromNetwork];
    
    //部分数据初始化
    self.cellInedt=@"cellForZX";
    
    //静态测试数据，可注释掉
    NSDictionary *dt1=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu1", @"image", @"治安安全知识知多少？防扒、防盗、防抢先了解", @"title", @"蔡宇冠", @"author", @"2019-05-23 11:23:24", @"date", @"安全责任重于泰山，安全问题要人人关注，人人参与。\n\
  今年9月，市委平安办印制了平安（安全）知识宣传手册，图文并茂的形式可是吸引了不少眼球，“杭州教育发布”也从9月开始陆续为大家详细介绍手册的内容。\n\
  今天，小编为大家带来的是“治安安全知识——防扒、防盗、防抢”。\n\
  \n\
  外出如何防盗\n\
  扒手们往往混迹于火车、汽车、轮船等交通工具上伺机作案。以下方法有助于避免损失：\n\
  1. 外出时尽置少带现金和贵重物品；\n\
  \n\
  2. 穿着不要过于讲究，携带贵重物品时神情要若无其事，以免遭人注意；\n\
  3. 夜深人静时，千万不要睡着，因为这是盗窃分子活动的高峰期；\n\
  4. 注意结交可靠的朋友，互相帮助，代为照应。\n\
  安全的椅背套\n\
  顾客进入餐厅就餐，一般都有脱衣习惯，将衣服脱挂在椅背上，随后与亲朋好友或叙谈或小酌，不大注意身后衣服内钱物，这就给偷盗者以可乘之机。偷盗者往往在顾客餐桌临近地方选择好位置，与顾客背靠背，趁顾客不注意时伺机下手盗窃顾客袋内钱物，得手后立即溜之大吉。为此，可以在大众餐厅实用衣套，一旦顾客脱衣后，服务员应立即用衣套套上，避免被不法人员钻空子，造成对顾客的伤害。从服务员的角度上讲，此举也可避免服务员在上菜过程中不慎将汤汁弄脏顾客衣服从而影响服务质量。\n\
  旅途坚持“五不要”\n\
  人在旅途，常因缺乏安全防范意识，给犯罪分子造成可乘之机。所以，为了旅途的安全与愉快，必须坚持“五不要”。\n\
  1. 不要贪心。比如别有用心的人会用放有麻醉物的香烟、饮料、酒以及其他食品请你，你若贪心地蹭几口、喝几杯，必定破产。\n\
  2. 不要粗心。在列车上发生的盗窃案，多半与旅客粗心大意有关，贵重物品、钱款不要放在行李架上或衣帽钩上。\n\
  3. 不要露富。出门时要有用钱的打算，将零整分开，分别保管；还要衣行简朴，不引人注意。\n\
  4. 不要露底。与人闲谈，不要轻易将工作单位、家庭地址及电话和盘托出。\n\
  5. 不要胆小。遇到犯罪分子应勇敢地站出来，动员和运用一切力量或可利用的工具与罪犯作斗争。\n\
  刺毛搭扣\n\
  有一种刺毛搭扣，在扯开封口时会发出“嗤啦啦、嗤啦啦”的响声，而且要用有些力气才拉得开来，可以在每只口袋上都安装这种刺毛搭扣，这样就使小偷知难而退。\n\
  拉链防扒\n\
  从商店买来的衣服，一般来说，内外两面都有口袋，但这些口袋都比较浅，扒手下手比较容易。如果我们在衣服内侧口袋上装一条拉链，外出时，将拉链拉上，那么扒手本事再大也别想轻易得手了。\n\
  \n\
  防抢温馨提示\n\
  1. 在公路边候车、等人时，要注意保管好随身携带的提包、手机等财物，要特别留意两人共乘一辆摩托车在人群中不停地转圈子的人员，防止遭飞抢。\n\
  2. 上夜班的女子不要单身上、下班，要走灯光明亮、行人较多的道路。\n\
  3. 不要在道路上一边行走一边打手机，打手机时要注意左右环视，防止被人抢夺。\n\
  4. 深夜不要到树林茂密的公园、僻静的道路散步、玩耍。\n\
  5. 夜晚去吃饭喝酒、到酒吧夜总会娱乐，亲朋之间要互相照应，有人喝醉要有人守候至其酒醒，或将其送回家，防止醉卧路边或车上被人抢劫。\n\
  6. 万一遭抢，要及时报警并留下家里或亲朋好友的 联系电话，积极为公安机关提供证据，主动协助公安机关打击犯罪，保护自己的权益。\n\
  女性驾车防抢五大绝招\n\
  针对女性驾车者往往容易受到侵害的情况， 警方总结了几条女性驾车防抢注意事项，提醒广大群众注意提高自身防范意识，避免被侵害。\n\
  1. 上车就锁好车门，开车外出务必养成锁车门的习惯；路口遇红灯停车时，若有人敲打门窗， 不要搭理，或者开一条窗缝与其交谈。\n\
  2. 车不要停在僻静处，停车时，首先要选择路 面、亮灯、靠近保安或人多处停车，或选择有人管理、照明良好的地下停车场停车；车停后不要立即下车，确认周围无异常时再开门下车。\n\
  3. 车中不要放贵重财物，行车途中，手机、现金及贵重物品最好放在包里，或放置于隐蔽处，停车离开时，带走皮包、车载导航仪、手提电脑等财物，切勿放置于车厢或后备箱内， 以免招贼。\n\
  4. 遇到擦碰等情况要及时报警，寻求交警、保险公司等第三方介入调处，妥善解决纠纷。在交涉过程中尽量避免争吵、拉扯等行为，防止对方一时冲动而实施伤害等暴力行为。\n\
  5. —般情况不让陌生人搭车，对路边招手搭讪的陌生人要求搭车的， 保持警惕，予以拒绝。\n", @"detail", nil];
    NSDictionary *dt2=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu2", @"image", @"长铁警方传授防扒防盗秘诀", @"title", @"杨洁规", @"author", @"2019-05-23 11:16:59", @"date", @"长铁警方传授防扒防盗秘诀\n\
  发布时间：2019-05-23 11:16:59     作者：杨洁规\n\
  1月20日，长铁警方在长沙火车站候车大厅开展春运安全宣传，通过答题互动、演唱原创歌曲等形式，现场向旅客传授防扒防盗等安全知识，帮助旅客平安踏上返乡路，受到旅客点赞。\n\
  活动现场，民警演示了扒手用剪刀、刀片、镊子行窃的过程，介绍了小偷“挤车门儿”“上架子”“过安检顺包”等行窃招数，向旅客们传授防扒防盗小秘诀。\n\
  “通过看表演，答问题，让我们了解了扒手的作案手法，学到了一些防扒防盗的常识，很受用！”在长沙火车站候车大厅观看视频后，旅客胡先生说。\n\
  防扒防盗小秘诀\n\
  1.无论什么情况下，尽量不要往人堆里扎；\n\
  2.现金及手机等贵重物品不要放在外衣口袋；\n\
  3.在公共场所双肩包或手提袋不要放在身后；\n\
  4.坐在车上不要打盹，提高警惕；\n\
  5.乘车时或其他公共场所不做“低头族”，注意周围情况；\n\
  6.扒手、小偷经常会带一些道具如报纸、衣物来增强作案的隐蔽性，因此要注意提防可疑人物。", @"detail", nil];
    NSDictionary *dt3=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu3", @"image", @"假期旅游应注意 防扒防盗需警惕", @"title", @"气象北京", @"author", @"2019-05-23 11:19:18", @"date", @"假期旅游应注意 防扒防盗需警惕\n\
    发布时间：2019-05-23 11:19:18     作者：气象北京\n\
    小长假就要来临，自驾游、登山游、家庭游，各种出行、旅游活动肯定多起来。但是，别光顾着高兴，假期消费，出行安全，这些方面你得注意下！\n\
    1 交通安全\n\
    越来越多的朋友喜欢自驾游。民警提示司机朋友，要注意行车安全，严格遵守交通法律法规，切记不要酒后驾车、疲劳驾驶。在夜间行车时，要保持比白天更大的车距，车速不宜过快，不强行超车，以免发生追尾、剐蹭等事故。\n\
    另外，如通过乘飞机、坐火车等外出，假期人流大、乘客多，一定要预留充足时间候机、候车，同时，也要多了解相关安检要求，避免出现不必要的麻烦，贻误行程。\n\
    2 户外运动\n\
    开展登山游玩类似的户外活动，要提前做好准备，量力而行，注意自身安全。在出行前，要携带好食物、衣服、急救药品以及必要的装备和通讯工具。不要盲目攀爬情况不熟悉的野山、荒山，或者到未开放的旅游山区和危险山区游玩。\n\
    一旦遇到危险，不要盲目乱打电话，一定要第一时间报警求助，保持通讯畅通，并在原地保存体力等待救援，以防发生其他危险。\n\
    3 看护好老人、孩子\n\
    带着老人、孩子出游时，要做好看护陪同，可提前在老人、孩子身上放好联系卡片，如老人身体不好，也要准备必要的急救药品。如果突发疾病或出现走失等突发情况，民警能以此及时联系到家属，避免发生意外。\n\
    \n\
    防扒小贴士\n\
    出行游玩的季节，在公交车、火车、站点、景区、商场等人流量大、密集度高的公共场所，扒窃类警情易高发。提示大家，外出游玩要加强防范意识，贵重物品要贴身放置，如钱包、手机等要放在衣服和包的内侧口袋。如果发现有人故意挤碰自己，或陌生人总是在身边徘徊，一定要引起注意，保护好自己的财物，及时离开这些可疑人员，也可向有民警或保安人员的地方靠近。必要时，及时拨打110或向附近民警报警。\n\
    \n\
    防盗小贴士\n\
    利用假期外出游玩时，家中无人，如果防范疏忽，小偷伺机入室盗窃。提示大家，出门前几要检查门、窗的安全性。外出时务必要锁好门窗，做好安全防范工作。同时，不要把贵重物品和大额现金放在家中，遇到可疑情况，及时拨打110报警。\n\
    另外，天气持续炎热，许多居民会开窗通风，为方便及时发现可疑情况，大家可在门口挂上铃铛、阳台放上一盆水，一旦发出声响能够及时发现。尤其提醒住在平房或低楼层的居民，要加强安全防范意识，建议加装防护栏等防盗设施，一旦发现家中财物被盗立即报警。（相关内容来自网络", @"detail", nil];
    NSDictionary *dt4=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu4", @"image", @"冬季防扒防盗攻略", @"title", @"陈定南", @"author", @"2019-05-23 11:20:02", @"date", @"冬季防扒防盗攻略\n\
    发布时间：2019-05-23 11:20:02     作者：陈定南\n\
    俗话说：“不怕贼偷，就怕贼惦记”。冬季天气寒冷，人们穿衣服较多较厚，感知度较弱，时扒窃分子相对活跃的季节。如今，小偷扒窃有哪些新花样？市民应该如何防范？\n\
    1公交站等车时\n\
    民警提示：特别上下班高峰期，人流拥挤，在上车或下车一瞬间，造成机会，冬季身体接触警惕性不高。上车时，最好把包往前背，手机一类东西别放口袋，要贴身。\n\
    2进门掀帘时扒窃\n\
  民警提示：窃贼趁大家在掀起食堂、超市的厚重门帘的一瞬间，飞快盗走其身上的钱包、手机。这是近年来扒窃案件高发的又一作案地点。民警提醒，进食堂、商场大门时，要将包放在胸前，外衣兜内不要装有钱包和手机等物品，同时在掀门帘的瞬间要格外留心身边经过的人。\n\
    3餐饮店内扒窃\n\
    民警提示：冬天去饭店吃饭，大家往往会把大衣和包放在身边或身后的椅子上，难免会被窃贼盯上，所以，一定要记住，在点菜或者起身离开座位时，要把财物随身携带或交给同伴看管。\n\
    4街面行走时被尾随扒窃\n\
    民警提示：尽量不要将包背在后面，或斜挎在一侧，最好将包置于前方自己的视野范围之内。现金、钱包不要放置于后侧裤口袋内。\n\
    5在商场内购物时被扒窃\n\
    民警提示：冬季穿的厚重，到商场内试衣试鞋时难免会脱下外套放在一边，这时，小偷就蠢蠢欲动了，所以，任何时候都不要掉以轻心，外衣和背包要放在视线可及的地方。\n\
    6运动场聊天时被扒窃\n\
    民警提示：天气较好的情况下，大家喜欢坐在草坪上聊天，随手将手机、钱包放在一边，这样就给了小偷可乘之机，因此，不管谈意有多浓，一定要将手机、钱包捏在手上。\n\
    以上几点如果你全部掌握了，消息大部分的扒手对你怯而远之，一句话，多一份警惕，才能多一份安全。", @"detail", nil];
    NSDictionary *dt5=[[NSDictionary alloc] initWithObjectsAndKeys:@"tu5", @"image", @"防骗、防扒、防盗……", @"title", @"陈菊", @"author", @"2019-05-23 11:18:10", @"date", @"防骗、防扒、防盗……\n\
    发布时间：2019-05-23 11:18:10     作者：陈菊\n\
  每年，针对女性的盗抢案件时有发生，这是因为和“孔武有力”的男性不同，女性的自卫能力偏弱，防范意识相对不强，如果再加上是单身出行，极易成为不法分子的作案对象。因此，蜀黍专门整理一些必要的防范措施和注意事项，让女性在日常生活中能更好地保护自己。\n\
    防骗篇\n\
    便宜不好捡\n\
    这一类“捡便宜”的诈骗手段以针对中老妇女为主。不法分子往往在菜场、老小区、中老年人活动区域等地，以摆摊、搞促销活动等形式吸引人注意，一旦有女性朋友主动“上门”，他们就几个人一起设套行骗。\n\
    基本套路为一人出售东西，另一个人做“托”，不住地夸赞所卖物品好、赠送产品多、售后服务精等。受害者心动上钩后，最后“自愿”花大笔钱买一堆没用的东西。\n\
    针对这类骗局，一是尽量不要搭理陌生人的问话，二是千万不要相信有“天上掉馅饼”的好事。\n\
    迷信落陷阱\n\
  乡镇地区很多青年都外出拼搏，中老年妇女因为太担心子女容易“胡思乱想”。一些不法分子正是瞧准了这点，打着“神仙菩萨”的名义，或骗中老年妇女说子女在外地不顺，需要花钱消灾，或称买一些祈福用的东西回家能保佑子女平平安安。信以为真的母亲们赶紧回家拿出“私房钱”统统捐给“菩萨”，其实全进了“神棍”的钱包。\n\
    防扒篇\n\
    乘公交车有讲究\n\
    客流量大的公交车一般都是扒窃案件的多发地。对于不法分子来说，依靠拥挤的人群，他们有天然的“地形掩护”方便“下手”，就算被发现也能及时下车逃离。\n\
     女性朋友乘坐公交车时一定要看护好自己的财物，千万别给扒手“机会”。像等车的时候不要把钱包拿出来也不要打手机，不然等于告诉扒手你把财物放在哪里。如果包是拎在手中，最好把包带放长，这样扒手要行窃就必须弯腰，容易识别。\n\
    逛商场包不离身\n\
    逛街购物是女性朋友心态最为放松的时候，但此时也是警惕性最低、最容易被扒窃的时候。\n\
  女性朋友出门血拼，最好不要在外衣、裤子内放置手机、钱包等贵重物品。因为女装很多都是“料少口袋浅”，对于一些“熟练工”来说很容易就能得手。同时，女性朋友在试衣服的时候应将贵重物品放在看得见的地方，最好是随身携带或友人照看，因为商场“龙蛇混杂”，一个不注意就可能损失钱财。\n\
    单身出行需提防\n\
  抢夺一般多发生于乡镇一些偏僻街道。无论是骑自行车、电动车还是步行赶路，对于女士来说，只要是单身出行就最好不要搭理陌生人，特别是那些声称“到那边帮我个忙”等借口的人，如果背了包尽量也别把大量现金和贵重物品放在里面。同时，骑车时包最好不要放在前后车篮中，骑车时遇到有人拍你肩膀、车轮被异物缠绕等情况，应该先拿好包再回头，防止歹徒声东击西。如果有时因特殊情况需要深夜出行，最好找人结伴，千万不要独自去灯光昏暗的地方。\n\
    防盗篇\n\
    睡前要查看门锁情况\n\
  入室盗窃案一般有三个特点，一是选择高层单身公寓，因为这类住宅楼之间邻居几乎没有来往；二是选择半夜人们熟睡之际；三是冲着老小区门锁老旧或是根本没锁防盗门的人家入手。所以，女性朋友为了自身的安全，睡觉前应仔细查看防盗门或屋门是否锁好，门窗是否关好。为了防止歹徒攀援入室，空调架安装要规范，有必要的还可以在落水管上抹机油。如果是一人在家，一定要把手机或电话放在边上，这样一旦遇上危险也能第一时间报警。\n\
    陌生人敲门别轻易开\n\
    单身女性还需特别防范一种发生率不高但性质恶劣的犯罪现象：入室抢劫。\n\
    有些犯罪分子专门瞄准那些单身独居的女士下手。\n\
    根据往年类似案情来看，犯罪分子很多都借用查水表、送包裹信件等借口进入室内后进行胁迫抢劫。\n\
    蜀黍提醒单身居住的女性朋友注意，如果有陌生人上门，送东西的话就让他放门口，真要有重要事情，也一定要先让对方出示有关证件证实身份后再看情况开门。\n\
  最后，蜀黍提醒广大女性朋友：从很多侵害女性的案件看来，犯罪嫌疑人的作案手段其实并不高明，他们只是利用某些女性的心理弱点、行为漏洞进行引诱糊弄，最后再行骗。因此广大女性朋友一定要筑牢自己的心理防线，时刻保持警惕和头脑清醒，不要因为一些蝇头小利或是一时的疏忽大意给犯罪分子可乘之机。", @"detail", nil];
    
    NSArray *allDataArr=@[dt1, dt2, dt3, dt4, dt5];
    NSDictionary *alldataDic=[[NSDictionary alloc] initWithObjectsAndKeys:allDataArr, @"data", nil];
    self.dataOfShow=alldataDic;
    
    //背景
    CGFloat bkViewY=self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height;
    CGFloat bkViewWidth=self.navigationController.navigationBar.frame.size.width;
    CGFloat bkViewHeight=[self.uzd getTabbarRect].origin.y-bkViewY;
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bkViewWidth, bkViewHeight)];
    [self.view addSubview:bkView];
    [bkView setImage:[UIImage imageNamed:@"di.png"]];
    [bkView setUserInteractionEnabled:YES];
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    //尺寸
    CGSize screenSize=CGSizeMake([[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    CGFloat leftSpacing=10;
    CGFloat upSpacing=20;
    CGPoint tableViewPoint=CGPointMake(leftSpacing, upSpacing);
    CGSize tableViewSize=CGSizeMake(screenSize.width-2*leftSpacing, screenSize.height);
    
    //主
    UITableView *mainTableView=[[UITableView alloc] initWithFrame:CGRectMake(tableViewPoint.x, tableViewPoint.y, tableViewSize.width, tableViewSize.height) style:UITableViewStylePlain];
    [bkView addSubview:mainTableView];
    [mainTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];//去分割线
    [mainTableView setShowsVerticalScrollIndicator:NO];//隐藏右侧滚动条
    [mainTableView setDelegate:self];
    [mainTableView setDataSource:self];
    [mainTableView setBackgroundColor:[UIColor clearColor]];
    
    [mainTableView setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];//增加额外滚动范围
}

#pragma mark - get data

-(void)getDataFromNetwork{
    
    
//    NSString *url=[[NSString alloc] initWithFormat:@"http://lmr.cocosplanet.com/Home/Mall/getBeauticiansJson.html"];
//    NSURL *realUrl=[[NSURL alloc] initWithString:url];
//
//    //创建请求体字符串
//    NSString *post=@"type=1";
//
//    //字符串转UTF-8编码方式
//    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
//
//    //创建请求体
//    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
//
//    //设置请求方式
//    [request setHTTPMethod:@"post"];
//
//    //填充请求体
//    [request setHTTPBody:postData];
//
//    //配置会话
//    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
//
//    //创建会话
//    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:[NSOperationQueue mainQueue]];
//    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
//        NSLog(@"请求完成...");
//        if (!error) {
//            NSLog(@"成功");
//            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//            NSArray *sec=[nd objectForKey:@"data"];
//            NSDictionary *secc=sec[0];
//            NSString *s=[secc objectForKey:@"name"];
//            NSString *s2=[secc objectForKey:@"short_intro"];
//
//            NSLog(@"%@, %@, %@", s, s2, [secc objectForKey:@"avatar"]);
//
//        } else {
//            NSLog(@"失败， %@", error);
//        }
//    }];
//    //执行会话任务
//    [task resume];
    
}

#pragma mark - tableviewdelegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number=0;
    if (section==0) {
        NSArray *arr=[self.dataOfShow objectForKey:@"data"];
        number=(NSInteger)[arr count];
    }
    
    
    return number;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 150;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    zxCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellInedt];
    
    if(!cell){
        cell=[[zxCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellInedt];
    }
    NSArray *arr=[self.dataOfShow objectForKey:@"data"];
    [cell.leftImg setImage:[UIImage imageNamed:[arr[indexPath.row] objectForKey:@"image"]]];
    cell.titleLabel.text=[arr[indexPath.row] objectForKey:@"title"];
    cell.authorLabel.text=[arr[indexPath.row] objectForKey:@"author"];
    cell.dateLabel.text=[arr[indexPath.row] objectForKey:@"date"];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    articleDetails *ad=[[articleDetails alloc] init];
    
    //ad.articleTextView.text=[[self.dataOfShow objectForKey:@"data"][indexPath.row] objectForKey:@"detail"] ;
    ad.showArticle=[[self.dataOfShow objectForKey:@"data"][indexPath.row] objectForKey:@"detail"];
    [ad setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:ad animated:YES];
}

-(void)goToArticleDetails:(id)sender{
    articleDetails *ad=[[articleDetails alloc] init];
    [self.navigationController pushViewController:ad animated:YES];
}

#pragma mark - gotoView

-(void)gotoView:(id)where{
    UIViewController *w=where;
    
    [w setHidesBottomBarWhenPushed:YES];
    
    [self.navigationController pushViewController:w animated:YES];
}


#pragma mark - touch

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //收起按钮弹窗
    [self.uzd hidePopView];
}


@end
