//
//  fourthView.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "userzmxDelegate.h"

@interface fourthView : UIViewController

@property(strong, nonatomic) id<userzmxDegelate> uzd;


-(void)gotoView:(id)where;

@end

