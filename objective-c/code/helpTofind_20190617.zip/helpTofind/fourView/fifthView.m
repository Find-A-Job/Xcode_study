//
//  fifthView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "fifthView.h"
#import "wdshiwu.h"
#import "wdzhaoling.h"
#import "wdxiaoxi.h"
#import "wdziliao.h"
#import "userzmxDelegate.h"
#import "../dataPersistence/NSUserDefaults+nsUD_cate.h"
#import "../main/global.h"

@interface fifthView() <userzmxDegelate, wdshiwuViewDelegate, wdzhaolingViewDelegate, NSURLSessionDelegate>

@property(nonatomic) BOOL isLogin;
@property(strong, nonatomic) NSString *changeString;

//4个视图
@property(strong, nonatomic)wdshiwu *wdshiwuVC;
@property(strong, nonatomic)wdzhaoling *wdzhaolingVC;
@property(strong, nonatomic)wdxiaoxi *wdxiaoxiVC;
@property(strong, nonatomic)wdziliao *wdziliaoVC;

//按钮
@property(strong, nonatomic) UIButton *b1;
@property(strong, nonatomic) UIButton *b2;
@property(strong, nonatomic) UIButton *b3;
@property(strong, nonatomic) UIButton *b4;

//按钮响应事件
-(void)b1Click:(id)sender;
-(void)b2Click:(id)sender;
-(void)b3Click:(id)sender;
-(void)b4Click:(id)sender;

@property(strong, nonatomic)NSDictionary *otherData;//其他视图需要的数据

//全局数据
@property(strong, atomic)NSDictionary *showData;
@property(strong, atomic)NSDictionary *imgCachePool;

@end

@implementation fifthView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //背景
    CGFloat bkViewY=self.navigationController.navigationBar.frame.origin.y+self.navigationController.navigationBar.frame.size.height;
    CGFloat bkViewWidth=self.navigationController.navigationBar.frame.size.width;
    CGFloat bkViewHeight=[self.uzd getTabbarRect].origin.y-bkViewY;
    UIImageView *bkView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bkViewWidth, bkViewHeight)];
    [self.view addSubview:bkView];
    [bkView setImage:[UIImage imageNamed:@"di.png"]];
    
    //
    CGFloat buttonWidth=360;
    CGFloat buttonHeight=120;
    CGFloat startY=0;
    CGFloat buttonX=8;
    CGFloat spacingOfButton=5;
    CGFloat b1y=startY;
    CGFloat b2y=startY+buttonHeight+spacingOfButton;
    CGFloat b3y=startY+2*(buttonHeight+spacingOfButton);
    
    //调整4号位置,若要恢复，将old取消注释，将new注释掉，并在该文件的warning add 处取消一个注释
    //CGFloat b4y=startY+3*(buttonHeight+spacingOfButton);//old
    CGFloat b4y=startY+2*(buttonHeight+spacingOfButton);//new
    
    //我的失物
    UIButton *wdsw=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b1y, buttonWidth, buttonHeight)];
    self.b1=wdsw;
    [wdsw setBackgroundImage:[UIImage imageNamed:@"wdswuBK.png"] forState:UIControlStateNormal];
    [wdsw setBackgroundImage:[UIImage imageNamed:@"wdswuBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdsw];
    [wdsw setTitle:@"我的失物" forState:UIControlStateNormal];
    [wdsw setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdsw addTarget:self action:@selector(b1Click:) forControlEvents:UIControlEventTouchUpInside];
    
    //我的招领
    UIButton *wdzliao=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b2y, buttonWidth, buttonHeight)];
    self.b2=wdzliao;
    [wdzliao setBackgroundImage:[UIImage imageNamed:@"wdzlingBK.png"] forState:UIControlStateNormal];
    [wdzliao setBackgroundImage:[UIImage imageNamed:@"wdzlingBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdzliao];
    [wdzliao setTitle:@"我的招领" forState:UIControlStateNormal];
    [wdzliao setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdzliao addTarget:self action:@selector(b2Click:) forControlEvents:UIControlEventTouchUpInside];
    
    //我的消息,2019-6-17去掉”我的消息“功能
    UIButton *wdxx=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b3y, buttonWidth, buttonHeight)];
    self.b3=wdxx;
    [wdxx setBackgroundImage:[UIImage imageNamed:@"wdxxiBK.png"] forState:UIControlStateNormal];
    [wdxx setBackgroundImage:[UIImage imageNamed:@"wdxxiBK.png"] forState:UIControlStateHighlighted];
#warning add
    //[self.view addSubview:wdxx];
    [wdxx setTitle:@"我的消息" forState:UIControlStateNormal];
    [wdxx setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdxx addTarget:self action:@selector(b3Click:) forControlEvents:UIControlEventTouchUpInside];
    
    //我的资料
    UIButton *wdzl=[[UIButton alloc] initWithFrame:CGRectMake(buttonX, b4y, buttonWidth, buttonHeight)];
    self.b4=wdzl;
    [wdzl setBackgroundImage:[UIImage imageNamed:@"wdzliaoBK.png"] forState:UIControlStateNormal];
    [wdzl setBackgroundImage:[UIImage imageNamed:@"wdzliaoBK.png"] forState:UIControlStateHighlighted];
    [self.view addSubview:wdzl];
    [wdzl setTitle:@"我的资料" forState:UIControlStateNormal];
    [wdzl setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [wdzl addTarget:self action:@selector(b4Click:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark - 视图消失和出现

-(void)viewWillAppear:(BOOL)animated{
    //接收通知，数据加载完成和加载失败
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finish:) name:@"userDataDownloadFinish" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fail:) name:@"userDataDownloadFail" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imgCacheFinish:) name:@"userimgCacheFinish" object:nil];
    
    //判断是否已经登录
    NSString *statusOfLogin=[NSUserDefaults getData:@"isLogin"];
    if (!statusOfLogin) {
        [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
        self.isLogin=NO;
    }else{
        if ([statusOfLogin isEqualToString:@"yes"]) {
            self.isLogin=YES;
            
            //已登录，则获取数据
            
            //数据筛选
            self.showData=[self.uzd getUserData_all];
            self.imgCachePool=[self.uzd getUserImgCachePool];
            
            
        }else if ([statusOfLogin isEqualToString:@"no"]){
            self.isLogin=NO;
        }
        else {
            NSLog(@"unknow value of key \"inLogin\"");
            self.isLogin=NO;
        }
    }
    

}

-(void)viewWillDisappear:(BOOL)animated{
    
    //移除通知响应
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"userDataDownloadFinish" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"userDataDownloadFail" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"userimgCacheFinish" object:nil];
    
}

#pragma mark - 懒加载

-(wdshiwu *)wdshiwuVC{
    if (!_wdshiwuVC) {
        _wdshiwuVC=[[wdshiwu alloc] init];
    }
    
    return _wdshiwuVC;
}
-(wdzhaoling *)wdzhaolingVC{
    if (!_wdzhaolingVC) {
        _wdzhaolingVC=[[wdzhaoling alloc] init];
    }
    
    return _wdzhaolingVC;
}
-(wdxiaoxi *)wdxiaoxiVC{
    if (!_wdxiaoxiVC) {
        _wdxiaoxiVC=[[wdxiaoxi alloc] init];
    }
    
    return _wdxiaoxiVC;
}
-(wdziliao *)wdziliaoVC{
    if (!_wdziliaoVC) {
        _wdziliaoVC=[[wdziliao alloc] init];
    }
    
    return _wdziliaoVC;
}

#pragma mark - click

-(void)b1Click:(id)sender{
    //我的失物 按钮
    
    if (!self.isLogin) {
        UIViewController *loginVCObj=[self.uzd getLoginVC];
        [self presentViewController:loginVCObj animated:YES completion:nil];
    } else {
        wdshiwu *wd=self.wdshiwuVC;
        wd.wdshiwuDelegate=self;
        
        //筛选出"我的失物"
        if (self.showData != nil) {
            NSArray *oldArr=[self.showData objectForKey:@"myData"];
            NSMutableArray *newArr=[[NSMutableArray alloc] init];
            
            for (NSDictionary *dic in oldArr) {
                if ([[dic objectForKey:@"item_type"] isEqualToString:@"失物"]) {
                    [newArr addObject:dic];
                }
            }
            
            if (newArr.count<=0) {
                wd.showData=nil;
            }else{
                NSArray *newArr2=[[NSArray alloc] initWithArray:newArr];
                wd.showData=[[NSDictionary alloc] initWithObjectsAndKeys:newArr2, @"myData", nil];
            }
        }
        
        wd.imgCachePool=self.imgCachePool;
        
        NSLog(@"进入\"我的失物\"视图");
        [wd setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:wd animated:YES];
    }
}
-(void)b2Click:(id)sender{
    //我的招领 按钮

    if (!self.isLogin) {
        UIViewController *loginVCObj=[self.uzd getLoginVC];
        [self presentViewController:loginVCObj animated:YES completion:nil];
    } else {
        
        wdzhaoling *wd=self.wdzhaolingVC;
        wd.wdzhaolingDelegate=self;
        
        //筛选出"我的失物"
        if (self.showData != nil) {
            NSArray *oldArr=[self.showData objectForKey:@"myData"];
            NSMutableArray *newArr=[[NSMutableArray alloc] init];
            
            for (NSDictionary *dic in oldArr) {
                if ([[dic objectForKey:@"item_type"] isEqualToString:@"招领"]) {
                    [newArr addObject:dic];
                }
            }
            
            if (newArr.count<=0) {
                wd.showData=nil;
            }else{
                NSArray *newArr2=[[NSArray alloc] initWithArray:newArr];
                wd.showData=[[NSDictionary alloc] initWithObjectsAndKeys:newArr2, @"myData", nil];
            }
        }
        
        wd.imgPool=self.imgCachePool;
        
        NSLog(@"进入\"我的招领\"视图");
        [wd setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:wd animated:YES];
    }
}
-(void)b3Click:(id)sender{
    //我的消息 按钮

    if (!self.isLogin) {
        UIViewController *loginVCObj=[self.uzd getLoginVC];
        [self presentViewController:loginVCObj animated:YES completion:nil];
    } else {
        wdxiaoxi *wd=[[wdxiaoxi alloc] init];
        [wd setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:wd animated:YES];
    }
}
-(void)b4Click:(id)sender{
    //我的资料 按钮

    
    if (!self.isLogin) {
        UIViewController *loginVCObj=[self.uzd getLoginVC];
        [self presentViewController:loginVCObj animated:YES completion:nil];
    } else {
        wdziliao *wd=[[wdziliao alloc] init];
        wd.uzd=self;
        [wd setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:wd animated:YES];
    }
}
-(CGRect)getTabbarRect{
    return [self.uzd getTabbarRect];
}


#pragma mark - gotoView

-(void)gotoView:(id)where{
    UIViewController *w=where;
    
    [w setHidesBottomBarWhenPushed:YES];
    
    [self.navigationController pushViewController:w animated:YES];
}


#pragma mark - touch

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //收起按钮弹窗
    [self.uzd hidePopView];
}


#pragma mark - logout set bool no

-(void)logoutFromWDZL{
    
    [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
    [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"", @"value", @"userInfo", @"key", nil]];
    
}

#pragma mark - 获取数据并跳转
-(void)getDataFromNetwork:(nullable id)p toview:(UIViewController *)wd item_type:(NSString *)typeString{
    
    //toview wd, item_type typeString
    
    NSString *domainString=DOMAIN_SET;
    NSString *urlString=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/swzl/swzlLists", domainString];
    NSURL *realUrl=[[NSURL alloc] initWithString:urlString];
    NSString *uidString=[[NSUserDefaults getData:@"userInfo"] objectForKey:@"uid"];
    
    //创建请求体字符串
    NSString *post=[[NSString alloc] initWithFormat:@"uid=%@", uidString];
    
    //字符串转UTF-8编码方式
    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
    
    //创建请求体
    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
    
    //设置请求方式
    [request setHTTPMethod:@"post"];
    
    //填充请求体
    [request setHTTPBody:postData];
    
    //配置会话
    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    //创建会话
    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"请求完成...");
        if (!error) {
            NSLog(@"成功");
            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
            if ([code isEqualToString:@"1"]) {
                //储存为字典
                NSArray *myData=[nd objectForKey:@"data"];
                
                NSMutableArray *tempData=[[NSMutableArray alloc] init];
                //筛选出-我的失物
                for (NSDictionary *eachData in myData) {
                    //\u5931\u7269, 失物
                    NSString *type=[NSString stringWithFormat:@"%@", [eachData objectForKey:@"item_type"]];
                    if ([type isEqualToString:typeString]) {
                        [tempData addObject:eachData];
                    }
                }
                NSArray *finallyData=[NSArray arrayWithArray:tempData];
                
                //记录数据
                self.otherData=[[NSDictionary alloc] initWithObjectsAndKeys:finallyData, @"myData", nil];
                
                //跳转
                [wd setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
                [self.navigationController pushViewController:wd animated:YES];
            } else {
                NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                //加个失败弹窗
                [self popAlert:[nd objectForKey:@"msg"]];
            }
        } else {
            NSLog(@"失败， %@", error);
            //加个失败弹窗
        }
    }];
    //执行会话任务
    [task resume];
}

-(NSDictionary *)getDatawdshiwu{
    
    return self.otherData;
}

-(NSDictionary *)getDatawdzhaoling{
    
    return self.otherData;
}


#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}

#pragma mark - 懒加载

-(NSString *)changeString{
    
    if (!_changeString) {
        _changeString=[[NSString alloc] init];
    }
    
    return _changeString;
}

#pragma mark - 状态更新

-(void)ssetChangeString:(NSString *)changeString{
    self.changeString=changeString;
}

#pragma mark - 通知

-(void)finish:(NSNotification *)noti{
    NSLog(@"收到数据缓存完成通知");

    
    //判断是否已经登录
    if (self.isLogin == YES) {
        NSDictionary *fData=[noti object];
        
        self.showData=fData;
//        if (self.showData != nil) {
//            NSArray *oldArr=[self.showData objectForKey:@"myData"];
//            NSMutableArray *newArr=[[NSMutableArray alloc] init];
//
//
//            //已经登录，则获取uid
//            NSDictionary *userInfo=[NSUserDefaults getData:@"userInfo"];
//            NSString *uid=[NSString stringWithFormat:@"%@", [userInfo objectForKey:@"uid"]];
//
//            for (NSDictionary *dic in oldArr) {
//                NSString *uString=[NSString stringWithFormat:@"%@", [dic objectForKey:@"uid"]];
//                if ([uString isEqualToString:uid]) {
//                    [newArr addObject:dic];
//                }
//            }
//
//            if (newArr.count<=0) {
//                self.showData=nil;
//            }else{
//                NSArray *newArr2=[[NSArray alloc] initWithArray:newArr];
//                self.showData=[[NSDictionary alloc] initWithObjectsAndKeys:newArr2, @"myData", nil];
//            }
//        }
        
        
        //[self.wdshiwuVC.tableView reloadData];
    }
    
}

-(void)fail:(NSNotification *)noti{
    NSLog(@"receive fail noticifity");
    
}

-(void)imgCacheFinish:(NSNotification *)noti{
    NSLog(@"收到图片缓存完成通知");
    self.imgCachePool=[noti object];
    //[self.wdshiwuVC.tableView reloadData];
    
    //NSLog(@"%@", self.imgCachePool);
}
@end
