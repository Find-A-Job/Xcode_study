//
//  viewWithDropList.m
//  helpTofind
//
//  Created by rdt on 2019/5/10.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "viewWithDropList.h"

@implementation viewWithDropList

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
//tableView超出父视图，重写hittest
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
UIView *view = [super hitTest:point withEvent:event];
if (view == nil)
    {
    // 转换坐标系
    CGPoint newPoint = [[self.tableViewDelegate getTableView] convertPoint:point fromView:self];
        // 判断触摸点是否在button上
        if (CGRectContainsPoint([self.tableViewDelegate getTableView].bounds, newPoint))
        {
            view =[self.tableViewDelegate getTableView];
        }
    }
    return view;
    
}

@end
