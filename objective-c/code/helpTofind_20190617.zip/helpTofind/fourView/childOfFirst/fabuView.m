//
//  fabuView.m
//  helpTofind
//
//  Created by rdt on 2019/5/8.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "fabuView.h"
#import "dropListCell.h"
#import "viewWithDropList.h"
#import "../../AFNetworking/AFNetworking.h"
#import "../../main/global.h"
#import "../../dataPersistence/NSUserDefaults+nsUD_cate.h"

@interface fabuView () <UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource, viewWithDropListDelegate>

//只设置了部分tag
@property(strong, nonatomic) UITextField *titleText;//标题,tag:100
@property(strong, nonatomic) UITextField *timeText;//时间,tag:101
@property(strong, nonatomic) UITextField *moneyText;//赏金,tag:102
@property(strong, nonatomic) UITextField *placeText;//地点,tag:103
@property(strong, nonatomic) UITextField *phoneText;//电话,tag:104
@property(strong, nonatomic) UITextField *overviewText;//简介,tag:105
@property(strong, nonatomic) UIButton *typeBtn;//类型,tag:106
@property(strong, nonatomic) UITableView *dropListView;//下拉框,tag:107
@property(strong, nonatomic) NSDictionary *arrOfDropList;
@property(strong, nonatomic) NSString *cellIdent;
@property(nonatomic)CGRect r;
@property(strong, nonatomic) UIButton *imgBtn;//图片选择按钮，bkimg就是被选择的图片,tag:108
@property(strong, nonatomic) NSURL *imgBtnURL;
//发布按钮回调
-(void)fabuBtnClick:(id)sender;

//选择图片按钮回调
-(void)chooseImgClick:(id)sender;

//选择类型按钮回调
-(void)chooseTypeClick:(id)sender;

@end

@implementation fabuView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    UIColor *shurukuang=[UIColor colorWithRed:0xec/255.0f green:0xf3/255.0f blue:0xfe/255.0f alpha:1.0f];
    self.cellIdent=@"dropListCell";
    
    self.arrOfDropList=[[NSDictionary alloc] initWithObjectsAndKeys:@"卡包", @"1", @"电子", @"2", @"饰品", @"3", @"文件", @"4", @"宠物", @"5", @"其他", @"6", nil];
    
    
    //导航栏右按钮
    UIBarButtonItem *rightBtn=[[UIBarButtonItem alloc] initWithTitle:@"发布" style:UIBarButtonItemStylePlain target:self action:@selector(fabuBtnClick:)];
    [rightBtn setTintColor:[UIColor whiteColor]];
    [self.navigationItem setRightBarButtonItem:rightBtn];
    
    //背景图片
    UIImageView *uibk=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    UIImage *sclViewBkImg=[UIImage imageNamed:@"shouYebg.png"];
    sclViewBkImg=[sclViewBkImg stretchableImageWithLeftCapWidth:sclViewBkImg.size.width*0.3f topCapHeight:sclViewBkImg.size.height*0.3f];
    uibk.image=sclViewBkImg;
    [self.view addSubview:uibk];
    
    //滚动视图
    UIScrollView *scrollViewBk=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    [self.view addSubview:scrollViewBk];
    [scrollViewBk setContentSize:CGSizeMake(0, scrollViewBk.bounds.size.height+500)];
    [scrollViewBk setShowsVerticalScrollIndicator:NO];
    //[scrollViewBk setBackgroundColor:[UIColor clearColor]];
    
    
    
    //加入4个视图
    UIImage *fourImg=[UIImage imageNamed:@"buttonViewBk.png"];
    fourImg=[fourImg stretchableImageWithLeftCapWidth:fourImg.size.width*0.2f topCapHeight:fourImg.size.height*0.2f];
    UIImageView *firstView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, 300)];
    firstView.image=fourImg;
    [scrollViewBk addSubview:firstView];
    [firstView setUserInteractionEnabled:YES];
    
    viewWithDropList *secondView=[[viewWithDropList alloc] initWithFrame:CGRectMake(0, firstView.frame.origin.y+firstView.bounds.size.height, winWidth, 80)];
    secondView.image=fourImg;
//    [scrollViewBk addSubview:secondView];
    secondView.tableViewDelegate=self;
    [secondView setUserInteractionEnabled:YES];
    
    UIImageView *thirdView=[[UIImageView alloc] initWithFrame:CGRectMake(0, secondView.frame.origin.y+secondView.bounds.size.height, winWidth, 200)];
    thirdView.image=fourImg;
    [scrollViewBk addSubview:thirdView];
    [thirdView setUserInteractionEnabled:YES];
    
    UIImageView *fourVied=[[UIImageView alloc] initWithFrame:CGRectMake(0, thirdView.frame.origin.y+thirdView.bounds.size.height, winWidth, winWidth+100)];
    fourVied.image=fourImg;
    [scrollViewBk addSubview:fourVied];
    [fourVied setUserInteractionEnabled:YES];
    
    [scrollViewBk addSubview:secondView];
    
    
    //控件
    CGFloat labLeftOffset=20;
    CGFloat labUpOfset=20;
    CGFloat labWidth=70;
    CGFloat spacingOfLabAndEditbox=5;
    CGFloat editBoxWidth=(winWidth-2*labLeftOffset-labWidth-spacingOfLabAndEditbox);
    CGFloat controlHeight=(firstView.bounds.size.height-2*labUpOfset)/5;
    
    
    
    
    //信息标题
    UILabel *title=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, labUpOfset, labWidth, controlHeight)];
    title.text=@"信息标题";
    title.textColor=qianlan;
    title.font=[UIFont systemFontOfSize:16];
    [firstView addSubview:title];
    //[title setBackgroundColor:[UIColor orangeColor]];
    
    UITextField *titleEditBox=[[UITextField alloc] initWithFrame:CGRectMake(0, 0, editBoxWidth, controlHeight-10)];
    titleEditBox.center=title.center;
    CGRect editboxFrame=titleEditBox.frame;
    editboxFrame.origin.x=title.frame.origin.x+title.frame.size.width+spacingOfLabAndEditbox;
    titleEditBox.frame=editboxFrame;
    [firstView addSubview:titleEditBox];
    [titleEditBox setBackgroundColor:shurukuang];
    [titleEditBox.layer setCornerRadius:12];//圆角度数
    [titleEditBox.layer setMasksToBounds:YES];//圆角遮罩
    [titleEditBox setDelegate:self];
    self.titleText=titleEditBox;
    
    
    
    
    //丢失时间
    UILabel *labLoseTime=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, title.frame.origin.y+title.bounds.size.height, labWidth, controlHeight)];
    labLoseTime.text=@"丢失时间";
    labLoseTime.textColor=qianlan;
    labLoseTime.font=[UIFont systemFontOfSize:16];
    [firstView addSubview:labLoseTime];
    //[labLoseTime setBackgroundColor:[UIColor orangeColor]];
    
    UITextField *LoseTimeEditBox=[[UITextField alloc] initWithFrame:CGRectMake(0, 0, editBoxWidth, controlHeight-10)];
    LoseTimeEditBox.center=labLoseTime.center;
    editboxFrame=LoseTimeEditBox.frame;
    editboxFrame.origin.x=title.frame.origin.x+title.frame.size.width+spacingOfLabAndEditbox;
    LoseTimeEditBox.frame=editboxFrame;
    [firstView addSubview:LoseTimeEditBox];
    [LoseTimeEditBox setBackgroundColor:shurukuang];
    [LoseTimeEditBox.layer setCornerRadius:12];//圆角度数
    [LoseTimeEditBox.layer setMasksToBounds:YES];//圆角遮罩
    [LoseTimeEditBox setDelegate:self];
    self.timeText=LoseTimeEditBox;
    
    
    
    
    
    //悬赏金额
    UILabel *labMoney=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, labLoseTime.frame.origin.y+labLoseTime.bounds.size.height, labWidth, controlHeight)];
    labMoney.text=@"悬赏金额";
    labMoney.textColor=qianlan;
    labMoney.font=[UIFont systemFontOfSize:16];
    [firstView addSubview:labMoney];
    //[labMoney setBackgroundColor:[UIColor orangeColor]];
    
    UITextField *moneyEditBox=[[UITextField alloc] initWithFrame:CGRectMake(0, 0, editBoxWidth, controlHeight-10)];
    moneyEditBox.center=labMoney.center;
    editboxFrame=moneyEditBox.frame;
    editboxFrame.origin.x=title.frame.origin.x+title.frame.size.width+spacingOfLabAndEditbox;
    moneyEditBox.frame=editboxFrame;
    [firstView addSubview:moneyEditBox];
    [moneyEditBox setBackgroundColor:shurukuang];
    [moneyEditBox.layer setCornerRadius:12];//圆角度数
    [moneyEditBox.layer setMasksToBounds:YES];//圆角遮罩
    [moneyEditBox setDelegate:self];
    self.moneyText=moneyEditBox;
    self.moneyText.tag=102;
    
    
    
    //丢失地点
    UILabel *labLosePlace=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, labMoney.frame.origin.y+labMoney.bounds.size.height, labWidth, controlHeight)];
    labLosePlace.text=@"丢失地点";
    labLosePlace.textColor=qianlan;
    labLosePlace.font=[UIFont systemFontOfSize:16];
    [firstView addSubview:labLosePlace];
    //[labLosePlace setBackgroundColor:[UIColor orangeColor]];
    
    UITextField *losePlaceEditBox=[[UITextField alloc] initWithFrame:CGRectMake(0, 0, editBoxWidth, controlHeight-10)];
    losePlaceEditBox.center=labLosePlace.center;
    editboxFrame=losePlaceEditBox.frame;
    editboxFrame.origin.x=title.frame.origin.x+title.frame.size.width+spacingOfLabAndEditbox;
    losePlaceEditBox.frame=editboxFrame;
    [firstView addSubview:losePlaceEditBox];
    [losePlaceEditBox setBackgroundColor:shurukuang];
    [losePlaceEditBox.layer setCornerRadius:12];//圆角度数
    [losePlaceEditBox.layer setMasksToBounds:YES];//圆角遮罩
    [losePlaceEditBox setDelegate:self];
    self.placeText=losePlaceEditBox;
    
    
    
    
    
    //联系电话
    UILabel *labPhone=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, labLosePlace.frame.origin.y+labLosePlace.bounds.size.height, labWidth, controlHeight)];
    labPhone.text=@"联系电话";
    labPhone.textColor=qianlan;
    labPhone.font=[UIFont systemFontOfSize:16];
    [firstView addSubview:labPhone];
    //[labPhone setBackgroundColor:[UIColor orangeColor]];
    
    UITextField *phoneEditBox=[[UITextField alloc] initWithFrame:CGRectMake(0, 0, editBoxWidth, controlHeight-10)];
    phoneEditBox.center=labPhone.center;
    editboxFrame=phoneEditBox.frame;
    editboxFrame.origin.x=title.frame.origin.x+title.frame.size.width+spacingOfLabAndEditbox;
    phoneEditBox.frame=editboxFrame;
    [firstView addSubview:phoneEditBox];
    [phoneEditBox setBackgroundColor:shurukuang];
    [phoneEditBox.layer setCornerRadius:12];//圆角度数
    [phoneEditBox.layer setMasksToBounds:YES];//圆角遮罩
    [phoneEditBox setDelegate:self];
    self.phoneText=phoneEditBox;
    self.phoneText.tag=104;
    
    
    
    //失物类型
    UILabel *labType=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, (secondView.bounds.size.height-controlHeight)/2, labWidth, controlHeight)];
    labType.text=@"失物类型";
    labType.textColor=qianlan;
    labType.font=[UIFont systemFontOfSize:16];
    [secondView addSubview:labType];
    //[labType setBackgroundColor:[UIColor orangeColor]];
    
    //---！！挑战！！---
    //下拉选框, button(show, enable), tableview(hide),  点击按钮动画显示tableveiw，此时禁用button。 若点击cell，则tableview隐藏，且button解除禁用，并更改title为cell中的title
    UIButton *typeBtn=[[UIButton alloc] initWithFrame:titleEditBox.frame];
    CGPoint typeBtnCenter=typeBtn.center;
    typeBtnCenter.y=labType.center.y;
    typeBtn.center=typeBtnCenter;
    [typeBtn.layer setCornerRadius:12];
    [typeBtn.layer setMasksToBounds:YES];
    [typeBtn setBackgroundColor:shurukuang];
    [typeBtn setTitle:@"其他" forState:UIControlStateNormal];
    [typeBtn setTitleColor:qianlan forState:UIControlStateNormal];
    [typeBtn addTarget:self action:@selector(chooseTypeClick:) forControlEvents:UIControlEventTouchUpInside];
    [secondView addSubview:typeBtn];
    self.typeBtn=typeBtn;
    
    //下拉框
    UITableView *dropListView=[[UITableView alloc] initWithFrame:typeBtn.frame style:UITableViewStylePlain];
    [dropListView setHidden:YES];
    CGRect dropListViewRect=dropListView.frame;
    dropListViewRect.origin.y+=dropListViewRect.size.height;
    dropListViewRect.size.height*=3;
    dropListView.frame=dropListViewRect;
    dropListView.delegate=self;
    dropListView.dataSource=self;
    self.dropListView=dropListView;
    [secondView addSubview:dropListView];
    self.r=CGRectMake(0, 0, dropListViewRect.size.width, dropListViewRect.size.height);
    
    
    
    
    
    //失物简介
    UILabel *labOverview=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, 20, labWidth, controlHeight)];
    labOverview.text=@"失物简介";
    labOverview.textColor=qianlan;
    labOverview.font=[UIFont systemFontOfSize:16];
    [thirdView addSubview:labOverview];
    
    UITextField *overiewEditBox=[[UITextField alloc] initWithFrame:CGRectMake(0, 0, editBoxWidth, controlHeight-10)];
    overiewEditBox.center=labOverview.center;
    editboxFrame=overiewEditBox.frame;
    editboxFrame.origin.x=title.frame.origin.x+title.frame.size.width+spacingOfLabAndEditbox;
    editboxFrame.size.height=thirdView.bounds.size.height-2*labOverview.frame.origin.y;
    overiewEditBox.frame=editboxFrame;
    [thirdView addSubview:overiewEditBox];
    [overiewEditBox setBackgroundColor:shurukuang];
    [overiewEditBox.layer setCornerRadius:12];//圆角度数
    [overiewEditBox.layer setMasksToBounds:YES];//圆角遮罩
    [overiewEditBox setTextAlignment:NSTextAlignmentJustified];
    [overiewEditBox setDelegate:self];
    self.overviewText=overiewEditBox;
    
    
    
    
    
    //选择图片
    UILabel *labShowImg=[[UILabel alloc] initWithFrame:CGRectMake(labLeftOffset, 20, fourVied.bounds.size.width-2*labLeftOffset, controlHeight)];
    labShowImg.text=@"选择图片 [可选]";
    labShowImg.textColor=qianlan;
    labShowImg.font=[UIFont systemFontOfSize:16];
    [labShowImg setTextAlignment:NSTextAlignmentCenter];
    [fourVied addSubview:labShowImg];
    
    
    //图片占位
    CGFloat imgWidth4=fourVied.bounds.size.width-2*labLeftOffset;
    CGFloat imgHeight4=imgWidth4;
    UIButton *imgBtn4=[[UIButton alloc] initWithFrame:labShowImg.bounds];
    imgBtn4.center=labShowImg.center;
    CGRect img4Rect=imgBtn4.frame;
    img4Rect.origin.y+=labShowImg.bounds.size.height;
    img4Rect.size.height=imgHeight4;
    imgBtn4.frame=img4Rect;
    [imgBtn4 setBackgroundColor:shurukuang];
    [imgBtn4 setTitle:@"点击此处选择图片" forState:UIControlStateNormal];
    [imgBtn4.titleLabel setFont:[UIFont systemFontOfSize:20]];
    [imgBtn4 setTitleColor:qianlan forState:UIControlStateNormal];
    [imgBtn4 addTarget:self action:@selector(chooseImgClick:) forControlEvents:UIControlEventTouchUpInside];
    [fourVied addSubview:imgBtn4];
    self.imgBtn=imgBtn4;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - 右上角发布

-(void)fabuBtnClick:(id)sender{

    //网络管理者
    AFHTTPSessionManager *manager=[AFHTTPSessionManager manager];
    
    //参数
    NSString *domainString=DOMAIN_SET;
    NSString *urlString=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/swzl/swzlPublish", domainString];
    NSString *uidString=[[NSUserDefaults getData:@"userInfo"] objectForKey:@"uid"];
    NSString *navTitle=self.navigationItem.title;
    NSString *item_type=[navTitle isEqualToString:@"发布失物"]?@"失物":@"招领";
    
    NSDictionary *pareDic=[[NSDictionary alloc] initWithObjectsAndKeys:uidString, @"uid", self.titleText.text, @"title", self.timeText.text, @"lose_time", self.moneyText.text, @"for_money", self.placeText.text, @"address", self.phoneText.text, @"mobile", self.typeBtn.titleLabel.text, @"goods_type", self.overviewText.text, @"resume", item_type, @"item_type", @"进行中", @"status", nil];
    

    [manager POST:urlString parameters:pareDic headers:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        //img路径转二进制data
        NSData *imgData=[[NSData alloc] initWithContentsOfFile:self.imgBtnURL.path];
        NSString *nameString=[[NSString alloc] initWithFormat:@"%@", @"pic"];
        NSString *filenameString=[[NSString alloc] initWithFormat:@"pp.%@", self.imgBtnURL.pathExtension];
        NSString *mimetypeString=[[NSString alloc] initWithFormat:@"image/%@", self.imgBtnURL.pathExtension];
        
        if (self.imgBtnURL != nil) {
            
            //上传图片
            [formData appendPartWithFileData:imgData name:nameString fileName:filenameString mimeType:mimetypeString];
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        NSLog(@"%f", 1.0 * uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
#warning error
        //失败时会调用这个block，与原意相违背，需要仔细研究一下失败的判断标准，可能是后台对接的原因
        NSLog(@"上传完成, %@", responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
#warning error
        //成功时会调用这个block，与原意相违背，需要仔细研究一下成功的判断标准
        NSLog(@"上传失败, %@", error);
        [self popAlert:@"发布成功，请前往首页下拉刷新"];
    }];
}

#pragma mark - 键盘代理

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    BOOL result=YES;
    NSLog(@"editField:%@", string);
    
    //电话号码
    if(textField.tag == 104){
        //超过11位，则限制
        unsigned long oldStringLength=(unsigned long)textField.text.length;
        unsigned long newStringLength=(unsigned long)string.length;
        
        NSLog(@"oldStringLength:%lu, newStringLength:%lu", oldStringLength, newStringLength);//使用apple自带的复制粘贴，会比你复制的字符长度多1，比如复制“12”，则会变成“ 12”
        if (newStringLength <= 0) {
            //允许删除操作
            return YES;
        }
        if ((oldStringLength + newStringLength) > 11) {
            NSLog(@"超过最大长度");
            return NO;
        }
        
        //方案二,characterset
        NSCharacterSet *digitSet=[NSCharacterSet decimalDigitCharacterSet];
        NSArray *stringArr=[string componentsSeparatedByCharactersInSet:digitSet];
        NSString *finishString=[stringArr componentsJoinedByString:@""];
        NSLog(@"finishString: %@", finishString);
        if (finishString.length != 0 || ![finishString isEqualToString:@""]) {
            NSLog(@"输入的内容是非数字字符");
            result=NO;
        }
    }
    
    //赏金
    if(textField.tag == 102){
        //超过11位，则限制
        unsigned long oldStringLength=(unsigned long)textField.text.length;
        unsigned long newStringLength=(unsigned long)string.length;
        
        NSLog(@"oldStringLength:%lu, newStringLength:%lu", oldStringLength, newStringLength);//使用apple自带的复制粘贴，会比你复制的字符长度多1，比如复制“12”，则会变成“ 12”
        if (newStringLength <= 0) {
            //允许删除操作
            return YES;
        }
        if ((oldStringLength + newStringLength) > 3) {
            NSLog(@"超过最大长度");
            return NO;
        }
        
        //方案二,characterset
        NSCharacterSet *digitSet=[NSCharacterSet decimalDigitCharacterSet];
        NSArray *stringArr=[string componentsSeparatedByCharactersInSet:digitSet];
        NSString *finishString=[stringArr componentsJoinedByString:@""];
        NSLog(@"finishString: %@", finishString);
        if (finishString.length != 0 || ![finishString isEqualToString:@""]) {
            NSLog(@"输入的内容是非数字字符");
            result=NO;
        }
    }
    
    return result;
}

#pragma mark - 选择类型

-(void)chooseTypeClick:(id)sender{
    NSLog(@"选择类型");
    
    [self.dropListView setHidden:NO];
    //[self.dropListView becomeFirstResponder];
    [self.typeBtn setUserInteractionEnabled:NO];
}

#pragma mark - 选择图片 按钮

-(void)chooseImgClick:(id)sender{
    //访问相册
    
    self.imgBtnURL=nil;
    [self.imgBtn setBackgroundImage:nil forState:UIControlStateNormal];
    
    NSUInteger sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    UIImagePickerController *imgPicker=[[UIImagePickerController alloc] init];
    imgPicker.sourceType=sourceType;
    imgPicker.delegate=self;
    [self presentViewController:imgPicker animated:YES completion:nil];
}

#pragma mark - 相册代理
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    //取消时
    NSLog(@"取消选择");
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info{
    [self.imgBtn setTitle:@"" forState:UIControlStateNormal];
    UIImage *image=[info objectForKey:UIImagePickerControllerOriginalImage];
    [self.imgBtn setBackgroundImage:image forState:UIControlStateNormal];
    [picker dismissViewControllerAnimated:YES completion:nil];
    
#warning UIImagePickerControllerReferenceURL used for ios4.1~11.0,UIImagePickerControllerImageURL used for ios11.0+
    NSString *DevVer=[[UIDevice currentDevice] systemVersion];
    if (DevVer.doubleValue>=11.0) {
        self.imgBtnURL=[info objectForKey:UIImagePickerControllerImageURL];
        NSLog(@"大于11.0");
    }else
    {
        self.imgBtnURL=[info objectForKey:UIImagePickerControllerReferenceURL];
        NSLog(@"小于11.0");
    }
}

#pragma mark - 表视图代理
//delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.height/3;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"%lu", self.arrOfDropList.count);
    return self.arrOfDropList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    dropListCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[dropListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    
    NSString *key=[[NSString alloc] initWithFormat:@"%ld", indexPath.row+1];
    [cell.textLabel setText:[self.arrOfDropList objectForKey:key]];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"click cell");
    [self.dropListView setHidden:YES];
    [self.typeBtn setUserInteractionEnabled:YES];
    NSString *key=[[NSString alloc] initWithFormat:@"%ld", indexPath.row+1];
    [self.typeBtn setTitle:[self.arrOfDropList objectForKey:key] forState:UIControlStateNormal];
    NSLog(@"%@", [self.arrOfDropList objectForKey:key]);
}



#pragma mark - 下拉框

//my delegate
-(UIView *)getTableView{
 
    return self.dropListView;
}




#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}

@end
