//
//  recordViewController.m
//  helpTofind
//
//  Created by rdt on 2019/5/14.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "recordViewController.h"
#import "recordTableView.h"

@interface recordViewController () <UITableViewDelegate, UITableViewDataSource, recordTVDelegate>

//leftcell
@property(strong, nonatomic)NSString *leftCellIdent;

//rightcell
@property(strong, nonatomic)NSString *rightCellIdent;

//typeData
@property(strong, nonatomic)NSDictionary *typeData;

//'纪录‘表视图
@property(strong, nonatomic)recordTableView *rtv;

@end

@implementation recordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //基础数据
    //{
        //cellIdent
        self.leftCellIdent=@"leftCell";
        self.rightCellIdent=@"rightCell";
    
        //type data
        self.typeData=[[NSDictionary alloc] initWithObjectsAndKeys:@"全部", @"1", @"卡包", @"2", @"电子", @"3", @"饰品", @"4", @"文件", @"5", @"宠物", @"6", @"其他", @"7", nil];
    
        //uicolor
        UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
        UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
        UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
        UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
        UIColor *shurukuang=[UIColor colorWithRed:0xec/255.0f green:0xf3/255.0f blue:0xfe/255.0f alpha:1.0f];
        UIColor *noColor=[UIColor clearColor];
        
        //base  750x1334
        CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
        CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
        CGFloat stateBarHeight=[[UIApplication sharedApplication] statusBarFrame].size.height;
        CGFloat navBarHeight=[self.navigationController.navigationBar bounds].size.height;
        CGFloat tabbarHeight=self.tabBarController.tabBar.bounds.size.height;
    
        //bkimg
        UIImage *BKimgTransform=[UIImage imageNamed:@"usualBK.png"];
        //BKimgTransform=[BKimgTransform stretchableImageWithLeftCapWidth:BKimgTransform.size.width*0.2f topCapHeight:BKimgTransform.size.height*0.2f];
        BKimgTransform=[BKimgTransform resizableImageWithCapInsets:UIEdgeInsetsMake(BKimgTransform.size.height*0.2f, BKimgTransform.size.width*0.2f, BKimgTransform.size.height*0.2f, BKimgTransform.size.width*0.2f)];
        UIImage *qqlBKImgTransform=[UIImage imageNamed:@"qianqianlanBK.png"];
        qqlBKImgTransform=[qqlBKImgTransform stretchableImageWithLeftCapWidth:qqlBKImgTransform.size.width*0.1f topCapHeight:qqlBKImgTransform.size.height*0.1f];
    
        
    //}

    
    
    
    
    
    
    //背景view，imageview
    UIImageView *bk=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    bk.image=qqlBKImgTransform;
    [self.view addSubview:bk];
    
    
    
    //左类目view， view
    //--左类目view的背景view， imageview
    //--左类目view的按钮， tableview
    UIView *leftView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, winWidth/6.0f, winHeight-stateBarHeight-navBarHeight)];
    [self.view addSubview:leftView];
    
    UIImageView *bkImgLeftView=[[UIImageView alloc] initWithFrame:leftView.bounds];
    bkImgLeftView.image=BKimgTransform;
    [leftView addSubview:bkImgLeftView];
    
    UITableView *typeTableView=[[UITableView alloc] initWithFrame:leftView.bounds style:UITableViewStylePlain];
    typeTableView.delegate=self;
    typeTableView.dataSource=self;
    [typeTableView setBackgroundColor:noColor];
    [typeTableView setScrollEnabled:NO];
    [typeTableView setSeparatorColor:shenlan];
    UIEdgeInsets sepEdge=[typeTableView separatorInset];
    sepEdge.right=sepEdge.left;
    [typeTableView setSeparatorInset:sepEdge];//分割线长度设置
    [typeTableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    
    [leftView addSubview:typeTableView];
    
    
    //右侧详细信息板
    recordTableView *rtv=[[recordTableView alloc] initWithFrame:CGRectMake(leftView.bounds.size.width, leftView.frame.origin.y, self.view.bounds.size.width-leftView.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
    self.rtv=rtv;
    rtv.rtvDelegate=self;
    [self.view addSubview:rtv];
}

-(void)viewWillAppear:(BOOL)animated{
    
    self.rtv.showData=self.showData;
    self.rtv.imgCachePool=self.imgCachePool;
    [self.rtv reloadData];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return self.tabBarController.tabBar.bounds.size.height;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:self.leftCellIdent];
    
    if (!cell) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.leftCellIdent];
    }
    
    NSString *key=[[NSString alloc] initWithFormat:@"%lu", indexPath.row+1];
    cell.textLabel.text=[self.typeData objectForKey:key];
    [cell.textLabel setTextColor:[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f]];
    [cell.textLabel setFont:[UIFont systemFontOfSize:12]];
    [cell setBackgroundColor:[UIColor clearColor]];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"click: %ld, %@", indexPath.row, [self.typeData objectForKey:[NSString stringWithFormat:@"%ld", indexPath.row+1]]);
    //点击事件

    //筛选出指定类型的数据，然后刷新tableview
    NSArray * oldArr=[self.showData objectForKey:@"myData"];
    NSMutableArray *newArr=[[NSMutableArray alloc] init];
    NSString *speString=[self.typeData objectForKey:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
    
    if ([speString isEqualToString:@"全部"]) {
        //全部，则不筛选
        self.rtv.showData=self.showData;
    }else{
        for (NSDictionary *dic in oldArr) {
            NSString *thisString=[dic objectForKey:@"goods_type"];
            if ([thisString isEqualToString:speString]) {
                [newArr addObject:dic];
            }
        }
        
        if (newArr.count<=0) {
            self.rtv.showData=nil;
        }else{
            NSArray *newArr2=[[NSArray alloc] initWithArray:newArr];
            NSDictionary *newDic=[[NSDictionary alloc] initWithObjectsAndKeys:newArr2, @"myData", nil];
            self.rtv.showData=newDic;
        }
    }
    
    [self.rtv reloadData];
}

#pragma mark - 电话·短信·简介回调


-(void)clickPhoneBtnDd:(NSInteger)ind{
    if (self.showData == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    if (oldArr == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSDictionary *newDic=oldArr[ind];
    NSString *phoneString=[[NSString alloc] initWithFormat:@"%@", [newDic objectForKey:@"mobile"]];
    if ([phoneString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写联系方式"];
        return;
    }
    
    
    //拨打电话
    NSString *telNumber=[NSString stringWithFormat:@"tel://%@", phoneString];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}
-(void)clickMsgBtnDd:(NSInteger)ind{
    if (self.showData == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    if (oldArr == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSDictionary *newDic=oldArr[ind];
    NSString *phoneString=[[NSString alloc] initWithFormat:@"%@", [newDic objectForKey:@"mobile"]];
    if ([phoneString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写联系方式"];
        return;
    }
    
    
    //发送短信
    NSString *telNumber=[NSString stringWithFormat:@"sms://%@", phoneString];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}
-(void)clickOverviewBtnDd:(NSInteger)ind{
    if (self.showData == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    if (oldArr == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSDictionary *newDic=oldArr[ind];
    NSString *overviewString=[[NSString alloc] initWithFormat:@"%@", [newDic objectForKey:@"resume"]];
    if ([overviewString isEqualToString:@""]) {
        [self popAlert:@"没有简介"];
        return;
    }
    
    [self popAlert:overviewString];
}



#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}


@end
