//
//  recordTableViewCell.h
//  helpTofind
//
//  Created by rdt on 2019/5/15.
//  Copyright © 2019 电脑. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol recordTVcellDelegate <NSObject>

@optional
-(void)clickPhoneBtnD:(NSInteger)ind;
-(void)clickMsgBtnD:(NSInteger)ind;
-(void)clickOverviewBtnD:(NSInteger)ind;

@end

@interface recordTableViewCell : UITableViewCell

@property(strong, nonatomic)UIButton *phoneBtn;
@property(strong, nonatomic)UIButton *msgBtn;
@property(strong, nonatomic)UIButton *commentBtn;

@property(weak, nonatomic)id<recordTVcellDelegate> rtvcellDelegate;

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame;

@end

NS_ASSUME_NONNULL_END
