//
//  recordTableView.m
//  helpTofind
//
//  Created by rdt on 2019/5/15.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "recordTableView.h"
#import "recordTableViewCell.h"

@interface recordTableView() <UITableViewDelegate, UITableViewDataSource, recordTVcellDelegate>

//cellIdent
@property(strong, nonatomic) NSString *cellIdent;

@end

@implementation recordTableView



-(instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    self=[super initWithFrame:frame style:style];
    
    
    //
    self.cellIdent=@"cellIdentRecord";
    self.delegate=self;
    self.dataSource=self;
    
    
    //去掉分割线
    self.separatorColor=[UIColor clearColor];
    
    //背景透明
    self.backgroundColor=[UIColor clearColor];
    
    //额外滚动区域
    [self setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];
    
    //取消右侧滚动条
    [self setShowsVerticalScrollIndicator:NO];
    
    
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

//delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.showData == nil) {
        return 0;
    }
    
    NSArray *arr=[self.showData objectForKey:@"myData"];
    return arr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 400;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    recordTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[recordTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent frame:tableView.bounds];
        cell.rtvcellDelegate=self;
    }
    
    
//    titleLabel.tag          = 10;
//    userLabel.tag           = 11;
//    timeLabel.tag           = 12;
//    lostTimeImgView.tag     = 13;
//    lostTimeLabel.tag       = 14;
//    placeImgView.tag        = 15;
//    placeLabel.tag          = 16;
//    typeImgView.tag         = 17;
//    typeLabel.tag           = 18;
//    photoImgView.tag        = 19;
//    lineImgView.tag         = 20;
//    phoneButton.tag         = 21;
//    phoneLabel.tag          = 22;
//    msgButton.tag           = 23;
//    msgLabel.tag            = 24;
//    commentButton.tag       = 25;
//    commentLabel.tag        = 26;
    
    UILabel *titleLabel         = [cell viewWithTag:10];
    UILabel *userLabel          = [cell viewWithTag:11];
    UILabel *timeLabel          = [cell viewWithTag:12];
    UILabel *lostTimeLabel      = [cell viewWithTag:14];
    UILabel *placeLabel         = [cell viewWithTag:16];
    UILabel *typeLabel          = [cell viewWithTag:18];
    
    NSArray *arr=[self.showData objectForKey:@"myData"];
    NSDictionary *dic=arr[indexPath.row];
    
    NSString *titleString       = [dic objectForKey:@"title"];
    NSString *userString        = [dic objectForKey:@"user_name"];
    NSString *timeString        = [dic objectForKey:@"create_time"];
    NSString *lostTimeString    = [dic objectForKey:@"lose_time"];
    NSString *placeString       = [dic objectForKey:@"address"];
    NSString *typeString        = [dic objectForKey:@"goods_type"];
    
    titleString     = ((NSNull *)titleString==[NSNull null]?@"":titleString);
    userString      = ((NSNull *)userString==[NSNull null]?@"":userString);
    timeString      = ((NSNull *)timeString==[NSNull null]?@"":[NSString stringWithFormat:@"%@ 发布", timeString]);
    lostTimeString  = ((NSNull *)lostTimeString==[NSNull null]?@"":lostTimeString);
    placeString     = ((NSNull *)placeString==[NSNull null]?@"":placeString);
    typeString      = ((NSNull *)titleString==[NSNull null]?@"":typeString);
    
    
    titleLabel.text     = titleString;
    userLabel.text      = userString;
    timeLabel.text      = timeString;
    lostTimeLabel.text  = lostTimeString;
    placeLabel.text     = placeString;
    typeLabel.text      = typeString;
    
    
    UIImageView *photoImageView=[cell viewWithTag:19];
    if (self.imgCachePool == nil) {
        photoImageView.image=[UIImage imageNamed:@"ka.png"];
    }else{
        UIImage *img=[self.imgCachePool objectForKey:[NSString stringWithFormat:@"%@", [dic objectForKey:@"id"]]];
        img=((NSNull *)img == [NSNull null] ? [UIImage imageNamed:@"ka.png"] : img);
        photoImageView.image=img;
        
    }
    
    //标识一下按钮
    cell.phoneBtn.tag=indexPath.row+30;
    cell.msgBtn.tag=indexPath.row+31;
    cell.commentBtn.tag=indexPath.row+32;
    
    
    return cell;
}

-(void)chooseTypeToReload:(NSString *)type{
    
    
}

-(void)clickPhoneBtnD:(NSInteger)ind{
    [self.rtvDelegate clickPhoneBtnDd:ind];
}
-(void)clickMsgBtnD:(NSInteger)ind{
    [self.rtvDelegate clickMsgBtnDd:ind];
    
}
-(void)clickOverviewBtnD:(NSInteger)ind{
    [self.rtvDelegate clickOverviewBtnDd:ind];
    
}

@end
