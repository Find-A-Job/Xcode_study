//
//  recordTableView.h
//  helpTofind
//
//  Created by rdt on 2019/5/15.
//  Copyright © 2019 电脑. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol recordTVDelegate <NSObject>

@optional

-(void)clickPhoneBtnDd:(NSInteger)ind;
-(void)clickMsgBtnDd:(NSInteger)ind;
-(void)clickOverviewBtnDd:(NSInteger)ind;

@end

@interface recordTableView : UITableView

@property(weak, nonatomic)id<recordTVDelegate> rtvDelegate;

//数据
@property(strong, atomic, nullable)NSDictionary *showData;
@property(strong, atomic)NSDictionary *imgCachePool;

//根据类型筛选数据
-(void)chooseTypeToReload:(NSString *)type;

@end

NS_ASSUME_NONNULL_END
