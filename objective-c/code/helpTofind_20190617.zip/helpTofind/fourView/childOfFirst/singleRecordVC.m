//
//  singleRecordVC.m
//  helpTofind
//
//  Created by rdt on 2019/5/16.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "singleRecordVC.h"

@interface singleRecordVC ()


@end

@implementation singleRecordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    
    //背景图片
    UIImageView *uibk=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    UIImage *sclViewBkImg=[UIImage imageNamed:@"qianqianlanBK.png"];
    sclViewBkImg=[sclViewBkImg resizableImageWithCapInsets:UIEdgeInsetsMake(sclViewBkImg.size.height*0.2f, sclViewBkImg.size.height*0.2f, sclViewBkImg.size.height*0.2f, sclViewBkImg.size.height*0.2f)];
    uibk.image=sclViewBkImg;
    [self.view addSubview:uibk];
    
    //滚动视图
    UIScrollView *scrollViewBk=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    [self.view addSubview:scrollViewBk];
    [scrollViewBk setContentSize:CGSizeMake(0, scrollViewBk.bounds.size.height+100)];
    [scrollViewBk setShowsVerticalScrollIndicator:NO];
    
    
    
    
    //白色矩形框背景
    UIImage *whiteRectImg=[UIImage imageNamed:@"usualBK.png"];
    whiteRectImg=[whiteRectImg resizableImageWithCapInsets:UIEdgeInsetsMake(whiteRectImg.size.height*0.2f, whiteRectImg.size.height*0.2f, whiteRectImg.size.height*0.2f, whiteRectImg.size.height*0.2f)];
    UIImageView *whiteRectBK=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight/4*3)];
    whiteRectBK.image=whiteRectImg;
    [scrollViewBk addSubview:whiteRectBK];
    
    
    
    
    //添加控件
    UIColor *shenhui        = [UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui        = [UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan        = [UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan        = [UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    UIColor *hei            = [UIColor blackColor];

    CGRect boundsBase       = [whiteRectBK bounds];
    CGFloat leftOffset      = boundsBase.size.width/10;
    CGFloat topOffset       = boundsBase.size.height/20;
    CGFloat labelWidth      = boundsBase.size.width/3*2;
    CGFloat labelHeight     = boundsBase.size.height/10;
    CGFloat leftImgWidth    = labelHeight/2;
    CGFloat photoImgWidth   = labelWidth;
    CGFloat photoImgHeight  = labelWidth/3*2;
    CGFloat bottomImgWidth  = boundsBase.size.width/8;

    UIFont *titleFont       = [UIFont systemFontOfSize:leftOffset/10*7];
    UIFont *nameFont        = [UIFont systemFontOfSize:leftOffset/10*5];
    UIFont *timeFont        = [UIFont systemFontOfSize:leftOffset/3];




    UILabel *titleLabel             = [[UILabel alloc] initWithFrame:CGRectMake(leftOffset, topOffset, labelWidth, labelHeight)];
    UILabel *userLabel              = [[UILabel alloc] initWithFrame:CGRectMake(leftOffset, titleLabel.frame.origin.y+titleLabel.bounds.size.height, labelWidth, labelHeight/3*2)];
    UILabel *timeLabel              = [[UILabel alloc] initWithFrame:CGRectMake(leftOffset, userLabel.frame.origin.y+userLabel.bounds.size.height, labelWidth, labelHeight/4*2)];
    UIImageView *lostTimeImgView    = [[UIImageView alloc] initWithFrame:CGRectMake(leftOffset, timeLabel.frame.origin.y+timeLabel.bounds.size.height+5, leftImgWidth, leftImgWidth)];
    UILabel *lostTimeLabel          = [[UILabel alloc] initWithFrame:CGRectMake(lostTimeImgView.frame.origin.x+lostTimeImgView.frame.size.width+5, lostTimeImgView.frame.origin.y, labelWidth, labelHeight/2)];

    UIImageView *placeImgView       = [[UIImageView alloc] initWithFrame:CGRectMake(lostTimeImgView.frame.origin.x, lostTimeImgView.frame.origin.y+lostTimeImgView.bounds.size.height+3, leftImgWidth, leftImgWidth)];
    UILabel *placeLabel             = [[UILabel alloc] initWithFrame:CGRectMake(placeImgView.frame.origin.x+placeImgView.bounds.size.width+5, placeImgView.frame.origin.y, lostTimeLabel.bounds.size.width, lostTimeLabel.bounds.size.height)];

    UIImageView *typeImgView        = [[UIImageView alloc] initWithFrame:CGRectMake(placeImgView.frame.origin.x, placeImgView.frame.origin.y+placeImgView.bounds.size.height+3, leftImgWidth, leftImgWidth)];
    UILabel *typeLabel              = [[UILabel alloc] initWithFrame:CGRectMake(typeImgView.frame.origin.x+typeImgView.bounds.size.width+5, typeImgView.frame.origin.y, lostTimeLabel.bounds.size.width, lostTimeLabel.bounds.size.height)];

    UIImageView *photoImgView       = [[UIImageView alloc] initWithFrame:CGRectMake(leftOffset, typeImgView.frame.origin.y+typeImgView.bounds.size.height+7, photoImgWidth, photoImgHeight)];
    UIImageView *lineImgView        = [[UIImageView alloc] initWithFrame:CGRectMake(boundsBase.size.width/20, photoImgView.frame.origin.y+photoImgView.bounds.size.height+10, boundsBase.size.width/20*18, 1)];

    UIButton *phoneButton           = [[UIButton alloc] initWithFrame:CGRectMake((boundsBase.size.width/3-bottomImgWidth)/2, lineImgView.frame.origin.y+10, bottomImgWidth, bottomImgWidth/6*5)];
    UILabel *phoneLabel             = [[UILabel alloc] initWithFrame:CGRectMake(phoneButton.frame.origin.x, phoneButton.frame.origin.y+phoneButton.bounds.size.height, bottomImgWidth, bottomImgWidth/2)];

    UIButton *msgButton             = [[UIButton alloc] initWithFrame:CGRectMake((boundsBase.size.width/3-bottomImgWidth)/2+boundsBase.size.width/3, lineImgView.frame.origin.y+10, bottomImgWidth, bottomImgWidth/6*5)];
    UILabel *msgLabel               = [[UILabel alloc] initWithFrame:CGRectMake(msgButton.frame.origin.x, msgButton.frame.origin.y+msgButton.bounds.size.height, bottomImgWidth, bottomImgWidth/2)];

    UIButton *commentButton         = [[UIButton alloc] initWithFrame:CGRectMake((boundsBase.size.width/3-bottomImgWidth)/2+boundsBase.size.width/3*2, lineImgView.frame.origin.y+10, bottomImgWidth, bottomImgWidth/6*5)];
    UILabel *commentLabel           = [[UILabel alloc] initWithFrame:CGRectMake(commentButton.frame.origin.x, commentButton.frame.origin.y+commentButton.bounds.size.height, bottomImgWidth, bottomImgWidth/2)];



    titleLabel.textColor    = shenlan;
    userLabel.textColor     = hei;
    timeLabel.textColor     = shenhui;
    lostTimeLabel.textColor = shenlan;
    placeLabel.textColor    = shenlan;
    typeLabel.textColor     = shenlan;
    phoneLabel.textColor    = shenlan;
    msgLabel.textColor      = shenlan;
    commentLabel.textColor  = shenlan;




    titleLabel.font         = titleFont;
    userLabel.font          = nameFont;
    timeLabel.font          = timeFont;
    lostTimeLabel.font      = timeFont;
    placeLabel.font         = timeFont;
    typeLabel.font          = timeFont;
    phoneLabel.font         = nameFont;
    msgLabel.font           = nameFont;
    commentLabel.font       = nameFont;




    [scrollViewBk addSubview:titleLabel];
    [scrollViewBk addSubview:userLabel];
    [scrollViewBk addSubview:timeLabel];
    [scrollViewBk addSubview:lostTimeImgView];
    [scrollViewBk addSubview:lostTimeLabel];
    [scrollViewBk addSubview:placeImgView];
    [scrollViewBk addSubview:placeLabel];
    [scrollViewBk addSubview:typeImgView];
    [scrollViewBk addSubview:typeLabel];
    [scrollViewBk addSubview:photoImgView];
    [scrollViewBk addSubview:lineImgView];
    [scrollViewBk addSubview:phoneButton];
    [scrollViewBk addSubview:phoneLabel];
    [scrollViewBk addSubview:msgButton];
    [scrollViewBk addSubview:msgLabel];
    [scrollViewBk addSubview:commentButton];
    [scrollViewBk addSubview:commentLabel];




    UIImage *lostTimeImg    = [UIImage imageNamed:@"biaoshi1@3x.png"];
    lostTimeImgView.image   = lostTimeImg;
    UIImage *placeImg       = [UIImage imageNamed:@"biaoshi2@3x.png"];
    placeImgView.image      = placeImg;
    UIImage *typeImg        = [UIImage imageNamed:@"biaoshi3@3x.png"];
    typeImgView.image       = typeImg;
    UIImage *photoImg       = [UIImage imageNamed:@"ka.png"];
    photoImgView.image      = photoImg;
    UIImage *lineImg        = [UIImage imageNamed:@"xian.png"];
    lineImgView.image       = lineImg;
    UIImage *phoneImg       = [UIImage imageNamed:@"tel@3x.png"];
    [phoneButton setBackgroundImage:phoneImg forState:UIControlStateNormal];
    UIImage *msgImg         = [UIImage imageNamed:@"msg@3x.png"];
    [msgButton setBackgroundImage:msgImg forState:UIControlStateNormal];
    UIImage *commentImg     = [UIImage imageNamed:@"comment@3x.png"];
    [commentButton setBackgroundImage:commentImg forState:UIControlStateNormal];




    titleLabel.tag          = 110;
    userLabel.tag           = 111;
    timeLabel.tag           = 112;
    lostTimeImgView.tag     = 113;
    lostTimeLabel.tag       = 114;
    placeImgView.tag        = 115;
    placeLabel.tag          = 116;
    typeImgView.tag         = 117;
    typeLabel.tag           = 118;
    photoImgView.tag        = 119;
    lineImgView.tag         = 120;
    phoneButton.tag         = 121;
    phoneLabel.tag          = 122;
    msgButton.tag           = 123;
    msgLabel.tag            = 124;
    commentButton.tag       = 125;
    commentLabel.tag        = 126;



    [phoneLabel setTextAlignment:NSTextAlignmentCenter];
    [msgLabel setTextAlignment:NSTextAlignmentCenter];
    [commentLabel setTextAlignment:NSTextAlignmentCenter];



    phoneLabel.text=@"电话";
    msgLabel.text=@"短信";
    commentLabel.text=@"简介";
    

    //点击事件
    [phoneButton addTarget:self action:@selector(clickPhoneBtn) forControlEvents:UIControlEventTouchUpInside];
    [msgButton addTarget:self action:@selector(clickMsgBtn) forControlEvents:UIControlEventTouchUpInside];
    [commentButton addTarget:self action:@selector(clickOverviewBtn) forControlEvents:UIControlEventTouchUpInside];
}
-(void)viewWillAppear:(BOOL)animated{
    UILabel *titleLabel=[self.view viewWithTag:110];
    UILabel *userLabel=[self.view viewWithTag:111];
    UILabel *timeLabel=[self.view viewWithTag:112];
    UILabel *lostTimeLabel=[self.view viewWithTag:114];
    UILabel *placeLabel=[self.view viewWithTag:116];
    UILabel *typeLabel=[self.view viewWithTag:118];
    UIImageView *photoImgView=[self.view viewWithTag:119];
    
    NSString *titleString=[self.singleRecordData objectForKey:@"title"];
    titleLabel.text=((NSNull *)titleString==[NSNull null]?@"":titleString);
    
    NSString *user_nameString=[self.singleRecordData objectForKey:@"user_name"];
    userLabel.text=((NSNull *)user_nameString==[NSNull null]?@"":user_nameString);
    
    NSString *create_timeString=[self.singleRecordData objectForKey:@"create_time"];
    timeLabel.text=((NSNull *)create_timeString == [NSNull null] ? @"" : [NSString stringWithFormat:@"%@ 发布", create_timeString]);
    
    NSString *lose_timeString=[self.singleRecordData objectForKey:@"lose_time"];
    lostTimeLabel.text=((NSNull *)lose_timeString==[NSNull null]?@"":lose_timeString);
    
    NSString *addressString=[self.singleRecordData objectForKey:@"address"];
    placeLabel.text=((NSNull *)addressString==[NSNull null]?@"":addressString);
    
    NSString *goods_typeString=[self.singleRecordData objectForKey:@"goods_type"];
    typeLabel.text=((NSNull *)goods_typeString==[NSNull null]?@"":goods_typeString);
    
    if (self.imgCachePool != nil) {
        UIImage *imgg=[self.imgCachePool objectForKey:[NSString stringWithFormat:@"%@", [self.singleRecordData objectForKey:@"id"]]];
        photoImgView.image=imgg;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)clickPhoneBtn{
    if (self.singleRecordData == nil) {
        return;
    }
    NSString *phoneString=[self.singleRecordData objectForKey:@"mobile"];
    if ([phoneString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写联系方式"];
        return ;
    }
    
    
    //拨打电话
    NSString *telNumber=[NSString stringWithFormat:@"tel://%@", phoneString];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}

-(void)clickMsgBtn{
    if (self.singleRecordData == nil) {
        return;
    }
    NSString *phoneString=[self.singleRecordData objectForKey:@"mobile"];
    if ([phoneString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写联系方式"];
        return ;
    }
    
    
    //拨打电话
    NSString *telNumber=[NSString stringWithFormat:@"sms://%@", phoneString];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}

-(void)clickOverviewBtn{
    if (self.singleRecordData == nil) {
        return;
    }
    NSString *overviewString=[self.singleRecordData objectForKey:@"resume"];
    if ([overviewString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写简介"];
        return ;
    }
    
    //
    [self popAlert:overviewString];
}


#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}



@end
