//
//  newNewsCell.m
//  helpTofind
//
//  Created by rdt on 2019/5/7.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "newNewsCell.h"

@implementation newNewsCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    
    CGFloat fontSize=13;
    
    //name
    UILabel *name=[[UILabel alloc] initWithFrame:CGRectMake(0, 5, winWidth/6, 20)];
    [name setTextColor:shenlan];
    [name setFont:[UIFont systemFontOfSize:fontSize]];
    [name setTextAlignment:NSTextAlignmentRight];
    //[name setBackgroundColor:[UIColor orangeColor]];
    [self addSubview:name];
    self.labName=name;
    
    //title
    UILabel *title=[[UILabel alloc] initWithFrame:CGRectMake(name.frame.origin.x+name.frame.size.width+winWidth/75, name.frame.origin.y, winWidth/3, name.frame.size.height)];
    [title setTextColor:shenlan];
    [title setFont:[UIFont systemFontOfSize:fontSize]];
    //[title setBackgroundColor:[UIColor orangeColor]];
    [self addSubview:title];
    self.labTitle=title;
    
    //time
    UILabel *timeDate=[[UILabel alloc] initWithFrame:CGRectMake(title.frame.origin.x+title.frame.size.width+winWidth/75, name.frame.origin.y, winWidth/25*22-10-name.bounds.size.width-title.bounds.size.width, name.frame.size.height)];
    [timeDate setTextColor:qianhui];
    [timeDate setFont:[UIFont systemFontOfSize:fontSize]];
    [timeDate setTextAlignment:NSTextAlignmentRight];
    //[timeDate setBackgroundColor:[UIColor orangeColor]];
    [self addSubview:timeDate];
    self.labTime=timeDate;
    
    //取消选中状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return self;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
