//
//  viewWithDropList.h
//  helpTofind
//
//  Created by rdt on 2019/5/10.
//  Copyright © 2019 电脑. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol viewWithDropListDelegate <NSObject>

@optional
-(UIView *)getTableView;

@end

@interface viewWithDropList : UIImageView

@property(weak, nonatomic) id<viewWithDropListDelegate> tableViewDelegate;

@end

NS_ASSUME_NONNULL_END
