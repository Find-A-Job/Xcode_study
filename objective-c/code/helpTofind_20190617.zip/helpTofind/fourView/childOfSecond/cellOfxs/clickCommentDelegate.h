//
//  clickCommentDelegate.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/28.
//  Copyright © 2019年 电脑. All rights reserved.
//

#ifndef clickCommentDelegate_h
#define clickCommentDelegate_h

@protocol clickCommentDelegate

@optional
-(void)showKeyboard;
-(NSString *)getPhoneNumber:(NSInteger)indexPath;
-(void)startActivityIndicator;
-(void)stopActivityIndicator;

//按钮点击
-(void)showOverView:(NSInteger)ind;
-(void)clickPhoneBtn:(NSInteger)ind;
-(void)clickMsgBtn:(NSInteger)ind;

@end
#endif /* clickCommentDelegate_h */
