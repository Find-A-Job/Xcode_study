//
//  cellOfxs.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/26.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "clickCommentDelegate.h"

@interface cellOfxs : UITableViewCell

@property(strong, nonatomic) UILabel *l1;//标题
@property(strong, nonatomic) UILabel *l2;//用户昵称
@property(strong, nonatomic) UILabel *l3;//发布日期
@property(strong, nonatomic) UILabel *l4;//‘丢失/发现’时间
@property(strong, nonatomic) UILabel *l5;//地点
@property(strong, nonatomic) UILabel *l6;//标签
@property(strong, nonatomic) UILabel *l7;//赏金

@property(strong, nonatomic) UIImageView *u1;//物品照片
@property(strong, nonatomic) UIImageView *u2;//赏金图标

//弹起键盘和编辑框
@property(weak, nonatomic) id<clickCommentDelegate> commentDelegate;


//额外信息，用于区分不同的cell上的控件
@property(strong, nonatomic) UIButton *tel;
@property(strong, nonatomic) UIButton *msg;
@property(strong, nonatomic) UIButton *comment;

@end
