//
//  xuanshangTableView.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/26.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "cellOfxs/clickCommentDelegate.h"

@interface xuanshangTableView : UITableViewController


//是否完成一次刷新
@property(atomic)BOOL isRefreshOver;

//弹起键盘和编辑框
@property(weak, nonatomic, nullable) id<clickCommentDelegate> commentDelegate;

@property(strong, atomic, nullable)NSDictionary *showData;
@property(strong, atomic, nullable)NSDictionary *imgCachePool;

@end
