//
//  xuanshangTableView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/26.
//  Copyright © 2019年 电脑. All rights reserved.
//

#warning "mission"
#pragma mark - 没完成的事。1.加个加载动画 2.回弹判断

#import "xuanshangTableView.h"
#import "cellOfxs.h"

@interface xuanshangTableView() <UITableViewDelegate, UITableViewDataSource, clickCommentDelegate, UIScrollViewDelegate>

//cell标识
@property(strong, nonatomic) NSString *cellIdent;

//是否松手
@property(atomic)BOOL isDragOver;




@end

@implementation xuanshangTableView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //
    self.cellIdent=@"cellOfxuanshang";
    self.isRefreshOver=YES;//应该在diytabbar文件中判断是否结束刷新。这里可能导致的问题是第一次加载数据正在进行中，而用户立刻进行刷新操作，两次的数据加载操作都是新的线程，会冲突
    
    //设置坐标
    [self.tableView setFrame:CGRectMake(0, 50, [[UIApplication sharedApplication] statusBarFrame].size.width, 600)];
    
    //背景透明
    [self.tableView setBackgroundColor:[UIColor clearColor]];
    
    //增加额外滚动区域
    [self.tableView setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];
    
    //去分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    //隐藏右侧滚动条
    [self.tableView setShowsVerticalScrollIndicator:NO];
    
}

//代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number=0;
    
    NSArray *arr=[self.showData objectForKey:@"myData"];
    if (arr == nil) {
        number=0;
    }else{
        
        number=arr.count;
    }
    
    return number;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat gao=600;
    
    return  gao;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    cellOfxs *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[cellOfxs alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    cell.commentDelegate=self;
    
    NSDictionary *nsd=((NSArray *)[self.showData objectForKey:@"myData"])[indexPath.row];
    
    if (nsd == nil) {
        ;
    }else{
        NSString *titleString       = [nsd objectForKey:@"title"];
        NSString *userString        = [nsd objectForKey:@"user_name"];
        NSString *createTimeString  = [nsd objectForKey:@"create_time"];
        NSString *loseTimeString    = [nsd objectForKey:@"lose_time"];
        NSString *addressString     = [nsd objectForKey:@"address"];
        NSString *typeString        = [nsd objectForKey:@"goods_type"];
        NSString *moneyString       = [nsd objectForKey:@"for_money"];
        
        
        titleString         = ((NSNull *)titleString==[NSNull null]?@"":titleString);
        userString          = ((NSNull *)userString==[NSNull null]?@"":userString);
        createTimeString    = ((NSNull *)createTimeString==[NSNull null]?@"":createTimeString);
        loseTimeString      = ((NSNull *)loseTimeString==[NSNull null]?@"":loseTimeString);
        addressString       = ((NSNull *)addressString==[NSNull null]?@"":addressString);
        typeString          = ((NSNull *)typeString==[NSNull null]?@"":typeString);
        moneyString         = ((NSNull *)moneyString==[NSNull null]?@"0":[NSString stringWithFormat:@"%d", moneyString.intValue]);
        
        
        //标题
        cell.l1.text=titleString;
        
        //用户
        cell.l2.text=userString;
        
        //发布时间
        cell.l3.text=[NSString stringWithFormat:@"%@  发布", createTimeString];
        
        //丢失/寻找时间
        cell.l4.text=loseTimeString;
        
        //地址
        cell.l5.text=addressString;
        
        //类型
        cell.l6.text=typeString;
        
        //赏金
        NSString *moneyValue=moneyString;
        if ([moneyValue isEqualToString:@"0"]) {
            [cell.l7 setHidden:YES];
            [cell.u2 setHidden:YES];
        }else{
            [cell.l7 setHidden:NO];
            [cell.u2 setHidden:NO];
            cell.l7.text=[NSString stringWithFormat:@"%@赏金", moneyValue];
        }
        
        //图片
        if (self.imgCachePool == nil) {
            [cell.u1 setImage:[UIImage imageNamed:@"ka.png"]];
        }else{
            
            UIImage *img=[self.imgCachePool objectForKey:[NSString stringWithFormat:@"%@", [nsd objectForKey:@"id"]]];
            img = ((NSNull *)img==[NSNull null]?[UIImage imageNamed:@"ka.png"]:img);
            [cell.u1 setImage:img];
        }
        
        //额外的信息,用来确认按钮来自那个cell
        cell.tel.tag=(indexPath.row+10)*10;
        cell.msg.tag=(indexPath.row+11)*10;
        cell.comment.tag=(indexPath.row+12)*10;
    }

    
    return cell;
}

#pragma mark - clickCommentDelegate代理

-(void)showKeyboard{
    [self.commentDelegate showKeyboard];
}
-(NSString *)getPhoneNumber:(NSInteger)indexPath{
    NSArray *arr=[self.showData objectForKey:@"myData"];
    
    if (arr == nil) {
        return @"13630257468";
    }else{
        
        NSDictionary *nsd=arr[indexPath];
        NSString *telNumber=[nsd objectForKey:@"mobile"];
#warning i
        //缺个空值判断
        return telNumber;
    }

}
-(void)showOverView:(NSInteger)ind{
    //[self.commentDelegate showOverView:ind];
    
    
    if (self.showData == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    if (oldArr == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSDictionary *newDic=oldArr[ind];
    NSString *overviewString=[[NSString alloc] initWithFormat:@"%@", [newDic objectForKey:@"resume"]];
    if ([overviewString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写简介"];
        return;
    }
    
    
    //显示简介
    [self popAlert:overviewString];
}

-(void)clickPhoneBtn:(NSInteger)ind{
    if (self.showData == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    if (oldArr == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSDictionary *newDic=oldArr[ind];
    NSString *phoneString=[[NSString alloc] initWithFormat:@"%@", [newDic objectForKey:@"mobile"]];
    if ([phoneString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写联系方式"];
        return;
    }
    
    
    //拨打电话
    NSString *telNumber=[NSString stringWithFormat:@"tel://%@", phoneString];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}

-(void)clickMsgBtn:(NSInteger)ind{
    
    if (self.showData == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSArray *oldArr=[self.showData objectForKey:@"myData"];
    if (oldArr == nil) {
        [self popAlert:@"空"];
        return;
    }
    NSDictionary *newDic=oldArr[ind];
    NSString *phoneString=[[NSString alloc] initWithFormat:@"%@", [newDic objectForKey:@"mobile"]];
    if ([phoneString isEqualToString:@""]) {
        [self popAlert:@"该用户未填写联系方式"];
        return;
    }
    
    
    //发送短信
    NSString *telNumber=[NSString stringWithFormat:@"sms://%@", phoneString];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telNumber] options:@{} completionHandler:nil];
}

//-(void)startActivityIndicator{
//    
//    
//}
//
//-(void)stopActivityIndicator{
//    
//    
//}

#pragma mark - 滚动视图代理

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //手指收起，若此时的滑动距离符合条件则执行刷新的动画，且发送全局消息，通知“刷新‘
    if (self.isDragOver) {
        if (scrollView.contentOffset.y<-30 && scrollView.contentOffset.y>=-40) {
            
            //动画
            //[self reflashAnimate];
            
            self.isDragOver=NO;
        }
    }
    


}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
    //开始拖拽
    self.isDragOver=NO;
}

-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
    

    
    //结束拖拽
    self.isDragOver=YES;
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    
    if (self.isRefreshOver == YES) {
        if (scrollView.contentOffset.y<-30) {
            
            //防止短时间内进行重复操作
            self.isRefreshOver=NO;
            
            //广播-“需要重新请求所有数据”
            NSLog(@"广播-\"刷新，全局数据\"");
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshAlldata" object:nil];
        }
    }
}

- (BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView{
    
    
    
    return YES;
}

- (void)scrollViewDidScrollToTop:(UIScrollView *)scrollView{
    
    
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
    
    
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    
}

#pragma mark - 刷新的动画

-(void)reflashAnimate{
    
    
    //绘制动画,显示加载小菊花
    [self.commentDelegate startActivityIndicator];
    
    
    //模拟延时
    [NSThread sleepForTimeInterval:2.0f];


    
    
    [self.commentDelegate stopActivityIndicator];
    
    //发送全局通知
    
    
}



#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}

@end
