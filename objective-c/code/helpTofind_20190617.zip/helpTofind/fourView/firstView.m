//
//  firstView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "firstView.h"
#import "childOfFirst/newNewsCell.h"
#import "childOfFirst/fabuView.h"
#import "childOfFirst/fourButton/recordViewController.h"
#import "childOfFirst/singleRecordVC.h"
#import "../main/global.h"
#import "../dataPersistence/NSUserDefaults+nsUD_cate.h"

@interface firstView() <UITableViewDelegate, UITableViewDataSource, NSURLSessionDelegate, UIScrollViewDelegate>

//是否完成一次刷新
@property(atomic)BOOL isRefreshOver;

//layer层动画
@property(strong, nonatomic) CADisplayLink *displayLink;
@property(strong, nonatomic) CALayer        *greenLayer;
@property(strong, nonatomic) CAShapeLayer   *redLayer;
@property(strong, nonatomic) CALayer        *maskLayer;
@property(strong, nonatomic) UIView         *maskView;
@property(atomic)           CGFloat         changeValue;

-(void)layerAction;

//ident
@property(strong, nonatomic) NSString *cellIdent;

//data
@property(strong, atomic) NSDictionary *showData;
@property(strong, atomic) NSDictionary *imgCachePool;

//viewController lost
@property(strong, nonatomic) recordViewController *lostRecordVC;

//viewController find
@property(strong, nonatomic) recordViewController *findRecordVC;

//viweController singleRecord
@property(strong, nonatomic) singleRecordVC *singleRecVC;

-(void)showRect:(CGRect)r;

//button
-(void)clickSWJLU:(id)sender;
-(void)clickFBSWU:(id)sender;
-(void)clickZLJLU:(id)sender;
-(void)clickFBZLING:(id)sender;

@end

@implementation firstView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //
    self.cellIdent=@"cell3";
    self.isRefreshOver=YES;
    
    //
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    

    //背景滚动视图
    UIScrollView *baseScrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, winWidth, winHeight)];
    [self.view addSubview:baseScrollView];
    [baseScrollView setContentSize:CGSizeMake(0, winHeight+150)];//设置滚动范围
    [baseScrollView setShowsVerticalScrollIndicator:NO];//不显示垂直滚动条
    baseScrollView.delegate=self;
    //[baseScrollView setBounces:NO];//取消弹簧效果
    
    
    
    //背景视图
    UIView *baseView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, winWidth, baseScrollView.contentSize.height+20)];
    [baseScrollView addSubview:baseView];
    UIImage *bkImg=[UIImage imageNamed:@"shouYebg.png"];
    bkImg=[bkImg stretchableImageWithLeftCapWidth:bkImg.size.width*0.3f topCapHeight:bkImg.size.height*0.3f];
    UIImageView *bkImgView=[[UIImageView alloc] initWithFrame:baseView.bounds];
    bkImgView.image=bkImg;
    [baseView addSubview:bkImgView];
    
    
    
    
    
    //轮播图视图 378x197
    UIView *showImageView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, winWidth, 200)];
    [baseView addSubview:showImageView];
    [showImageView setBackgroundColor:[UIColor clearColor]];
    
    CGFloat midImgViewWidth=350;
    CGFloat leftOffset1=(winWidth-midImgViewWidth)/2;
    CGRect midImgVIewRect=CGRectMake((winWidth-midImgViewWidth)/2, 1, midImgViewWidth, 198);
    UIImageView *midImgView=[[UIImageView alloc] initWithFrame:midImgVIewRect];
    UIImage *img1=[UIImage imageNamed:@"shiwuzhaoling.png"];
    midImgView.image=img1;
    [showImageView addSubview:midImgView];
    
    CGRect leftImgViewRect=CGRectMake(0, 0, midImgView.bounds.size.width/5*4, midImgView.bounds.size.height/5*4);
    UIImageView *leftImgView=[[UIImageView alloc] initWithFrame:leftImgViewRect];
    leftImgView.center=midImgView.center;
    CGRect newFrame1=leftImgView.frame;
    newFrame1.origin.x=0-leftImgView.bounds.size.width+(leftOffset1<=0?0:leftOffset1)+4;
    leftImgView.frame=newFrame1;
    [leftImgView setImage:[UIImage imageNamed:@"shiwuzhaoling.png"]];
    [showImageView addSubview:leftImgView];
    
    UIImageView *rightImgView=[[UIImageView alloc] initWithFrame:leftImgViewRect];
    rightImgView.center=midImgView.center;
    newFrame1=rightImgView.frame;
    newFrame1.origin.x=winWidth-(leftOffset1<=0?0:leftOffset1)-4;
    rightImgView.frame=newFrame1;
    [rightImgView setImage:[UIImage imageNamed:@"shiwuzhaoling.png"]];
    [showImageView addSubview:rightImgView];
    
    
    
    //快捷按钮视图
    UIView *buttonView=[[UIView alloc] initWithFrame:CGRectMake(0, showImageView.frame.origin.y+showImageView.bounds.size.height, winWidth, 120)];
    [baseView addSubview:buttonView];
    bkImg=[UIImage imageNamed:@"buttonViewBk.png"];
    bkImg=[bkImg stretchableImageWithLeftCapWidth:bkImg.size.width*0.3f topCapHeight:bkImg.size.height*0.3f];
    bkImgView=[[UIImageView alloc] initWithFrame:buttonView.bounds];
    bkImgView.image=bkImg;
    [buttonView addSubview:bkImgView];
    
    CGSize imgSize=CGSizeMake(80, 80);
    CGSize labelSize=CGSizeMake(imgSize.width, 20);
    CGFloat leftOffset=(winWidth-4*imgSize.width-3*10)/2;
    
    UIButton *imgViewSwjlu=[[UIButton alloc] initWithFrame:CGRectMake(leftOffset, 10, imgSize.width, imgSize.height)];
    UILabel *labSwjlu=[[UILabel alloc] initWithFrame:CGRectMake(imgViewSwjlu.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    UIButton *imgViewFbswu=[[UIButton alloc] initWithFrame:CGRectMake(imgViewSwjlu.frame.origin.x+imgSize.width+10, 10, imgSize.width, imgSize.height)];
    UILabel *labFbswu=[[UILabel alloc] initWithFrame:CGRectMake(imgViewFbswu.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    UIButton *imgViewZljlu=[[UIButton alloc] initWithFrame:CGRectMake(imgViewFbswu.frame.origin.x+imgSize.width+10, 10, imgSize.width, imgSize.height)];
    UILabel *labZljlu=[[UILabel alloc] initWithFrame:CGRectMake(imgViewZljlu.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    UIButton *imgViewFbzling=[[UIButton alloc] initWithFrame:CGRectMake(imgViewZljlu.frame.origin.x+imgSize.width+10, 10, imgSize.width, imgSize.height)];
    UILabel *labFbzling=[[UILabel alloc] initWithFrame:CGRectMake(imgViewFbzling.frame.origin.x, imgViewSwjlu.frame.origin.y+imgViewSwjlu.frame.size.height+1, labelSize.width, labelSize.height)];
    
    UIImage *img2=[UIImage imageNamed:@"shiwujilu.png"];
    [imgViewSwjlu setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewSwjlu.image=img2;
    img2=[UIImage imageNamed:@"fabushiwu.png"];
    [imgViewFbswu setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewFbswu.image=img2;
    img2=[UIImage imageNamed:@"zhaolingjilu.png"];
    [imgViewZljlu setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewZljlu.image=img2;
    img2=[UIImage imageNamed:@"fabuzhaoling.png"];
    [imgViewFbzling setBackgroundImage:img2 forState:UIControlStateNormal];
    //imgViewFbzling.image=img2;
    
    [imgViewSwjlu addTarget:self action:@selector(clickSWJLU:) forControlEvents:UIControlEventTouchUpInside];
    [imgViewFbswu addTarget:self action:@selector(clickFBSWU:) forControlEvents:UIControlEventTouchUpInside];
    [imgViewZljlu addTarget:self action:@selector(clickZLJLU:) forControlEvents:UIControlEventTouchUpInside];
    [imgViewFbzling addTarget:self action:@selector(clickFBZLING:) forControlEvents:UIControlEventTouchUpInside];
    
    [labSwjlu setText:@"失物记录"];
    [labFbswu setText:@"发布失物"];
    [labZljlu setText:@"招领记录"];
    [labFbzling setText:@"发布招领"];
    
    [labSwjlu setTextColor:qianlan];
    [labFbswu setTextColor:qianlan];
    [labZljlu setTextColor:qianlan];
    [labFbzling setTextColor:qianlan];
    
    [labSwjlu setFont:[UIFont systemFontOfSize:14]];
    [labFbswu setFont:[UIFont systemFontOfSize:14]];
    [labZljlu setFont:[UIFont systemFontOfSize:14]];
    [labFbzling setFont:[UIFont systemFontOfSize:14]];
    
    [labSwjlu setTextAlignment:NSTextAlignmentCenter];
    [labFbswu setTextAlignment:NSTextAlignmentCenter];
    [labZljlu setTextAlignment:NSTextAlignmentCenter];
    [labFbzling setTextAlignment:NSTextAlignmentCenter];
    
    [buttonView addSubview:imgViewSwjlu];
    [buttonView addSubview:labSwjlu];
    [buttonView addSubview:imgViewFbswu];
    [buttonView addSubview:labFbswu];
    [buttonView addSubview:imgViewZljlu];
    [buttonView addSubview:labZljlu];
    [buttonView addSubview:imgViewFbzling];
    [buttonView addSubview:labFbzling];
    
    
    //最新信息视图
    UIView *newMsgView=[[UIView alloc] initWithFrame:CGRectMake(0, buttonView.frame.origin.y+buttonView.frame.size.height, winWidth, 370)];
    [baseView addSubview:newMsgView];
    bkImg=[UIImage imageNamed:@"msgViewBk.png"];
    bkImg=[bkImg stretchableImageWithLeftCapWidth:bkImg.size.width*0.3f topCapHeight:bkImg.size.height*0.3f];
    bkImgView=[[UIImageView alloc] initWithFrame:newMsgView.bounds];
    bkImgView.image=bkImg;
    [newMsgView addSubview:bkImgView];
    
    CGFloat tableViewWidth=winWidth/25*22;
    CGFloat leftOffset3=(winWidth-tableViewWidth)/2;
    UIImageView *shugang=[[UIImageView alloc] initWithFrame:CGRectMake(leftOffset3, 20, 4, 20)];
    UILabel *labzxxx=[[UILabel alloc] initWithFrame:CGRectMake(shugang.frame.origin.x+shugang.frame.size.width+2, shugang.frame.origin.y, 100, shugang.frame.size.height)];
    
    UIImage *img3=[UIImage imageNamed:@"xiaoXiBiaoZhi.png"];
    shugang.image=img3;
    [labzxxx setTextColor:qianlan];
    [labzxxx setText:@"最新信息"];
    [labzxxx setFont:[UIFont systemFontOfSize:20]];
    
    [newMsgView addSubview:shugang];
    [newMsgView addSubview:labzxxx];
    
    UITableView *nnShow=[[UITableView alloc] initWithFrame:CGRectMake(leftOffset3, shugang.frame.origin.y+shugang.frame.size.height+5, tableViewWidth, newMsgView.bounds.size.height-shugang.frame.origin.y-shugang.frame.size.height-15) style:UITableViewStylePlain];
    [newMsgView addSubview:nnShow];
    nnShow.tag=34;
    [nnShow setSeparatorStyle:UITableViewCellSeparatorStyleNone];//去分割线
    [nnShow setShowsVerticalScrollIndicator:NO];//隐藏右侧滚动条
    [nnShow setDelegate:self];
    [nnShow setDataSource:self];
    [nnShow setBackgroundColor:[UIColor clearColor]];
    //[nnShow setContentInset:UIEdgeInsetsMake(0, 0, 200, 0)];//增加额外滚动范围
}

-(void)showRect:(CGRect)r{
    //NSLog(@"x=%f, y=%f, height=%f, width=%f", r.origin.x, r.origin.y, r.size.height, r.size.width);
}

#pragma mark - 4个按钮的点击事件

//button
-(void)clickSWJLU:(id)sender{
    NSLog(@"失物记录");
    if (self.showData == nil) {
        //提示，正在加载中，稍后重试
        [self popAlert:@"加载中，请稍后重试"];
        
    }else{
        recordViewController *swjlhere=[self getLostRecordVC];
        swjlhere.navigationItem.title=@"失物记录";
        
        
        
        
        //筛选出‘失物’纪录
        NSMutableArray *lostArr=[[NSMutableArray alloc] init];
        NSString *itemTypeString;
        NSArray *allData=[self.showData objectForKey:@"myData"];
        for (NSDictionary *eachDic in allData) {
            itemTypeString=[eachDic objectForKey:@"item_type"];
            if ([itemTypeString isEqualToString:@"失物"]) {
                [lostArr addObject:eachDic];
            }
        }
        
        NSDictionary *lostDic=[[NSDictionary alloc] initWithObjectsAndKeys:lostArr, @"myData", nil];
        swjlhere.showData=lostDic;
        swjlhere.imgCachePool=self.imgCachePool;
        
        //跳转至纪录视图
        [swjlhere setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:swjlhere animated:YES];
    }
}
-(void)clickFBSWU:(id)sender{
    
    if ([self.fDele isLoginFromFirstview]) {
        
        UIViewController *fbswhere=[self.fDele getFabuView];
        fbswhere.navigationItem.title=@"发布失物";
        [fbswhere setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:fbswhere animated:YES];
    }
}
-(void)clickZLJLU:(id)sender{
    NSLog(@"招领记录");
    
    if (self.showData == nil || self.imgCachePool == nil) {
        //提示，正在加载中，稍后重试
        [self popAlert:@"加载中，请稍后重试"];
        
    }else{
        recordViewController *zljlhere=[self getFindRecordVC];
        zljlhere.navigationItem.title=@"招领记录";
        
        
        
        
        //筛选出‘失物’纪录
        NSMutableArray *findArr=[[NSMutableArray alloc] init];
        NSString *itemTypeString;
        NSArray *allData=[self.showData objectForKey:@"myData"];
        for (NSDictionary *eachDic in allData) {
            itemTypeString=[eachDic objectForKey:@"item_type"];
            if ([itemTypeString isEqualToString:@"招领"]) {
                [findArr addObject:eachDic];
            }
        }
        
        NSDictionary *findDic=[[NSDictionary alloc] initWithObjectsAndKeys:findArr, @"myData", nil];
        zljlhere.showData=findDic;
        zljlhere.imgCachePool=self.imgCachePool;
        
        //跳转至纪录视图
        [zljlhere setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:zljlhere animated:YES];
    }
}
-(void)clickFBZLING:(id)sender{
    
    if ([self.fDele isLoginFromFirstview]) {
        
        UIViewController *fbzlhere=[self.fDele getZhaoLingView];
        fbzlhere.navigationItem.title=@"发布招领";
        [fbzlhere setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:fbzlhere animated:YES];
    }
}



#pragma mark - "最新信息"的tableview代理

//delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.showData == nil) {
        return 10;
    }
    
    NSArray *allData=[self.showData objectForKey:@"myData"];
    
    return allData.count>10 ? 10 : allData.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //这个tableview是"最新信息"
    newNewsCell *cell=[tableView dequeueReusableCellWithIdentifier:self.cellIdent];
    
    if (!cell) {
        cell=[[newNewsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:self.cellIdent];
    }
    
    //
    NSArray *allData=[self.showData objectForKey:@"myData"];
    NSDictionary *dic=allData[indexPath.row];
    
    
    if (allData == nil) {
        //name
        cell.labName.text=@"";
        //title
        cell.labTitle.text=@"加载中，请稍等";
        //time
        cell.labTime.text=@"";
    }else{
        //name
        cell.labName.text=([dic objectForKey:@"user_name"]==[NSNull null]?@"":[dic objectForKey:@"user_name"]);
        
        //title
        cell.labTitle.text=([dic objectForKey:@"title"]==[NSNull null]?@"":[dic objectForKey:@"title"]);
        
        //time
        cell.labTime.text=([dic objectForKey:@"lose_time"]==[NSNull null]?@"":[dic objectForKey:@"lose_time"]);
        
    }
    
    return  cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger num=indexPath.row;
    
    //cell选中时跳转操作
    singleRecordVC *srvc=[self getSingleRecordVC];
    NSArray *arr=[self.showData objectForKey:@"myData"];
    srvc.singleRecordData=arr[num];
    srvc.imgCachePool=self.imgCachePool;
    
    if (arr != nil) {
        
        [srvc setHidesBottomBarWhenPushed:YES];  //隐藏tabbar
        [self.navigationController pushViewController:srvc animated:YES];
    }
}



//VC
-(id)getLostRecordVC{
    if (!self.lostRecordVC) {
        self.lostRecordVC=[[recordViewController alloc] init];
    }
    
    return self.lostRecordVC;
}
-(id)getFindRecordVC{
    if (!self.findRecordVC) {
        self.findRecordVC=[[recordViewController alloc] init];
    }
    
    return self.findRecordVC;
}
-(id)getSingleRecordVC{
    if(!self.singleRecVC){
        self.singleRecVC=[[singleRecordVC alloc] init];
    }
    
    return self.singleRecVC;
}


#pragma mark - gotoView

-(void)gotoView:(id)where{
    UIViewController *w=where;
    
    [w setHidesBottomBarWhenPushed:YES];
    
    [self.navigationController pushViewController:w animated:YES];
}


#pragma mark - touch

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //收起按钮弹窗
    [self.uzd hidePopView];
    NSLog(@"first view");
}



#pragma mark - 即将显示

-(void)viewWillAppear:(BOOL)animated{
    //接收通知，数据加载完成和加载失败
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finish:) name:@"publicDataDownloadFinish" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fail:) name:@"publicDataDownloadFail" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imgCacheFinish:) name:@"imgCacheFinish" object:nil];
    
    //查询数据是否下载完成
    NSDictionary *firstData=[self.uzd getPublicData_all];
    self.imgCachePool=[self.uzd getImgCachePool];
    
    if (firstData != nil) {
        //self.showData=firstData;
        self.showData=[self sortByCreatetime:firstData];
        
        UITableView *tb=[self.view viewWithTag:34];
        [tb reloadData];
    }
    else{
        self.showData=nil;
        NSLog(@"firstview firstData is nil");
    }
    
    
}

-(void)viewDidAppear:(BOOL)animated{
//    //[self animateInLayer];
//    UIView *maskView=[[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
//    self.maskView=maskView;
//    maskView.backgroundColor=[UIColor blackColor];
//    maskView.alpha=0.6;
//
//    [[UIApplication sharedApplication].keyWindow addSubview:maskView];
//    UITapGestureRecognizer *tapp=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ttppAction:)];
//    [maskView addGestureRecognizer:tapp];
//
//    //绘制圆点
//    UIBezierPath *circleOld=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, 10, 10)];
//    CAShapeLayer *circleLayer=[[CAShapeLayer alloc] init];
//    circleLayer.bounds          = CGRectMake(0, 0, 10, 10);
//    circleLayer.path            = circleOld.CGPath;
//    circleLayer.fillColor       = [UIColor whiteColor].CGColor;
//    circleLayer.fillRule        = kCAFillRuleEvenOdd;
//    circleLayer.position        = self.view.center;
//    //绘图未完成
//
//    [maskView.layer addSublayer:circleLayer];
}


#pragma mark - 视图即将隐藏

-(void)viewWillDisappear:(BOOL)animated{
    
    //移除通知响应
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"publicDataDownloadFinish" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"publicDataDownloadFail" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"imgCacheFinish" object:nil];
}


#pragma mark - 获取信息

-(void)getNewMsg{
    
    
    NSString *domainString=DOMAIN_SET;
    NSString *urlString=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/swzl/swzlLists", domainString];
    NSURL *realUrl=[[NSURL alloc] initWithString:urlString];
    NSString *uidString=[[NSUserDefaults getData:@"userInfo"] objectForKey:@"uid"];
    
    //创建请求体字符串
    NSString *post=[[NSString alloc] initWithFormat:@"uid=%@", uidString];//再警告扁你！！！
    
    //字符串转UTF-8编码方式
    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
    
    //创建请求体
    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
    
    //设置请求方式
    [request setHTTPMethod:@"post"];
    
    //填充请求体
    [request setHTTPBody:postData];
    
    //配置会话
    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    //创建会话
    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"请求完成...");
        if (!error) {
            NSLog(@"成功");
            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
            if ([code isEqualToString:@"1"]) {
                NSArray *dataArr=[nd objectForKey:@"data"];
                self.showData=[[NSDictionary alloc] initWithObjectsAndKeys:dataArr, @"myData", nil];
                
            } else {
                NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                //加个失败弹窗
            }
        } else {
            NSLog(@"失败， %@", error);
            //加个失败弹窗
        }
    }];
    //执行会话任务
    [task resume];
}

#pragma mark - layer层动画

-(void)animateInLayer{
    
    self.greenLayer=[[CALayer alloc] init];
    self.greenLayer.bounds          = CGRectMake(0, 0, 200, 45);
    self.greenLayer.position        = self.view.center;
    self.greenLayer.backgroundColor = [UIColor blueColor].CGColor;
    
    self.redLayer=[[CAShapeLayer alloc] init];
    self.redLayer.bounds            = CGRectMake(0, 0, 200, 45);
    self.redLayer.position          = self.view.center;
    self.redLayer.path              = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, 1, 45)].CGPath;
    self.redLayer.fillColor         = [UIColor orangeColor].CGColor;
    self.redLayer.fillMode          = kCAFillRuleEvenOdd;
    
    
    CGFloat winWidth=[UIScreen mainScreen].bounds.size.width;
    CGFloat winHeight=[UIScreen mainScreen].bounds.size.height;
    self.maskLayer=[[CALayer alloc] init];
    self.maskLayer.frame            = CGRectMake(0, 0, winWidth, winHeight);
    [self.view.layer.mask addSublayer:self.maskLayer];
    
    self.changeValue=1;
    [self.view.layer addSublayer:self.greenLayer];
    [self.view.layer addSublayer:self.redLayer];
    
    
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(layerAction)];
    [self.displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

-(void)layerAction{
    self.changeValue+=1;
    self.redLayer.path=[UIBezierPath bezierPathWithRect:CGRectMake(0, 0, self.changeValue, 45)].CGPath;
    
    if (self.changeValue >=200) {
        [self.displayLink invalidate];
        [self.redLayer setHidden:YES];
        [self.greenLayer setHidden:YES];
    }
}

#pragma mark - 点触手势

-(void)ttppAction:(UITapGestureRecognizer *)gesture{
    NSLog(@"tap to hide maskview");
    [[UIApplication sharedApplication].keyWindow sendSubviewToBack:self.maskView];
}

#pragma mark - 通知

-(void)finish:(NSNotification *)noti{
    NSLog(@"收到数据缓存完成通知");
    NSDictionary *fData=[noti object];
    
    //self.showData=fData;
    self.showData=[self sortByCreatetime:fData];
    
    //收到加载数据完成的通知，然后刷新tableview
    UITableView *tb=[self.view viewWithTag:34];
    [tb reloadData];
}

-(void)fail:(NSNotification *)noti{
    NSLog(@"receive fail noticifity");
    
}

-(void)imgCacheFinish:(NSNotification *)noti{
    NSLog(@"收到图片缓存完成通知");
    self.imgCachePool=[noti object];
    //图片缓存完成就代表所有相关的数据请求完成
    self.isRefreshOver=YES;
    
    
    //收到加载图片数据完成的通知，然后刷新tableview
    UITableView *tb=[self.view viewWithTag:34];
    [tb reloadData];
}


#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}

#pragma mark - 按时间排序

-(NSDictionary *)sortByCreatetime:(NSDictionary *)oldDic{
    if (oldDic == nil) {
        return nil;
    }
    NSArray *oldArr=[oldDic objectForKey:@"myData"];
    NSArray *newArr=[oldArr sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSDictionary *d1=obj1;
        NSDictionary *d2=obj2;
        
        NSString *s1=[d1 objectForKey:@"create_time"];
        NSString *s2=[d2 objectForKey:@"create_time"];
        
        if ([s1 compare:s2] == NSOrderedAscending) {
            return NSOrderedAscending;
        }else{
            return NSOrderedDescending;
        }
    }];
    
    NSDictionary *newDic=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
    
    return newDic;
}

#pragma mark - 滚动视图代理

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    
    if (self.isRefreshOver == YES) {
        if (scrollView.contentOffset.y<-30) {
            
            //防止短时间内进行重复操作
            self.isRefreshOver=NO;
            
            //广播-“需要重新请求所有数据”
            NSLog(@"广播-\"刷新，全局数据\"");
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshAlldata" object:nil];
        }
    }
}

@end
