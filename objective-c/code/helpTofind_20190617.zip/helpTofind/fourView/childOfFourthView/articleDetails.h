//
//  articleDetails.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/18.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol articleDelegate <NSObject>

@optional

-(void)setViewFrame;

@end

@interface articleDetails : UIViewController

@property(strong, nonatomic) UITextView *articleTextView;
@property(strong, nonatomic)NSString *showArticle;

@end
