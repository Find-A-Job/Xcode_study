//
//  zxCell.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/18.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "zxCell.h"

@interface zxCell()


@end

@implementation zxCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    //视图上的imgview和label留着不删
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    
    //添加控件, 一个uiimage和三个uilabel
    CGFloat spacingBetweenLeftAndRight=15;
    CGFloat spacingBetweenUpAndDown=20;
    CGFloat cellHeight=150;
    
    //CGPoint imgXY=CGPointMake(winWidth/10, cellHeight/8);
    CGSize  imgSize=CGSizeMake(winWidth/10*3, cellHeight/4*3);
    CGSize  titleSize=CGSizeMake(winWidth/10*5, cellHeight/4);
    CGSize  authorSize=CGSizeMake(titleSize.width, cellHeight/4);
    CGSize  dateSize=CGSizeMake(authorSize.width, cellHeight/4);
    
    //创建控件
    self.leftImg=[[UIImageView alloc] initWithFrame:CGRectMake(winWidth/20, cellHeight/8, imgSize.width, imgSize.height)];
    self.titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(self.leftImg.frame.origin.x+self.leftImg.bounds.size.width+winWidth/30, self.leftImg.frame.origin.y, titleSize.width, titleSize.height)];
    self.authorLabel=[[UILabel alloc] initWithFrame:CGRectMake(self.titleLabel.frame.origin.x, self.titleLabel.frame.origin.y+self.titleLabel.bounds.size.height, authorSize.width, authorSize.height)];
    self.dateLabel=[[UILabel alloc] initWithFrame:CGRectMake(self.authorLabel.frame.origin.x, self.authorLabel.frame.origin.y+self.authorLabel.bounds.size.height, dateSize.width, dateSize.height)];
    
    //占位，可注释掉
//    self.titleLabel.backgroundColor=[UIColor orangeColor];
//    self.authorLabel.backgroundColor=[UIColor grayColor];
//    self.dateLabel.backgroundColor=[UIColor orangeColor];
    
    //字号
    self.titleLabel.font=[UIFont systemFontOfSize:16];
    self.authorLabel.font=[UIFont systemFontOfSize:13];
    self.dateLabel.font=[UIFont systemFontOfSize:10];
    
    //字体颜色
    [self.titleLabel setTextColor:qianhui];
    [self.authorLabel setTextColor:qianhui];
    [self.dateLabel setTextColor:qianhui];
    
    //加入视图中
    [self addSubview:self.leftImg];
    [self addSubview:self.titleLabel];
    [self addSubview:self.authorLabel];
    [self addSubview:self.dateLabel];
    
    //背景色毛玻璃效果
    [self setBackgroundColor:[UIColor clearColor]];
    
    //设置背景视图
    [self setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"zx_di.png"]]];
    
    //显示箭头
    [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    
    //点击不会变为高亮状态
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return self;
}

@end
