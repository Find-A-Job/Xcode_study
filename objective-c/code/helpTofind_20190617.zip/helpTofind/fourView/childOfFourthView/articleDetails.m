//
//  articleDetails.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/18.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import "articleDetails.h"

@interface articleDetails()


@end

@implementation articleDetails

-(void)viewDidLoad{
    [super viewDidLoad];
    
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight=[[UIScreen mainScreen] bounds].size.height;
    
    //设置标题
    self.navigationItem.title=@"文章详情";
    
    //设置背景
    UIImageView *bkImgView=[[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:bkImgView];
    [bkImgView setImage:[UIImage imageNamed:@"di.png"]];
    
    //文章视图背景
    UIImageView *textBK=[[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 355, winHeight)];
    UIImage *cellBKImg=[UIImage imageNamed:@"usualBK.png"];
    cellBKImg=[cellBKImg resizableImageWithCapInsets:UIEdgeInsetsMake(cellBKImg.size.height*0.2f, cellBKImg.size.width*0.2f, cellBKImg.size.height*0.2f, cellBKImg.size.width*0.2f)];
    textBK.image=cellBKImg;
    [self.view addSubview:textBK];
    [textBK setUserInteractionEnabled:YES];
    
    //文章
    UITextView *ut=[[UITextView alloc] initWithFrame:CGRectMake(20, 50, 315, winHeight)];
    [textBK addSubview:ut];
    self.articleTextView=ut;
    ut.text=self.showArticle;

    
    //字体大小, 24
    [ut setFont:[UIFont systemFontOfSize:18]];
    
    //不可编辑
    [ut setEditable:NO];
    
    //增加额外滚动范围
    [ut setContentInset:UIEdgeInsetsMake(0, 0, 300, 0)];
}


@end
