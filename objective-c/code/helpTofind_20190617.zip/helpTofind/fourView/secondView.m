//
//  secondView.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#warning "mission"
#pragma mark - 没完成的事。1，电话、短信、评论按钮的响应


#import "secondView.h"
#import "xuanshangTableView.h"
#import "childOfSecond/cellOfxs/clickCommentDelegate.h"

@interface secondView() <UITextFieldDelegate, clickCommentDelegate>

@property(strong, nonatomic) UITextField *editBox;

@property(strong, nonatomic)xuanshangTableView *xstv;

//刷新小菊花
@property(strong, nonatomic)UIActivityIndicatorView *littleFlower;

//排序标签
@property(strong, nonatomic)UISegmentedControl *uisc;

//
-(void)keyboardUp:(NSNotification *)sender;
-(void)keyboardDown:(NSNotification *)sender;

//
-(void)enterBk:(id)sender;
-(void)enterFk:(id)sender;


@end



@implementation secondView

-(void)viewDidLoad{
    [super viewDidLoad];
    
    //color
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    CGFloat winWidth=[[UIScreen mainScreen] bounds].size.width;
    
    //背景
    UIImageView *shangdiView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shangdi1.png"]];
    [self.view addSubview:shangdiView];
    [self.view setBackgroundColor:[UIColor whiteColor]];//需要改成灰色
    
    //按时间排序，按赏金排序
    UISegmentedControl *sortType=[[UISegmentedControl alloc] initWithFrame:CGRectMake(0, 0, winWidth, 40)];
    [sortType insertSegmentWithTitle:@"按时间排序" atIndex:0 animated:YES];
    [sortType insertSegmentWithTitle:@"按赏金排序" atIndex:1 animated:YES];
    [sortType setSelectedSegmentIndex:0];//初始下标
    [sortType setApportionsSegmentWidthsByContent:YES];//等分
    [sortType setBackgroundColor:[UIColor clearColor]];
    [sortType setTitleTextAttributes:[[NSDictionary alloc] initWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [sortType addTarget:self action:@selector(segmeChanged:) forControlEvents:UIControlEventValueChanged]; //添加点击事件
    
    [self.view addSubview:sortType];
    self.uisc=sortType;
    
    
    //表格
    xuanshangTableView *xs=[[xuanshangTableView alloc] initWithStyle:UITableViewStylePlain];
    self.xstv=xs;
    [self addChildViewController:xs];
    [self.view addSubview:xs.view];
    xs.commentDelegate=self;
    
    //输入框
    UITextField *putText=[[UITextField alloc] initWithFrame:CGRectMake(0, 200, 375, 50)];
    [putText setBackgroundColor:[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f]];
    [putText setFont:[UIFont systemFontOfSize:20]];
    [putText setTextColor:[UIColor blackColor]];
    putText.delegate=self;
    [putText setHidden:YES];
    [self.view addSubview:putText];
    [self.view bringSubviewToFront:putText];
    self.editBox=putText;
    
    //输入框右侧按钮
    UIButton *fasong=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 38, 28)];//x,y属性没效果
    [fasong setTitle:@"发送" forState:UIControlStateNormal];
    [fasong setTitleColor:qianlan forState:UIControlStateNormal];
    [putText setRightView:fasong];
    [putText setRightViewMode:UITextFieldViewModeWhileEditing];
    
    
    //刷新小菊花
    UIActivityIndicatorView *lf=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.littleFlower=lf;
    self.littleFlower.center=CGPointMake(winWidth/2, 70);
    //self.littleFlower.color=[UIColor redColor];
    self.littleFlower.backgroundColor=[UIColor clearColor];
    self.littleFlower.hidesWhenStopped=YES;//停止时隐藏
    //[self.littleFlower setHidden:NO];
    
    [shangdiView addSubview:self.littleFlower];
}

#pragma mark - 视图出现和消失

-(void)viewWillAppear:(BOOL)animated{
    //注册监听数据下载进度
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finish:) name:@"publicDataDownloadFinish" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fail:) name:@"publicDataDownloadFail" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imgCacheFinish:) name:@"imgCacheFinish" object:nil];
    
    
    //筛选出带赏金的数据
    NSDictionary *moneyDic=[self screenDic:[self.uzd getPublicData_all]];
    
    //先按时间排序一次
    NSArray *oldArr=[NSArray arrayWithArray:[moneyDic objectForKey:@"myData"]];
    NSArray *newArr=[oldArr sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSDictionary *dic1=obj1;
        NSDictionary *dic2=obj2;
        
        NSString *s1=[NSString stringWithFormat:@"%@", [dic1 objectForKey:@"create_time"]];
        NSString *s2=[NSString stringWithFormat:@"%@", [dic2 objectForKey:@"create_time"]];
        
        if ([s1 compare:s2] == NSOrderedDescending) {
            return NSOrderedDescending;//升序
        }else{
            return NSOrderedAscending;//降序
        }
        
    }];
    
    NSDictionary *newDic=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
    self.xstv.showData=newDic;
    
    //缓存的图片
    self.xstv.imgCachePool=[self.uzd getImgCachePool];
}


-(void)viewWillDisappear:(BOOL)animated{
    //页面消失，注销相关活动
    NSLog(@"页面隐藏");
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
    
    
    //移除监听
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"publicDataDownloadFinish" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"publicDataDownloadFail" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"imgCacheFinish" object:nil];
}
-(void)viewDidAppear:(BOOL)animated{
    //监听键盘,设置编辑框高度（在键盘上方），以及注销监听，防止多次监听
    //...
    NSLog(@"页面出现");
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDown:) name:UIKeyboardWillHideNotification object:nil];
    
    //进入后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterBk:) name:UIApplicationWillResignActiveNotification object:nil];
    
    //变为活动状态
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterFk:) name:UIApplicationDidBecomeActiveNotification object:nil];
}

#pragma mark - 键盘代理

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [self.editBox setHidden:YES];
    
    return YES;
}

-(void)keyboardUp:(NSNotification *)sender{
    NSValue *keyboard=[(NSDictionary *)[sender userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey];
    
    if ([sender.name isEqualToString:UIKeyboardWillShowNotification]) {
        CGRect keyboardRect=[keyboard CGRectValue];
        [self.editBox setCenter:CGPointMake(keyboardRect.size.width/2.0f, keyboardRect.origin.y-self.editBox.bounds.size.height/2.0f-64)];//60
        [self.editBox setHidden:NO];
    }
}
//键盘收起， textfiled隐藏, 清空
-(void)keyboardDown:(NSNotification *)sender{
    if ([sender.name isEqualToString:UIKeyboardWillHideNotification]) {
        [self.editBox setHidden:YES];
        [self.editBox setText:@""];
    }
}



#pragma mark - gotoView

-(void)gotoView:(id)where{
    UIViewController *w=where;
    
    [w setHidesBottomBarWhenPushed:YES];
    
    [self.navigationController pushViewController:w animated:YES];
}


#pragma mark - touch

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //收起按钮弹窗
    [self.uzd hidePopView];
    NSLog(@"second view");
}


#pragma mark - 通知

-(void)finish:(NSNotification *)noti{
    NSLog(@"收到数据缓存完成通知");
    
    //更新数据
    NSDictionary *fData=[noti object];
    NSDictionary *moneyDic=[self screenDic:fData];
    //先按时间/赏金排序一次, 待解决的问题，赏金排序中，这里的排序方法和segment里的排序方法，产生的结果不一样
    NSString *sortType=(self.uisc.selectedSegmentIndex == 0 ? @"create_time" : @"for_money");
    NSArray *oldArr=[NSArray arrayWithArray:[moneyDic objectForKey:@"myData"]];
    NSArray *newArr=[oldArr sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSDictionary *dic1=obj1;
        NSDictionary *dic2=obj2;
        
        NSString *s1=[NSString stringWithFormat:@"%@", [dic1 objectForKey:sortType]];
        NSString *s2=[NSString stringWithFormat:@"%@", [dic2 objectForKey:sortType]];
        
        if ([s1 compare:s2] == NSOrderedDescending) {
            return NSOrderedDescending;//升序
        }else{
            return NSOrderedAscending;//降序
        }
        
    }];
    
    NSDictionary *newDic=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
    self.xstv.showData=newDic;
    
    //收到加载数据完成的通知，然后刷新tableview
    [self.xstv.tableView reloadData];
}

-(void)fail:(NSNotification *)noti{
    NSLog(@"receive fail noticifity");
    
}

-(void)imgCacheFinish:(NSNotification *)noti{
    NSLog(@"收到图片缓存完成通知");
    
    
    
    self.xstv.imgCachePool=[noti object];
    //图片缓存完成就代表所有相关的数据请求完成
    self.xstv.isRefreshOver=YES;
    
    [self.xstv.tableView reloadData];
}



-(void)enterBk:(id)sender{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}
-(void)enterFk:(id)sender{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardUp:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDown:) name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - 筛选

-(NSDictionary *)screenDic:(NSDictionary *)data{
    if (data == nil) {
        return nil;
    }else{
        
        NSArray *arr=[data objectForKey:@"myData"];
        if (arr == nil) {
            return nil;
        }else{
            
            NSMutableArray *newArr=[[NSMutableArray alloc] init];
            
            for (NSDictionary *dic in arr) {
                NSString *moneyString=[dic objectForKey:@"for_money"];
                if (moneyString == nil || moneyString.intValue <= 0) {
                    ;
                }else{
                    [newArr addObject:dic];
                }
            }
            
            if (newArr.count <= 0) {
                return nil;
            }else{
                
                NSDictionary *moneyData=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
                return moneyData;
            }
        }
    }
    
}

#pragma mark - 分段控件点击事件

-(void)segmeChanged:(UISegmentedControl *)sender{
    if(self.xstv.showData == nil){
        return;
    }
    
    switch (sender.selectedSegmentIndex) {
        case 0:
        {
            NSLog(@"按时间排序");
            //按时间排序
            NSArray *oldArr=[NSArray arrayWithArray:[self.xstv.showData objectForKey:@"myData"]];
            NSArray *newArr=[oldArr sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
                NSDictionary *dic1=obj1;
                NSDictionary *dic2=obj2;
                
                NSString *s1=[NSString stringWithFormat:@"%@", [dic1 objectForKey:@"create_time"]];
                NSString *s2=[NSString stringWithFormat:@"%@", [dic2 objectForKey:@"create_time"]];
                
                if ([s1 compare:s2] == NSOrderedDescending) {
                    return NSOrderedDescending;//升序
                }else{
                    return NSOrderedAscending;//降序
                }
                
            }];
            
            NSDictionary *newDic=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
            self.xstv.showData=newDic;
        }
            break;
            
        case 1:
        {
            NSLog(@"按赏金排序");
            //按赏金排序
            NSArray *oldArr=[NSArray arrayWithArray:[self.xstv.showData objectForKey:@"myData"]];
            NSArray *newArr=[oldArr sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
                NSDictionary *dic1=obj1;
                NSDictionary *dic2=obj2;
                
                NSString *s1=[NSString stringWithFormat:@"%@", [dic1 objectForKey:@"for_money"]];
                NSString *s2=[NSString stringWithFormat:@"%@", [dic2 objectForKey:@"for_money"]];
                
                if ([s1 compare:s2] == NSOrderedDescending) {
                    return NSOrderedDescending;//升序
                }else{
                    return NSOrderedAscending;//降序
                }
                
            }];
            
            NSDictionary *newDic=[[NSDictionary alloc] initWithObjectsAndKeys:newArr, @"myData", nil];
            self.xstv.showData=newDic;
        }
            break;
            
        default:
            break;
    }
    
    [self.xstv.tableView reloadData];
}

#pragma mark - clickCommentDelegate代理

-(void)startActivityIndicator{
    [self.littleFlower startAnimating];
}

-(void)stopActivityIndicator{
    
    [self.littleFlower stopAnimating];
}

#pragma mark - 显示简介


-(void)showKeyboard{
//    [self.editBox setHidden:NO];
//    [self.editBox setText:@""];
//    [self.editBox becomeFirstResponder];
}

-(void)showOverView:(NSInteger)ind{

}

@end
