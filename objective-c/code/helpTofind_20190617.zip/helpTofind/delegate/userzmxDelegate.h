//
//  usezmx.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/17.
//  Copyright © 2019年 电脑. All rights reserved.
//

#ifndef usezmx_h
#define usezmx_h
//#import <Foundation/Foundation.h>

@protocol userzmxDegelate

@optional
-(CGRect)getTabbarRect;
-(void)hidePopView;
-(id)getLoginVC;
-(id)getLogonVC;
-(BOOL)isLogin;


//获取公共数据
-(NSDictionary *)getPublicData_all;
-(NSDictionary *)getImgCachePool;
-(NSDictionary *)getUserData_all;
-(NSDictionary *)getUserImgCachePool;

//wodeziliao
-(void)logoutFromWDZL;

@end

#endif /* usezmx_h */
