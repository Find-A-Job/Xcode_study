//
//  loginVC.m
//  helpTofind
//
//  Created by rdt on 2019/5/21.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "loginVC.h"
#import "../dataPersistence/NSUserDefaults+nsUD_cate.h"
#import "../main/global.h"

@interface loginVC () <UITextFieldDelegate, NSURLSessionDelegate>


-(void)clickLoginBtn:(id)sender;
-(void)clickLogonBtn:(id)sender;
-(void)clickCancelBtn:(id)sender;

@end

@implementation loginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view setBackgroundColor:[UIColor orangeColor]];
    
    //登录
#pragma mark - login
    
    
    //全局
    CGFloat winWidth    = [[UIScreen mainScreen] bounds].size.width;
    CGFloat winHeight   = [[UIScreen mainScreen] bounds].size.height;
    CGPoint winCenter   = CGPointMake(winWidth/2, winHeight/2);
    CGFloat statusBarHei= [[UIApplication sharedApplication] statusBarFrame].size.height;
    
    
    //颜色  浅1-3深 ECF3FE 8EBEFE
    UIColor *lanse1=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    UIColor *lanse2=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *lanse3=[UIColor colorWithRed:0x08/255.0f green:0x53/255.0f blue:0x94/255.0f alpha:1.0f];
    UIColor *editboxColor=[UIColor colorWithRed:0xec/255.0f green:0xf3/255.0f blue:0xfe/255.0f alpha:1.0f];
    UIColor *btnColor=[UIColor colorWithRed:0x8e/255.0f green:0xbe/255.0f blue:0xfe/255.0f alpha:1.0f];
    
    
    
    //字体尺寸
    CGFloat fontSize=2.6;
    
    
    //控件尺寸位置
    CGSize titleSize            = CGSizeMake(winWidth/10*3, winHeight/40);
    CGSize cancelSize           = CGSizeMake(titleSize.width/2, titleSize.height);
    CGSize topBlueBkSize        = CGSizeMake(winWidth, winHeight/9*2);
    CGSize bottomBkSize         = CGSizeMake(winWidth, winHeight-topBlueBkSize.height);
    CGSize showBoxSize          = CGSizeMake(winWidth, winHeight/2);
    CGSize accountLabelSize     = CGSizeMake(winWidth/7, winHeight/16);
    CGSize accountEditBoxSize   = CGSizeMake(winWidth/7*5, accountLabelSize.height);
    CGSize passwordLabelSize    = accountLabelSize;
    CGSize passwordEditBoxSize  = accountEditBoxSize;
    CGSize loginBtnSize         = CGSizeMake(winWidth/7*6, accountEditBoxSize.height/4*5);
    CGSize logonBtnSize         = CGSizeMake(winWidth/8*3, winHeight/28);
    
    
    //载入图片
    UIImage *topBkImg       = [UIImage imageNamed:@"blueTopBk.png"];
    UIImage *bottomBkImg    = [UIImage imageNamed:@"qianqianlanBK.png"];
    UIImage *editboxImg     = [UIImage imageNamed:@"qianqianlanBK.png"];
    UIImage *cellBkImg      = [UIImage imageNamed:@"usualBK.png"];
    
    bottomBkImg             = [bottomBkImg resizableImageWithCapInsets:UIEdgeInsetsMake(bottomBkImg.size.height*0.2f, bottomBkImg.size.width*0.2f, bottomBkImg.size.height*0.2f, bottomBkImg.size.width*0.2f)];
    editboxImg              = [editboxImg resizableImageWithCapInsets:UIEdgeInsetsMake(editboxImg.size.height*0.2f, editboxImg.size.width*0.2f, editboxImg.size.height*0.2f, editboxImg.size.width*0.2f)];
    cellBkImg               = [cellBkImg resizableImageWithCapInsets:UIEdgeInsetsMake(cellBkImg.size.height*0.2f, cellBkImg.size.width*0.2f, cellBkImg.size.height*0.2f, cellBkImg.size.width*0.2f)];
    
    
    //加入视图
    UIImageView *topBkImgView       = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, topBlueBkSize.width, topBlueBkSize.height)];
    UIImageView *bottomBkImgView    = [[UIImageView alloc] initWithFrame:CGRectMake(0, topBlueBkSize.height, bottomBkSize.width, bottomBkSize.height)];
    UIImageView *cellBkImgView      = [[UIImageView alloc] initWithFrame:CGRectMake(0, showBoxSize.height/3, showBoxSize.width, showBoxSize.height)];
    
    topBkImgView.image          = topBkImg;
    bottomBkImgView.image       = bottomBkImg;
    cellBkImgView.image         = cellBkImg;
    
    [self.view addSubview:topBkImgView];
    [self.view addSubview:bottomBkImgView];
    [self.view addSubview:cellBkImgView];
    
    
    //账号密码
    UILabel *accountLabel       = [[UILabel alloc] initWithFrame:CGRectMake(accountLabelSize.width/2, showBoxSize.height/8+cellBkImgView.frame.origin.y, accountLabelSize.width, accountLabelSize.height)];
    UITextField *accountEditbox = [[UITextField alloc] initWithFrame:CGRectMake(accountLabel.frame.origin.x+accountLabelSize.width, accountLabel.frame.origin.y, accountEditBoxSize.width, accountEditBoxSize.height)];
    UILabel *passwordLabel      = [[UILabel alloc] initWithFrame:CGRectMake(accountLabel.frame.origin.x, showBoxSize.height/8+accountLabelSize.height+accountLabel.frame.origin.y, passwordLabelSize.width, passwordLabelSize.height)];
    UITextField *passwordEditbox= [[UITextField alloc] initWithFrame:CGRectMake(accountEditbox.frame.origin.x, passwordLabel.frame.origin.y, passwordEditBoxSize.width, passwordEditBoxSize.height)];
    
    [self.view addSubview:accountLabel];
    [self.view addSubview:accountEditbox];
    [self.view addSubview:passwordLabel];
    [self.view addSubview:passwordEditbox];
    
    
    accountEditbox.delegate=self;
    passwordEditbox.delegate=self;
    
    accountEditbox.tag=120;
    passwordEditbox.tag=121;
    
    accountLabel.textColor          = lanse2;
    passwordLabel.textColor         = lanse2;
    accountEditbox.textColor        = lanse2;
    passwordEditbox.textColor       = lanse2;
    
    accountLabel.font               = [UIFont systemFontOfSize:accountLabelSize.height/fontSize];
    passwordLabel.font              = [UIFont systemFontOfSize:accountLabelSize.height/fontSize];
    accountEditbox.font             = [UIFont systemFontOfSize:accountLabelSize.height/fontSize-2];
    passwordEditbox.font            = [UIFont systemFontOfSize:accountLabelSize.height/fontSize-2];
    
    accountLabel.text               = @"账号";
    passwordLabel.text              = @"密码";
    accountEditbox.placeholder      = @"    请输入您的账号(不超过12位)";
    passwordEditbox.placeholder     = @"    请输入您的密码(不超过12位)";
    
    [accountLabel setTextAlignment:NSTextAlignmentCenter];
    [passwordLabel setTextAlignment:NSTextAlignmentCenter];
    
    accountEditbox.backgroundColor  = editboxColor;
    passwordEditbox.backgroundColor = editboxColor;
    
    [accountEditbox.layer setCornerRadius:12];
    [accountEditbox.layer setMasksToBounds:YES];
    [passwordEditbox.layer setCornerRadius:12];
    [passwordEditbox.layer setMasksToBounds:YES];
    
    //设置为密码形式
    passwordEditbox.secureTextEntry=YES;
    
    
    //登录 注册
    UIButton *loginBtn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, loginBtnSize.width, loginBtnSize.height)];
    UIButton *logonBtn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, logonBtnSize.width, logonBtnSize.height)];
    
    loginBtn.center=winCenter;
    CGRect position=loginBtn.frame;
    position.origin.y=passwordLabel.frame.origin.y+passwordLabelSize.height+showBoxSize.height/8;
    loginBtn.frame=position;
    
    logonBtn.center=winCenter;
    position=logonBtn.frame;
    position.origin.y=loginBtn.frame.origin.y+loginBtnSize.height+showBoxSize.height/8/2;
    logonBtn.frame=position;
    
    [self.view addSubview:loginBtn];
    [self.view addSubview:logonBtn];
    
    [loginBtn addTarget:self action:@selector(clickLoginBtn:) forControlEvents:UIControlEventTouchUpInside];
    [logonBtn addTarget:self action:@selector(clickLogonBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    loginBtn.titleLabel.textAlignment=NSTextAlignmentCenter;
    logonBtn.titleLabel.textAlignment=NSTextAlignmentCenter;
    
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [logonBtn setTitleColor:lanse3 forState:UIControlStateNormal];
    
    [loginBtn setTitle:@"登  录" forState:UIControlStateNormal];
    [logonBtn setTitle:@"没有账号？点此注册" forState:UIControlStateNormal];
    
    loginBtn.backgroundColor=btnColor;
    logonBtn.backgroundColor=[UIColor whiteColor];
    
    loginBtn.titleLabel.font=[UIFont systemFontOfSize:accountLabelSize.height/fontSize+5];
    logonBtn.titleLabel.font=[UIFont systemFontOfSize:accountLabelSize.height/fontSize-2];
    
    [loginBtn.layer setCornerRadius:8];
    [loginBtn.layer setMasksToBounds:YES];
    
    ///下划线
    UIView *underlineView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, logonBtnSize.width, 1)];
    [underlineView setBackgroundColor:lanse3];
    [self.view addSubview:underlineView];
    underlineView.center=logonBtn.center;
    position=underlineView.frame;
    position.origin.y+=(logonBtnSize.height/2+1);
    underlineView.frame=position;
    
    
    
    //标题 左上取消按钮
    UILabel *titleLabel     = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, titleSize.width, titleSize.height)];
    UIButton *cancelBtn     = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, cancelSize.width, cancelSize.height)];
    
    titleLabel.center=winCenter;
    position=titleLabel.frame;
    position.origin.y=statusBarHei+10;
    titleLabel.frame=position;
    
    cancelBtn.center=titleLabel.center;
    position=cancelBtn.frame;
    position.origin.x=15;
    cancelBtn.frame=position;
    
    [self.view addSubview:titleLabel];
    [self.view addSubview:cancelBtn];
    
    titleLabel.textAlignment=NSTextAlignmentCenter;
    cancelBtn.titleLabel.textAlignment=NSTextAlignmentCenter;
    
    titleLabel.textColor=[UIColor whiteColor];
    [cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    titleLabel.text=@"朝丢夕拾";
    [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
    
    titleLabel.font=[UIFont systemFontOfSize:accountLabelSize.height/fontSize+5];
    cancelBtn.titleLabel.font=[UIFont systemFontOfSize:accountLabelSize.height/fontSize+3];
    
    titleLabel.backgroundColor=[UIColor clearColor];
    cancelBtn.backgroundColor=[UIColor clearColor];
    
    
    [cancelBtn addTarget:self action:@selector(clickCancelBtn:) forControlEvents:UIControlEventTouchUpInside];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - btn click

//#warning "login view click event"
-(void)clickLoginBtn:(id)sender{
    UITextField *account=[self.view viewWithTag:120];
    UITextField *password=[self.view viewWithTag:121];
    
    NSString *accountString=[account text];
    NSString *passwordString=[password text];
    
    if ([accountString length]>16 || [accountString length]<4 || [passwordString length]>16 || [passwordString length]<4) {
#warning pop alert win
        //加个错误弹窗
        NSLog(@"账号长度或密码长度不符合规定");
        
        [self popAlert:@"账号长度或密码长度不符合规定"];
    } else {
        //@"http://%@/index.php?s=/login/loginJson"
        //NSString *domainString=@"192.168.20.20:83";
        NSString *domainString=DOMAIN_SET;
        NSString *url=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/login/loginJson", domainString];
        NSURL *realUrl=[[NSURL alloc] initWithString:url];
        
        //创建请求体字符串
        NSString *post=[[NSString alloc] initWithFormat:@"username=%@&password=%@", accountString, passwordString];
        
        //字符串转UTF-8编码方式
        NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
        
        //创建请求体
        NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
        
        //设置请求方式
        [request setHTTPMethod:@"post"];
        
        //填充请求体
        [request setHTTPBody:postData];
        
        //配置会话
        NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
        
        //创建会话
        NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:[NSOperationQueue mainQueue]];
        NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            NSLog(@"请求完成...");
            if (!error) {
                NSLog(@"成功");
                NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
                if ([code isEqualToString:@"1"]) {
                    //储存为字典
                    NSDictionary *userInfo=[nd objectForKey:@"data"];
                    
                    
                    //写入偏好设置
                    [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:userInfo, @"value", @"userInfo", @"key", nil]];
                    NSLog(@"登录成功");
                    
                    //成功然后退回
                    [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"yes", @"value", @"isLogin", @"key", nil]];
                    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
                } else {
                    NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                    //加个失败弹窗
                    [self popAlert:@"账号或密码错误"];
                }
            } else {
                NSLog(@"失败， %@", error);
                //加个失败弹窗
                [self popAlert:@"服务器连接失败"];
            }
        }];
        //执行会话任务
        [task resume];
    }
}

-(void)clickLogonBtn:(id)sender{
    //之前一直无法切换，是因为在遵守logonVCDelegate协议的类中，忘了赋值self
    [self.logonVCDelegate gotoLogonVC:self];
    NSLog(@"注册按钮");
}

-(void)clickCancelBtn:(id)sender{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    ;
}

#pragma mark - keyboard down

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
 
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    BOOL result=YES;
    NSLog(@"editField:%@", string);
    if(textField.tag == 120){
        //超过11位，则限制
        unsigned long oldStringLength=(unsigned long)textField.text.length;
        unsigned long newStringLength=(unsigned long)string.length;
        
        NSLog(@"oldStringLength:%lu, newStringLength:%lu", oldStringLength, newStringLength);//使用apple自带的复制粘贴，会比你复制的字符长度多1，比如复制“12”，则会变成“ 12”
        if (newStringLength <= 0) {
            //允许删除操作
            return YES;
        }
        if ((oldStringLength + newStringLength) > 12) {
            NSLog(@"超过最大长度");
            return NO;
        }
    }
    
    if(textField.tag == 121){
        //超过11位，则限制
        unsigned long oldStringLength=(unsigned long)textField.text.length;
        unsigned long newStringLength=(unsigned long)string.length;
        
        NSLog(@"oldStringLength:%lu, newStringLength:%lu", oldStringLength, newStringLength);//使用apple自带的复制粘贴，会比你复制的字符长度多1，比如复制“12”，则会变成“ 12”
        if (newStringLength <= 0) {
            //允许删除操作
            return YES;
        }
        if ((oldStringLength + newStringLength) > 12) {
            NSLog(@"超过最大长度");
            return NO;
        }
        
        //禁止输入非数字·字母字符
        NSCharacterSet *allOfCharAndNum=[NSCharacterSet alphanumericCharacterSet];
        NSArray *divArr=[string componentsSeparatedByCharactersInSet:allOfCharAndNum];
        NSString *finishString=[divArr componentsJoinedByString:@""];
        NSLog(@"中文禁止：%@, %@", divArr, finishString);
        if (![finishString isEqualToString:@""]) {
            NSLog(@"输入的字符必须是数字或字母");
            return NO;
        }
    }
    
    return result;
}

#pragma mark - alert

-(void)popAlert:(NSString *)msg{
    
    
    UIAlertController *errorBox=[UIAlertController alertControllerWithTitle:@"" message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:nil];
    
    [errorBox addAction:okAction];
    
    [self presentViewController:errorBox animated:YES completion:nil];
}

@end
