//
//  KBTabbar.m
//  KBTabbarController
//
//  Created by kangbing on 16/5/31.
//  Copyright © 2016年 kangbing. All rights reserved.
//

#import "KBTabbar.h"

@interface KBTabbar()


@end

@implementation KBTabbar


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        //[btn setImage:[[UIImage imageNamed:@"jia@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
        //btn.bounds = CGRectMake(0, 0, 64, 64);
        [btn setImage:[UIImage imageNamed:@"jia96.png"] forState:UIControlStateNormal];
        //[btn setBackgroundColor:[UIColor orangeColor]];
        //btn.bounds = CGRectMake(0, 0, 96, 96);
        btn.bounds = CGRectMake(0, 0, 70, 70);
        self.centerBtn = btn;
        [self addSubview:btn];
        
 
        //self.delegate=self;
    }
    return self;
}

- (void)layoutSubviews
{
    
    [super layoutSubviews];

    
    self.centerBtn.center = CGPointMake(self.bounds.size.width * 0.5, self.bounds.size.height * 0.2);
    
    int index = 0;
    CGFloat wigth = self.bounds.size.width / 5;
    
    for (UIView* sub in self.subviews) {
        
        if ([sub isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            
            sub.frame = CGRectMake(index * wigth, self.bounds.origin.y, wigth, self.bounds.size.height - 2);
            
            index++;
            
            if (index == 2) {
                index++;
            }
        }
    }
}



- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    
    if (self.isHidden == NO) {
        
        UIView *popView=(UIView *)[self viewWithTag:222];
        
        CGPoint newPoint = [self convertPoint:point toView:self.centerBtn];
        CGPoint popViewPoint = [self convertPoint:point toView:popView];
        
        if ( [self.centerBtn pointInside:newPoint withEvent:event]) {
            return self.centerBtn;
        }
        else if ([popView pointInside:popViewPoint withEvent:event])
        {
            return [popView hitTest:popViewPoint withEvent:event];
        }
        else{
            
            return [super hitTest:point withEvent:event];
        }
    }
    
    else {
        return [super hitTest:point withEvent:event];
    }
}

#pragma mark - UITabbarController

//-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
//
//
//    //收起按钮弹窗
//    NSLog(@"kbtabbar select item");
//    UIView *popBtnView=[self.kbDelegate getPopView];
//
//    if (![popBtnView isHidden]) {
//
//        [UIView animateWithDuration:0.4f animations:^{
//            [self.centerBtn setTransform:CGAffineTransformIdentity];
//        }];
//        [popBtnView setHidden:YES];
//    }
//}

//-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
//    
//    NSLog(@"select tabbarVC");
//}



#pragma mark - touch

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    NSLog(@"tabbar touch began");
}



@end
