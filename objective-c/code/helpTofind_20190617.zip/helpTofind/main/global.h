//
//  global.h
//  helpTofind
//
//  Created by rdt on 2019/5/24.
//  Copyright © 2019 电脑. All rights reserved.
//

#ifndef global_h
#define global_h

#define DOMAIN_SET @"192.168.20.20:83"


#endif /* global_h */
