//
//  tabbarExtView.m
//  helpTofind
//
//  Created by rdt on 2019/5/17.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "tabbarExtView.h"
#import "../dataPersistence/NSUserDefaults+nsUD_cate.h"

@interface tabbarExtView()

//发布失物按钮 callback
-(void)fbshiwuBtnClick:(id)sender;


//发布招领按钮 callback
-(void)fbzhaolingBtnClick:(id)sender;

@end

@implementation tabbarExtView

-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];

    
    
#pragma mark - fortest
    
    
    
    //背景视图加入
    UIImageView *bkImgView=[[UIImageView alloc] initWithFrame:self.bounds];
    [self addSubview:bkImgView];
    
    UIImage *bkImg=[UIImage imageNamed:@"usualBK.png"];
    bkImg=[bkImg resizableImageWithCapInsets:UIEdgeInsetsMake(bkImg.size.height*0.2f, bkImg.size.width*0.2f, bkImg.size.height*0.2f, bkImg.size.width*0.2f)];
    bkImgView.image=bkImg;
    //[bkImgView setBackgroundColor:[UIColor orangeColor]];
    
    
#pragma mark - button
    CGFloat btnWidth=[self bounds].size.width/3;
    CGFloat btnHeight=[self bounds].size.height/7*4;
    
    
    //发布失物按钮
    UIButton *fbshiwuBtn=[[UIButton alloc] initWithFrame:CGRectMake(btnWidth/3, self.bounds.size.height/8, btnWidth, btnWidth)];
    [self addSubview:fbshiwuBtn];
    [fbshiwuBtn setTag:45];
    
    UIImage *fbshiwuImg=[UIImage imageNamed:@"fabushiwu.png"];
    [fbshiwuBtn setBackgroundImage:fbshiwuImg forState:UIControlStateNormal];
    [fbshiwuBtn addTarget:self action:@selector(fbshiwuBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    //[fbshiwuBtn setBackgroundColor:[UIColor orangeColor]];
    
    
    //发布招领按钮
    UIButton *fbzhaolingBtn=[[UIButton alloc] initWithFrame:CGRectMake(btnWidth/3*5, self.bounds.size.height/8, btnWidth, btnWidth)];
    [self addSubview:fbzhaolingBtn];
    [fbzhaolingBtn setTag:46];
    
    UIImage *fbzhaolingImg=[UIImage imageNamed:@"fabuzhaoling.png"];
    [fbzhaolingBtn setBackgroundImage:fbzhaolingImg forState:UIControlStateNormal];
    [fbzhaolingBtn addTarget:self action:@selector(fbzhaolingBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    //[fbzhaolingBtn setBackgroundColor:[UIColor orangeColor]];
    
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

#pragma mark - btn callback


#warning "+ btn click"
-(void)fbshiwuBtnClick:(id)sender{
    //隐藏
    [self setHidden:YES];
    
    //动画复原
    [self.getViewDelegate resetBtnAnimate];
    
    
    //判断是否已经登录
    NSString *statusOfLogin=[NSUserDefaults getData:@"isLogin"];
    if (!statusOfLogin) {
        [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
        ;
        //未登录则跳转至登录
        [self.getViewDelegate gotoLoginView];
    }else{
        if ([statusOfLogin isEqualToString:@"yes"]) {

            //已经登录则跳转
            [self.getViewDelegate gotoFbswView:nil];
        }else if ([statusOfLogin isEqualToString:@"no"]){
            ;
            //未登录则跳转至登录
            [self.getViewDelegate gotoLoginView];
        }
        else {
            NSLog(@"unknow value of key \"inLogin\"");
        }
    }
}

-(void)fbzhaolingBtnClick:(id)sender{
    //隐藏
    [self setHidden:YES];
    //动画复原
    [self.getViewDelegate resetBtnAnimate];
    
    //判断是否已经登录
    NSString *statusOfLogin=[NSUserDefaults getData:@"isLogin"];
    if (!statusOfLogin) {
        [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
        
        //未登录则跳转至登录
        [self.getViewDelegate gotoLoginView];
    }else{
        if ([statusOfLogin isEqualToString:@"yes"]) {
            
            //已经登录则跳转
            [self.getViewDelegate gotoFbzlView:nil];
        }else if ([statusOfLogin isEqualToString:@"no"]){
            ;
            //未登录则跳转至登录
            [self.getViewDelegate gotoLoginView];
        }
        else {
            NSLog(@"unknow value of key \"inLogin\"");
        }
    }
}


#pragma mark - hittest

-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    if (self.isHidden == NO) {
        UIView *fbswView=(UIView *)[self viewWithTag:45];
        UIView *fbzlView=(UIView *)[self viewWithTag:46];

        CGPoint fbswPoint = [self convertPoint:point toView:fbswView];
        CGPoint fbzlPoint = [self convertPoint:point toView:fbzlView];

        if ( [fbswView pointInside:fbswPoint withEvent:event]) {
            return fbswView;
        }
        else if ( [fbzlView pointInside:fbzlPoint withEvent:event]) {
            return fbzlView;
        }
        else{

            return [super hitTest:point withEvent:event];
        }
    }

    else {
        return [super hitTest:point withEvent:event];
    }
}

#pragma mark - showBtn

-(void)showBtn{
    
    CGPoint lastCenter=self.center;
    
    //opc
    [self setAlpha:0.0f];
    
    //show
    [self setHidden:NO];
    
    //center down
    [self setCenter:CGPointMake(-lastCenter.x, lastCenter.y)];
    
    
    //
    [UIView animateWithDuration:0.4 animations:^{
        [self setCenter:lastCenter];
        [self setAlpha:1];
    }];
}


@end
