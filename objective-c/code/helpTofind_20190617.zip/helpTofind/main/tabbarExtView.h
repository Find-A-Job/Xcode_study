//
//  tabbarExtView.h
//  helpTofind
//
//  Created by rdt on 2019/5/17.
//  Copyright © 2019 电脑. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol plusButtonDelegate <NSObject>

@optional
-(id)getFbswView;
-(id)getFbzlView;
-(void)gotoFbswView:(nullable id)somewhere;
-(void)gotoFbzlView:(nullable id)somewhere;
-(void)resetBtnAnimate;
-(void)gotoLoginView;
-(void)gotoLogonView;


@end

@interface tabbarExtView : UIView

@property(weak, nonatomic) id<plusButtonDelegate> getViewDelegate;


//显现
-(void)showBtn;

//

@end

NS_ASSUME_NONNULL_END
