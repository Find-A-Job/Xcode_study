//
//  DIY_tabbar.m
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

//4f95fb深蓝色
//77b2fa浅蓝色
//747474 深灰色
//9d9d9d浅灰色


#warning "mission"
#pragma mark - 没完成的事。无

#import "DIY_tabbar.h"

#import "firstView.h"
#import "secondView.h"
#import "thirdButtonView.h"
#import "fourthView.h"
#import "fifthView.h"
#import "KBTabbar.h"
#import "userzmxDelegate.h"
#import "tabbarExtView.h"
#import "global.h"
#import "../dataPersistence/NSUserDefaults+nsUD_cate.h"

#pragma mark - 延时
//#define yanshi


#pragma mark - 声明
@interface DIY_tabbar() <userzmxDegelate, firstViewDelegate, plusButtonDelegate, UITabBarControllerDelegate, kbtabbarDelegate, UIGestureRecognizerDelegate, loginDelegate, NSURLSessionDelegate>

//4视图
@property(strong, nonatomic) UIViewController *view11;
@property(strong, nonatomic) UIViewController *view12;
@property(strong, nonatomic) UIViewController *view13;
@property(strong, nonatomic) UIViewController *view14;

//其他数据
@property(nonatomic) CGRect rectOfTabbar;

//中间按钮
@property(strong, nonatomic) UIButton *centBtn;

//popview
@property(strong, nonatomic) tabbarExtView *popBtnView;

//按钮回调
-(void)centerBtnClick:(id)sender;

//tap callback
-(void)tapScreen;

//全局
-(void)globalSetting;


//线程调用函数
@property(strong, nonatomic)NSThread *getPublicInfoThread;
@property(strong, nonatomic)NSThread *getUserInfoThread;
-(void)getInfo_Thread:(id)argv;
-(void)getUserInfo_thread:(id)argv;


//线程相关数据
@property(strong, atomic) NSDictionary *baseData;
@property(strong, atomic) NSDictionary *userData;
@property(strong, atomic) NSDictionary *imgPool;
@property(strong, atomic) NSDictionary *userImgPool;


@end

@implementation DIY_tabbar

-(void)viewDidLoad{
    [super viewDidLoad];
    
    [self globalSetting];
    
    //uicolor
    UIColor *shenhui=[UIColor colorWithRed:0x74/255.0f green:0x74/255.0f blue:0x74/255.0f alpha:1.0f];
    UIColor *qianhui=[UIColor colorWithRed:0x9d/255.0f green:0x9d/255.0f blue:0x9d/255.0f alpha:1.0f];
    UIColor *shenlan=[UIColor colorWithRed:0x4f/255.0f green:0x95/255.0f blue:0xfb/255.0f alpha:1.0f];
    UIColor *qianlan=[UIColor colorWithRed:0x77/255.0f green:0xb2/255.0f blue:0xfa/255.0f alpha:1.0f];
    
    
    //视图1
    firstView *fv1=[[firstView alloc] init];
    fv1.uzd=self;
    fv1.fDele=self;
    UINavigationController *navFv1=[[UINavigationController alloc] initWithRootViewController:fv1];
    navFv1.tabBarItem.title=@"首页";
    [navFv1.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navFv1.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navFv1.tabBarItem.image=[UIImage imageNamed:@"fz1@3x.png"];
    [navFv1.tabBarItem setSelectedImage:[[UIImage imageNamed:@"fz2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navFv1.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navFv1.navigationBar.topItem setTitle:@"首页"];
    [navFv1.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];
    [navFv1.navigationBar setShadowImage:[UIImage new]];
    self.view11=fv1;
    
    //视图2
    secondView *sv2=[[secondView alloc] init];
    sv2.uzd=self;
    UINavigationController *navSv2=[[UINavigationController alloc] initWithRootViewController:sv2];
    navSv2.tabBarItem.title=@"悬赏";
    [navSv2.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navSv2.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navSv2.tabBarItem.image=[UIImage imageNamed:@"xs1@3x.png"];
    [navSv2.tabBarItem setSelectedImage:[[UIImage imageNamed:@"xs2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navSv2.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navSv2.navigationBar.topItem setTitle:@"悬赏"];
    [navSv2.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];
    [navSv2.navigationBar setShadowImage:[UIImage new]];
    self.view12=sv2;
    
    //视图4
    fourthView *fv4=[[fourthView alloc] init];
    fv4.uzd=self;
    UINavigationController *navFv4=[[UINavigationController alloc] initWithRootViewController:fv4];
    navFv4.tabBarItem.title=@"资讯";
    [navFv4.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navFv4.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navFv4.tabBarItem.image=[UIImage imageNamed:@"zixun1@3x.png"];
    [navFv4.tabBarItem setSelectedImage:[[UIImage imageNamed:@"zixun2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navFv4.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navFv4.navigationBar.topItem setTitle:@"资讯"];
    [navFv4.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];
    [navFv4.navigationBar setShadowImage:[UIImage new]];
    self.view13=fv4;
    
    //视图5
    fifthView *fv5=[[fifthView alloc] init];
    fv5.uzd=self;
    UINavigationController *navFv5=[[UINavigationController alloc] initWithRootViewController:fv5];
    navFv5.tabBarItem.title=@"我的";
    [navFv5.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:shenhui, NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    [navFv5.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:qianlan, NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    navFv5.tabBarItem.image=[UIImage imageNamed:@"wode1@3x.png"];
    [navFv5.tabBarItem setSelectedImage:[[UIImage imageNamed:@"wode2@3x.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navFv5.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    [navFv5.navigationBar.topItem setTitle:@"我的"];
    [navFv5.navigationBar setBackgroundImage:[UIImage imageNamed:@"shangdi375110.png"] forBarMetrics:UIBarMetricsDefault];//背景图设置超过64，然后再设置ShadowImage可以去除底部横线
    [navFv5.navigationBar setShadowImage:[UIImage new]];
    self.view14=fv5;
    
    //成为tabbar控制器的子控制器
    [self setViewControllers:@[navFv1, navSv2, navFv4, navFv5]];
    
    
    
    //中央按钮3,KVC
    KBTabbar *tabbar = [[KBTabbar alloc]init];
    [self setValue:tabbar forKeyPath:@"tabBar"];
    [tabbar.centerBtn addTarget:self action:@selector(centerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    self.centBtn=tabbar.centerBtn;
    tabbar.kbDelegate=self;
    
    //其他数据
    self.rectOfTabbar=navFv1.tabBarController.tabBar.frame;
    
    
    
    //弹出按钮视图相关
#pragma mark - fortest
    
    CGFloat popViewWidth=[self.tabBar bounds].size.width/4*3;
    CGFloat popViewHeight=[self.tabBar bounds].size.height*5/2;
    tabbarExtView *popView=[[tabbarExtView alloc] initWithFrame:CGRectMake((self.tabBar.bounds.size.width-popViewWidth)/2, -popViewHeight, popViewWidth, popViewHeight)];
    [self.tabBar addSubview:popView];
    [self.tabBar sendSubviewToBack:popView];
    [popView setTag:222];
    self.popBtnView=popView;
    popView.getViewDelegate=self;
    [popView setHidden:YES];
    
    CGRect maskViewRect=[UIScreen mainScreen].bounds;
    CGFloat tabbarHeight=[self.tabBar bounds].size.height;
    maskViewRect.origin.y=-(maskViewRect.size.height-tabbarHeight);
    UIView *maskView=[[UIView alloc] initWithFrame:maskViewRect];
    [self.tabBar addSubview:maskView];
    [maskView setBackgroundColor:[UIColor clearColor]];
    [self.tabBar sendSubviewToBack:maskView];
    
    //self.tabBar.delegate=self;//会报错,tabbar是view，不能用<UITabbarControllerDelegate>协议
    self.delegate=self;
    
#pragma mark - notification
    
    
    
#pragma mark - UIGestureRecognizer
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapScreen)];
    tap.delegate=self;
    [self.view addGestureRecognizer:tap];
}

#pragma mark - center btn click

-(void)centerBtnClick:(id)sender{
    
    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
    
    if ([popBtnView isHidden]) {
        //旋转
        [UIView animateWithDuration:0.4f animations:^{
            [self.centBtn setTransform:CGAffineTransformMakeRotation(M_PI_4)];
        } completion:^(BOOL finished) {
            
        }];
        
        //按钮从左往右移动，渐显
        [popBtnView showBtn];
    }
    else{
        [UIView animateWithDuration:0.4f animations:^{
            [self.centBtn setTransform:CGAffineTransformIdentity];
        }];
        [popBtnView setHidden:YES];
    }

}
-(CGRect)getTabbarRect{
    return self.rectOfTabbar;
}


#pragma mark - lazy load
//懒加载
-(fabuView *)fabu{
    if (!_fabu) {
        _fabu=[[fabuView alloc] init];
    }
    
    return _fabu;
}

-(fabuView *)zhaoling{
    if (!_zhaoling) {
        _zhaoling=[[fabuView alloc] init];
    }
    
    return _zhaoling;
}

//登录
-(loginVC *)loginVCObj{
    if (!_loginVCObj) {
        _loginVCObj=[[loginVC alloc] init];
        _loginVCObj.logonVCDelegate=self;
    }
    
    return _loginVCObj;
}


//注册
-(logonVC *)logonVCObj{
    if (!_logonVCObj) {
        _logonVCObj=[[logonVC alloc] init];
    }
    
    return _logonVCObj;
}





//发布失物 视图
-(id)getFabuView{
    return [self fabu];
}

//发布招领 视图
-(id)getZhaoLingView{
    return [self zhaoling];
}

//登录 视图
-(id)getLoginVC{
    
    return [self loginVCObj];
}


//注册 视图
-(id)getLogonVC{
    
    return [self logonVCObj];
}

#pragma mark - plusButtonDelegate

-(id)getFbswView{
    return [self fabu];
}

-(id)getFbzlView{
    return [self zhaoling];
}
//从其他controller跳转至发布view
-(void)gotoFbswView:(id)somewhere{
//    //动画复原
//    [UIView animateWithDuration:0.4f animations:^{
//        [self.centBtn setTransform:CGAffineTransformIdentity];
//    }];
    
    //跳转新视图
    UIViewController *fbsw=[self fabu];
    fbsw.navigationItem.title=@"发布失物";
    switch ([self selectedIndex]) {
        case 0:
            [(firstView *)self.view11 gotoView:fbsw];
            break;
        case 1:
            [(secondView *)self.view12 gotoView:fbsw];
            break;
        case 2:
            [(fourthView *)self.view13 gotoView:fbsw];
            break;
        case 3:
            [(fifthView *)self.view14 gotoView:fbsw];
            break;
            
        default:
            break;
    }
}
-(void)gotoFbzlView:(id)somewhere{
//    //动画复原
//    [UIView animateWithDuration:0.4f animations:^{
//        [self.centBtn setTransform:CGAffineTransformIdentity];
//    }];
    
    //跳转新视图
    UIViewController *fbzl=[self zhaoling];
    fbzl.navigationItem.title=@"发布招领";
    switch ([self selectedIndex]) {
        case 0:
            [(firstView *)self.view11 gotoView:fbzl];
            break;
        case 1:
            [(secondView *)self.view12 gotoView:fbzl];
            break;
        case 2:
            [(fourthView *)self.view13 gotoView:fbzl];
            break;
        case 3:
            [(fifthView *)self.view14 gotoView:fbzl];
            break;
            
        default:
            break;
    }
}

#pragma mark - touch

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //收起按钮弹窗
    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
    
    if (![popBtnView isHidden]) {
        
        [UIView animateWithDuration:0.4f animations:^{
            [self.centBtn setTransform:CGAffineTransformIdentity];
        }];
        [popBtnView setHidden:YES];
        NSLog(@"touch to hide");
    }
}


#pragma mark - KB delegate

-(id)getPopView{
    
    return [self.tabBar viewWithTag:222];
}


#pragma mark - UITabbarController

//-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
//
//    NSLog(@"diy_tabbar.m select item");
//    //收起按钮弹窗
//    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
//
//    if (![popBtnView isHidden]) {
//
//        [UIView animateWithDuration:0.4f animations:^{
//            [self.centBtn setTransform:CGAffineTransformIdentity];
//        }];
//        [popBtnView setHidden:YES];
//    }
//}

-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{

    NSLog(@"选择标签");
    
    //收起按钮弹窗
    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
    
    if (![popBtnView isHidden]) {
        
        [UIView animateWithDuration:0.4f animations:^{
            [self.centBtn setTransform:CGAffineTransformIdentity];
        }];
        [popBtnView setHidden:YES];
    }
}

#pragma mark - uzd delegate

-(void)hidePopView{
    
    //收起按钮弹窗
    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
    
    if (![popBtnView isHidden]) {
        
        [UIView animateWithDuration:0.4f animations:^{
            [self.centBtn setTransform:CGAffineTransformIdentity];
        }];
        [popBtnView setHidden:YES];
    }
}

-(NSDictionary *)getPublicData_all{
    //公共数据
    return self.baseData;
}

-(NSDictionary *)getImgCachePool{
    //图片缓存
    return self.imgPool;
}

-(NSDictionary *)getUserData_all{
    return self.userData;
}

-(NSDictionary *)getUserImgCachePool{
    return self.userImgPool;
}

#pragma mark - UIGestureRecognizer

-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    //收起按钮弹窗
    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
    if (![popBtnView isHidden]) {
        NSLog(@"拦截该触碰消息");
        return YES;
    }else{
        NSLog(@"不拦截该触碰消息");
        return  NO;
    }
    
}




-(void)tapScreen{
    
    NSLog(@"tag screen");
    
    //收起按钮弹窗
    tabbarExtView *popBtnView=[self.tabBar viewWithTag:222];
    
    if (![popBtnView isHidden]) {
        
        [UIView animateWithDuration:0.4f animations:^{
            [self.centBtn setTransform:CGAffineTransformIdentity];
        }];
        [popBtnView setHidden:YES];
    }
}


#pragma mark - "global setting"

-(void)globalSetting{
    
    //注册消息通知事件，来更新数据
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateAllData) name:@"update" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateAllData) name:@"refreshAlldata" object:nil];
    
    self.baseData=nil;
    self.userData=nil;
    
    //开启线程，获取公共版的数据
    self.getPublicInfoThread=[[NSThread alloc] initWithTarget:self selector:@selector(getInfo_Thread:) object:nil];
    self.getPublicInfoThread.name=@"getInfoThread";
    self.getPublicInfoThread.threadPriority=1.0;
    [self.getPublicInfoThread start];
    
    //判断是否已经登录
    NSString *statusOfLogin=[NSUserDefaults getData:@"isLogin"];
    if (!statusOfLogin) {
        //初次使用，增加字段isLogin
        [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
        NSLog(@"初次使用");
    }else{
        if ([statusOfLogin isEqualToString:@"yes"]) {
            NSLog(@"已登录");
            //已经登录，则获取uid
            NSDictionary *userInfo=[NSUserDefaults getData:@"userInfo"];
            NSString *uid=[NSString stringWithFormat:@"%@", [userInfo objectForKey:@"uid"]];
            
            //开启新线程，获取用户的公共信息
            self.getUserInfoThread=[[NSThread alloc] initWithTarget:self selector:@selector(getUserInfo_thread:) object:uid];
            self.getUserInfoThread.name=@"getUserInfoThread";
            self.getUserInfoThread.threadPriority=0.8;
            [self.getUserInfoThread start];
            
        }else if ([statusOfLogin isEqualToString:@"no"]){
            //未登录，不做响应
            NSLog(@"未登录");
        }
        else {
            //未知错误
            NSLog(@"unknow value of key \"inLogin\"");
        }
    }
    
}

#pragma mark - "thread"

-(void)getInfo_Thread:(id)argv{
    NSLog(@"线程——公共数据获取--开始");
    NSString *domainString=DOMAIN_SET;
    NSString *urlString=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/swzl/swzlLists", domainString];
    NSURL *realUrl=[[NSURL alloc] initWithString:urlString];
    //NSString *uidString=[[NSUserDefaults getData:@"userInfo"] objectForKey:@"uid"];
    
    //创建请求体字符串
    NSString *post=[[NSString alloc] initWithFormat:@"status=%@", @"进行中"];
    
    //字符串转UTF-8编码方式
    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
    
    //创建请求体
    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
    
    //设置请求方式
    [request setHTTPMethod:@"post"];
    
    //填充请求体
    [request setHTTPBody:postData];
    
    //配置会话
    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    //创建会话
    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:nil];//[NSOperationQueue mainQueue],最后一位参数设置空，表示不在主线程中执行
    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"请求完成...");
        if (!error) {
            NSLog(@"成功");
            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
            if ([code isEqualToString:@"1"]) {
                
#ifdef yanshi
                //模拟网络延时
                [NSThread sleepForTimeInterval:10.0f];
#endif
                
                NSArray *dataArr=[nd objectForKey:@"data"];
                self.baseData=[[NSDictionary alloc] initWithObjectsAndKeys:dataArr, @"myData", nil];
                NSLog(@"公共数据下载完成,数量:%lu", dataArr.count);
                
                //发送通知，数据下载完成
                //通知操作若会导致UI刷新，则需要在主线程中发送通知
                
                NSLog(@"广播通知");
                [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"publicDataDownloadFinish" object:self.baseData];
                }];
                
                
                //开启新线程来缓存图片
                NSThread *imgCacheThread=[[NSThread alloc] initWithTarget:self selector:@selector(getImgCache_thread:) object:dataArr];
                imgCacheThread.name=@"imgCachePool";
                imgCacheThread.threadPriority=1.0f;
                [imgCacheThread start];
            } else {
                NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                //加个失败弹窗
                
                
                //发送通知，数据下载失败
                [[NSNotificationCenter defaultCenter] postNotificationName:@"publicDataDownloadFail" object:nil];
                NSLog(@"广播\'失败\'通知");
            }
        } else {
            NSLog(@"失败， %@", error);
            //加个失败弹窗
            
            
            //发送通知，数据下载失败
            [[NSNotificationCenter defaultCenter] postNotificationName:@"publicDataDownloadFail" object:nil];
            NSLog(@"广播\'失败\'通知");
        }
    }];
    //执行会话任务
    [task resume];
    
//    NSURLSession *session = [NSURLSession sharedSession];
//    [[session dataTaskWithURL:[NSURL URLWithString:@"http://myurl"]
//            completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//                NSError *jsonError = nil;
//                NSArray* jsonUsers = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
//                if (jsonError) {
//                    NSLog(@"error is %@", [jsonError localizedDescription]);
//                    // Handle Error and return
//                    return;
//                }
//                self.userArray = jsonUsers;
//                [self.userTableView reloadData];
//                if ([[NSThread currentThread] isMainThread]){
//                    NSLog(@"In main thread--completion handler");
//                }
//                else{
//                    NSLog(@"Not in main thread--completion handler");
//                }
//            }] resume];
    
    
    NSLog(@"线程——公共数据获取--结束");
}

-(void)getUserInfo_thread:(id)argv{
    NSLog(@"线程——用户数据获取--开始");
    NSString *domainString=DOMAIN_SET;
    NSString *urlString=[[NSString alloc] initWithFormat:@"http://%@/index.php?s=/swzl/swzlLists", domainString];
    NSURL *realUrl=[[NSURL alloc] initWithString:urlString];
    
    //创建请求体字符串
    NSString *post=[[NSString alloc] initWithFormat:@"uid=%@", (NSString *)argv];
    
    //字符串转UTF-8编码方式
    NSData *postData=[post dataUsingEncoding:NSUTF8StringEncoding];
    
    //创建请求体
    NSMutableURLRequest *request=[[NSMutableURLRequest alloc] initWithURL:realUrl];
    
    //设置请求方式
    [request setHTTPMethod:@"post"];
    
    //填充请求体
    [request setHTTPBody:postData];
    
    //配置会话
    NSURLSessionConfiguration *defaultConfig=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    //创建会话
    NSURLSession *uSession=[NSURLSession sessionWithConfiguration:defaultConfig delegate:self delegateQueue:nil];
    NSURLSessionDataTask *task=[uSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"请求完成...");
        if (!error) {
            NSLog(@"成功");
            NSDictionary *nd=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *code=[[NSString alloc] initWithFormat:@"%@", [nd objectForKey:@"code"]];
            if ([code isEqualToString:@"1"]) {
                
                
                
#ifdef yanshi
                //模拟网络延时
                [NSThread sleepForTimeInterval:10.0f];
#endif
                
                
                NSArray *dataArr=[nd objectForKey:@"data"];
                self.userData=[[NSDictionary alloc] initWithObjectsAndKeys:dataArr, @"myData", nil];
                
                NSLog(@"用户数据，数量；%lu\n%@", dataArr.count, dataArr);
                //通知操作若会导致UI刷新，则需要在主线程中发送通知
                [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                    NSLog(@"广播-用户数据下载完成");
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"userDataDownloadFinish" object:self.userData];
                }];
                
                
                //开启新线程来缓存图片
                NSThread *imgCacheThread=[[NSThread alloc] initWithTarget:self selector:@selector(getUserImgCache_thread:) object:dataArr];
                imgCacheThread.name=@"userimgCachePool";
                imgCacheThread.threadPriority=1.0f;
                [imgCacheThread start];
            } else {
                NSLog(@"失败， code:%@, msg:%@", code, [nd objectForKey:@"msg"]);
                //加个失败弹窗
            }
        } else {
            NSLog(@"失败， %@", error);
            //加个失败弹窗
        }
    }];
    //执行会话任务
    [task resume];
    
    
    NSLog(@"线程——用户数据获取--结束");
}

-(void)getImgCache_thread:(id)obj{
    NSLog(@"线程——缓存图片--开始");
    /*
     
     策略是：
     用字典存储图片
     键用id来表示
     值是uiimage类型
     若图片为空，则使用默认的图片
     
     */
    
    
#ifdef yanshi
    //模拟网络延时
    [NSThread sleepForTimeInterval:10.0f];
#endif
    
    
    NSArray *totalArray=obj;
    NSString *domainString=DOMAIN_SET;
    
    NSMutableDictionary *imgCachePoolDic=[[NSMutableDictionary alloc] init];
    NSString *key;
    NSString *imgURLString;
    UIImage *img;
    for (NSDictionary *eachDic in totalArray) {
        key=[NSString stringWithFormat:@"%@", [eachDic objectForKey:@"id"]];
        imgURLString=[NSString stringWithFormat:@"%@", [eachDic objectForKey:@"pic"]];
        if ([imgURLString isEqualToString:@"n"]) {
            img=[UIImage imageNamed:@"ka.png"];
        }else{
            img=[[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString
                                                                                           stringWithFormat:@"http://%@/upload/%@", domainString, [eachDic objectForKey:@"pic"]]]]];
        }
        
        
        [imgCachePoolDic setObject:img forKey:key];
    }
    
    
    self.imgPool=[NSDictionary dictionaryWithDictionary:imgCachePoolDic];
    
    //下载完成，发送通知
    NSLog(@"图片缓存完成--发送通知");
    //通知操作若会导致UI刷新，则需要在主线程中发送通知
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"imgCacheFinish" object:self.imgPool];
    }];
    
    NSLog(@"线程——缓存图片--结束");
}

-(void)getUserImgCache_thread:(id)obj{
    NSLog(@"线程——缓存用户图片--开始");
    /*
     
     策略是：
     用字典存储图片
     键用id来表示
     值是uiimage类型
     若图片为空，则使用默认的图片
     
     */
    
    

#ifdef yanshi
    //模拟网络延时
    [NSThread sleepForTimeInterval:10.0f];
#endif
    
    
    NSArray *totalArray=obj;
    NSString *domainString=DOMAIN_SET;
    
    NSMutableDictionary *imgCachePoolDic=[[NSMutableDictionary alloc] init];
    NSString *key;
    NSString *imgURLString;
    UIImage *img;
    for (NSDictionary *eachDic in totalArray) {
        key=[NSString stringWithFormat:@"%@", [eachDic objectForKey:@"id"]];
        imgURLString=[NSString stringWithFormat:@"%@", [eachDic objectForKey:@"pic"]];
        if ([imgURLString isEqualToString:@"n"]) {
            img=[UIImage imageNamed:@"ka.png"];
        }else{
            img=[[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString
                                                                                                  stringWithFormat:@"http://%@/upload/%@", domainString, [eachDic objectForKey:@"pic"]]]]];
        }
        
        
        [imgCachePoolDic setObject:img forKey:key];
    }
    
    
    self.userImgPool=[NSDictionary dictionaryWithDictionary:imgCachePoolDic];
    
    //下载完成，发送通知
    NSLog(@"用户图片缓存完成--发送通知\n%@", self.userImgPool);
    //通知操作若会导致UI刷新，则需要在主线程中发送通知
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"userimgCacheFinish" object:self.userImgPool];
    }];
    
    NSLog(@"线程——缓存用户图片--结束");
}


#pragma mark - "loginDelegate"

-(void)gotoLogonVC:(id)sender{
    
    UIViewController *loginView=sender;
    UIViewController *logonView=[self logonVCObj];
    [loginView presentViewController:logonView animated:YES completion:nil];
    NSLog(@"切换到注册界面");
}

-(id)getLogonVCfromloginvc{
    if ([self logonVCObj] == nil ) {
        NSLog(@"empty logonVCObj");
    }else{
        NSLog(@"not empty logonVCObj");
    }
    return [self logonVCObj];
}


#pragma mark - 复原动画

-(void)resetBtnAnimate{
    
    //动画复原
    [UIView animateWithDuration:0.4f animations:^{
        [self.centBtn setTransform:CGAffineTransformIdentity];
    }];
}


#pragma mark - 跳转至登录页面

-(void)gotoLoginView{
    
    //跳转新视图
    [self presentViewController:self.loginVCObj animated:YES completion:nil];
}

-(BOOL)isLoginFromFirstview{
    
    //判断是否已经登录
    NSString *statusOfLogin=[NSUserDefaults getData:@"isLogin"];
    if (!statusOfLogin) {
        [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
        ;
        //未登录则跳转至登录
        [self presentViewController:self.loginVCObj animated:YES completion:nil];
    }else{
        if ([statusOfLogin isEqualToString:@"yes"]) {
            
            //已经登录则跳转
            return YES;
        }else if ([statusOfLogin isEqualToString:@"no"]){
            ;
            //未登录则跳转至登录
            [self presentViewController:self.loginVCObj animated:YES completion:nil];
        }
        else {
            NSLog(@"unknow value of key \"inLogin\"");
        }
    }
    
    
    return NO;
    
}

#pragma mark - 更新全局数据

-(void)updateAllData{
    self.baseData=nil;
    self.userData=nil;
    
    //开启线程，获取公共版的数据
    self.getPublicInfoThread=[[NSThread alloc] initWithTarget:self selector:@selector(getInfo_Thread:) object:nil];
    self.getPublicInfoThread.name=@"getInfoThread";
    self.getPublicInfoThread.threadPriority=1.0;
    [self.getPublicInfoThread start];
    
    //判断是否已经登录
    NSString *statusOfLogin=[NSUserDefaults getData:@"isLogin"];
    if (!statusOfLogin) {
        //初次使用，增加字段isLogin
        [NSUserDefaults saveData:[[NSDictionary alloc] initWithObjectsAndKeys:@"no", @"value", @"isLogin", @"key", nil]];
        NSLog(@"初次使用");
    }else{
        if ([statusOfLogin isEqualToString:@"yes"]) {
            NSLog(@"已登录");
            //已经登录，则获取uid
            NSDictionary *userInfo=[NSUserDefaults getData:@"userInfo"];
            NSString *uid=[NSString stringWithFormat:@"%@", [userInfo objectForKey:@"uid"]];
            
            //开启新线程，获取用户的公共信息
            self.getUserInfoThread=[[NSThread alloc] initWithTarget:self selector:@selector(getUserInfo_thread:) object:uid];
            self.getUserInfoThread.name=@"getUserInfoThread";
            self.getUserInfoThread.threadPriority=0.8;
            [self.getUserInfoThread start];
            
        }else if ([statusOfLogin isEqualToString:@"no"]){
            //未登录，不做响应
            NSLog(@"未登录");
        }
        else {
            //未知错误
            NSLog(@"unknow value of key \"inLogin\"");
        }
    }
}
@end
