//
//  DIY_tabbar.h
//  helpTofind
//
//  Created by 电脑 on 2019/4/16.
//  Copyright © 2019年 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "../fourView/childOfFirst/fabuView.h"
#import "../loginon/loginVC.h"
#import "../loginon/logonVC.h"

@interface DIY_tabbar : UITabBarController

@property(strong, nonatomic) fabuView   *fabu;
@property(strong, nonatomic) fabuView   *zhaoling;
@property(strong, nonatomic) loginVC    *loginVCObj;
@property(strong, nonatomic) logonVC    *logonVCObj;

@end
