//
//  NSUserDefaults+nsUD_cate.h
//  helpTofind
//
//  Created by rdt on 2019/5/23.
//  Copyright © 2019 电脑. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSUserDefaults (nsUD_cate)

+(void)saveData:(NSDictionary *)data;
+(id)getData:(id)key;

@end

NS_ASSUME_NONNULL_END
