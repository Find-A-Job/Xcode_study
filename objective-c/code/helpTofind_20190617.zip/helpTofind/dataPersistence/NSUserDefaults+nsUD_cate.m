//
//  NSUserDefaults+nsUD_cate.m
//  helpTofind
//
//  Created by rdt on 2019/5/23.
//  Copyright © 2019 电脑. All rights reserved.
//

#import "NSUserDefaults+nsUD_cate.h"

@implementation NSUserDefaults (nsUD_cate)

/*
 
 结构
 
 |----isLogin
 |----userInfo
    |----uid
    |----username
    |----consigner
    |----mobile
    |----address
 |----myData
    |----[]
        |----id
        |----title
        |----address
        |----mobile
        |----resume
        |----goods_type
        |----pic
        |----lose_time
        |----create_itme
        |----for_money
        |----item_type
        |----uid
        |----status
 
 
 
 */

//存放
+(void)saveData:(NSDictionary *)data{
    [[NSUserDefaults standardUserDefaults] setObject:[data objectForKey:@"value"] forKey:[data objectForKey:@"key"]];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//读取
+(id)getData:(id)key{
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

@end
